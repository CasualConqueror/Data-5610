using UnityEngine;

public class LLMManager : MonoBehaviour
{
    /// <summary>
    /// Simulates an LLM call to generate ability code.
    /// This method logs the last score and returns a string of C# code that defines the ability.
    /// </summary>
    /// <param name="lastScore">A performance score that can condition the code generation.</param>
    /// <returns>A string containing the ability code snippet.</returns>
    public string SimulateLLMCall(float lastScore)
    {
        Debug.Log($"🤖 LLM Suggestion: Last score was {lastScore:F2}. Considering movement strategy changes.");
        // Return sample ability code that dashes forward and reports outcome.
        return @"
            // Ability: Dash forward
            Vector3 forward = agent.transform.forward;
            agent.transform.position += forward * 5f;
            // Report success (1.0 means very effective in this example)
            agent.abilityManager.NotifyAbilityOutcome(agent, 1.0f);
            Debug.Log(""[Ability] Agent dashes forward!"");
        ";
    }
}
