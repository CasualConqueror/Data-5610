using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Policies;
using Unity.MLAgents.Actuators;
using System;
using System.IO;
using System.Reflection;
using System.CodeDom.Compiler; // Ensure reference to System.CodeDom.dll
using Microsoft.CSharp;         // Ensure reference to Microsoft.CSharp.dll
using System.Collections.Generic;

[Serializable]
public class AbilityInfo
{
    public string abilityName;
    public Action<CustomAgent> abilityAction;
    public float effectiveness; // Ranges from 0 (ineffective) to 1 (highly effective)

    public AbilityInfo(string name, Action<CustomAgent> action, float initEffectiveness = 0.5f)
    {
        abilityName = name;
        abilityAction = action;
        effectiveness = initEffectiveness;
    }
}

public class AgentAbilityManager : MonoBehaviour
{
    // ----------------------------
    // Energy Settings
    // ----------------------------
    public int maxEnergy = 100;
    public int currentEnergy { get; private set; }
    public int abilityCost = 30;

    // ----------------------------
    // Collection of Abilities
    // ----------------------------
    public List<AbilityInfo> abilities = new List<AbilityInfo>();

    // ----------------------------
    // Maximum Number of Ability Slots (Fixed at 3 now)
    // ----------------------------
    public int maxAbilities = 3;

    // ----------------------------
    // Ability File Settings (Dynamic Code)
    // ----------------------------
    public string abilityFolder = "Assets/GeneratedAbilities";
    public string abilityFileName = "Ability.txt";
    private string abilityFilePath;
    private DateTime lastWriteTime;

    // ----------------------------
    // Reference to LLMManager
    // ----------------------------
    public LLMManager llmManager;

    // ----------------------------
    // Dynamic BehaviorParameters (for ML‑Agents)
    // ----------------------------
    private BehaviorParameters behaviorParameters;
    // Base observation size (set to your current 79 observations).
    public int baseObservationSize = 79;
    // Each ability slot adds one extra observation (for its effectiveness).
    public int abilityObservationIncrement = 1;
    // Note: Action space (1 continuous, 2 discrete branches with 2 options each) is fixed in the Inspector.

    // ----------------------------
    // Reference to the Agent Component
    // ----------------------------
    private CustomAgent customAgent;

    // ----------------------------
    // Initialization
    // ----------------------------
    void Start()
    {
        // Set energy to full at the start of the round.
        currentEnergy = maxEnergy;

        // Get the CustomAgent component and assign a reference to this manager.
        customAgent = GetComponent<CustomAgent>();
        if (customAgent == null)
        {
            Debug.LogError("AgentAbilityManager requires a CustomAgent component on the same GameObject.");
        }
        else
        {
            // Ensure that CustomAgent has a public field 'abilityManager'.
            customAgent.abilityManager = this;
        }

        // Get BehaviorParameters for updating observation space.
        behaviorParameters = GetComponent<BehaviorParameters>();
        if (behaviorParameters == null)
        {
            Debug.LogError("AgentAbilityManager requires a BehaviorParameters component on the same GameObject.");
        }

        // Ensure the ability folder exists.
        if (!Directory.Exists(abilityFolder))
        {
            Directory.CreateDirectory(abilityFolder);
        }
        abilityFilePath = Path.Combine(abilityFolder, abilityFileName);
        if (!File.Exists(abilityFilePath))
        {
            File.WriteAllText(abilityFilePath, "");
        }
        lastWriteTime = File.GetLastWriteTime(abilityFilePath);

        // Load any existing ability from the file.
        LoadAbilityFromFile();
        UpdateObservationSpace();
    }

    // ----------------------------
    // Update Loop
    // ----------------------------
    void Update()
    {
        // Continuously check for changes in the ability file.
        DateTime newWriteTime = File.GetLastWriteTime(abilityFilePath);
        if (newWriteTime != lastWriteTime)
        {
            lastWriteTime = newWriteTime;
            LoadAbilityFromFile();
            UpdateObservationSpace();
        }

        // For simulation/testing:
        // Press "L" to simulate an LLM request for a new ability.
        if (Input.GetKeyDown(KeyCode.L))
        {
            RequestAbilityFromLLM();
        }

        // Press "A" to try using the first ability (for demonstration).
        if (Input.GetKeyDown(KeyCode.A))
        {
            // In practice, your policy should select which ability to use.
            TryUseAbility(0);
        }
    }

    // ----------------------------
    // Request Ability from LLM via LLMManager
    // ----------------------------
    void RequestAbilityFromLLM()
    {
        // Do not call the LLM if ability slots are full.
        if (abilities.Count >= maxAbilities)
        {
            Debug.Log("Ability slots are full. Not requesting a new ability.");
            return;
        }

        if (llmManager == null)
        {
            Debug.LogError("LLMManager is not assigned in AgentAbilityManager.");
            return;
        }

        // Simulate an LLM call; passing a sample score (e.g., 0.5).
        string abilityCode = llmManager.SimulateLLMCall(0.5f);

        // For uniqueness, assume the LLM provides a unique ability name ("DashAbility").
        string newAbilityName = "DashAbility";
        if (abilities.Exists(a => a.abilityName == newAbilityName))
        {
            Debug.Log("Ability already exists. Not adding duplicate.");
            return;
        }

        // Write the ability code to the file (this triggers the file watcher reload).
        File.WriteAllText(abilityFilePath, abilityCode);
        Debug.Log("LLM ability received and written to file: " + abilityFilePath);
    }

    // ----------------------------
    // Load and Compile Ability Code
    // ----------------------------
    void LoadAbilityFromFile()
    {
        string codeContent = File.ReadAllText(abilityFilePath);
        if (string.IsNullOrWhiteSpace(codeContent))
        {
            Debug.Log("Ability file is empty. No new ability loaded.");
            return;
        }
        // Wrap the file content in a complete class definition.
        string fullCode = @"
using UnityEngine;
public static class DynamicAbility {
    public static void UseAbility(CustomAgent agent) {
        " + codeContent + @"
    }
}
";
        Action<CustomAgent> compiledAbility = CompileAbility(fullCode);
        if (compiledAbility != null)
        {
            string abilityName = "DashAbility"; // Must match the unique name provided by the LLM.
            abilities.Add(new AbilityInfo(abilityName, compiledAbility));
            Debug.Log("Loaded new ability: " + abilityName);
        }
    }

    Action<CustomAgent> CompileAbility(string sourceCode)
    {
        CSharpCodeProvider provider = new CSharpCodeProvider();
        CompilerParameters parameters = new CompilerParameters
        {
            GenerateInMemory = true,
            TreatWarningsAsErrors = false
        };
        parameters.ReferencedAssemblies.Add("UnityEngine.dll");
        parameters.ReferencedAssemblies.Add("Assembly-CSharp.dll");

        CompilerResults results = provider.CompileAssemblyFromSource(parameters, sourceCode);
        if (results.Errors.HasErrors)
        {
            Debug.LogError("Ability compile error: " + results.Errors[0].ErrorText);
            return null;
        }
        Assembly assembly = results.CompiledAssembly;
        Type abilityType = assembly.GetType("DynamicAbility");
        MethodInfo method = abilityType.GetMethod("UseAbility", BindingFlags.Public | BindingFlags.Static);
        return (Action<CustomAgent>)Delegate.CreateDelegate(typeof(Action<CustomAgent>), method);
    }

    // ----------------------------
    // Use an Ability (by Index)
    // ----------------------------
    public void TryUseAbility(int index)
    {
        if (index < 0 || index >= abilities.Count)
        {
            Debug.LogWarning("Invalid ability index selected.");
            return;
        }
        if (currentEnergy < abilityCost)
        {
            Debug.Log("Insufficient Energy to use ability. Current Energy: " + currentEnergy);
            return;
        }
        currentEnergy -= abilityCost;
        abilities[index].abilityAction.Invoke(customAgent);
        Debug.Log("Used ability: " + abilities[index].abilityName + ". Remaining Energy: " + currentEnergy);
    }

    // ----------------------------
    // Ability Outcome Reporting
    // ----------------------------
    /// <summary>
    /// Call this method from within your dynamic ability code to report its effectiveness (a value between 0 and 1).
    /// </summary>
    public void NotifyAbilityOutcome(CustomAgent agent, float outcome)
    {
        // Update the effectiveness for the most recently added ability.
        if (abilities.Count > 0)
        {
            AbilityInfo lastAbility = abilities[abilities.Count - 1];
            float lerpFactor = 0.2f;
            lastAbility.effectiveness = Mathf.Lerp(lastAbility.effectiveness, outcome, lerpFactor);
            Debug.Log("Updated effectiveness for " + lastAbility.abilityName + " to: " + lastAbility.effectiveness);
        }
    }

    // ----------------------------
    // Fixed Ability Observations
    // ----------------------------
    /// <summary>
    /// Returns an array of length maxAbilities (here 3) with the effectiveness values.
    /// For any ability slot not filled, returns a neutral value (0.5).
    /// </summary>
    public float[] GetAbilityObservations()
    {
        float[] obs = new float[maxAbilities];
        for (int i = 0; i < maxAbilities; i++)
        {
            if (i < abilities.Count)
                obs[i] = abilities[i].effectiveness;
            else
                obs[i] = 0.5f;
        }
        return obs;
    }

    // ----------------------------
    // Update Observation Space
    // ----------------------------
    // We update the observation size to accommodate the fixed ability observation slots.
    void UpdateObservationSpace()
    {
        if (behaviorParameters == null)
        {
            Debug.LogWarning("BehaviorParameters not found. Cannot update observation space.");
            return;
        }
        // Update observation size: base (79) plus fixed space for maxAbilities (3).
        int newObsSize = baseObservationSize + maxAbilities * abilityObservationIncrement;
        behaviorParameters.BrainParameters.VectorObservationSize = newObsSize;
        Debug.Log("Updated observation size to: " + newObsSize);
    }
}
