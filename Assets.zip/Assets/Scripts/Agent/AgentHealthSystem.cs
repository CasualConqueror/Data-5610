using UnityEngine;
using Unity.MLAgents;

public class AgentHealthSystem : MonoBehaviour
{
    [Header("Health Settings")]
    public float maxHealth = 100f;
    [HideInInspector] public float currentHealth;

    [Header("Combat Settings")]
    public int teamID = 0; // 0 or 1 to identify teams
    public float attackRange = 1.25f;
    public float attackDamage = 10f;
    public float attackCooldown = 1f;
    [HideInInspector] public float attackTimer = 0f;

    [Header("Rewards")]
    public float damageReward = 0.05f; // Small reward for dealing damage
    public float damagePenalty = -0.03f; // Small penalty for taking damage

    private CustomAgent agentRef;
    private Color hitMarkerColor = Color.green;
    private bool showHitMarker = false;
    private Vector3 hitPosition;

    private void Awake()
    {
        agentRef = GetComponent<CustomAgent>();
    }

    public void Initialize()
    {
        currentHealth = maxHealth;
        attackTimer = 0f;
        showHitMarker = false;
    }

    public void UpdateCooldowns()
    {
        if (attackTimer > 0)
            attackTimer -= Time.deltaTime;
    }

    public void TryAttack(CustomAgent opponent, Vector3 hitPoint)
    {
        // Reset attack cooldown
        attackTimer = attackCooldown;

        // Verify opponent exists and is in range
        if (opponent != null)
        {
            // Get reference to opponent's blocking system
            AgentBlockSystem opponentBlockSystem = opponent.GetComponent<AgentBlockSystem>();

            // Check if opponent is blocking and facing us
            if (opponentBlockSystem != null && opponentBlockSystem.isBlocking &&
                opponentBlockSystem.IsAttackBlocked(transform.position, hitPoint))
            {
                // Attack was blocked!
                opponentBlockSystem.BlockAttack(hitPoint);
                Debug.Log($"🛡️ Agent {opponent.teamID} blocked attack from Agent {agentRef.teamID}!");
            }
            else
            {
                // Deal damage to opponent
                opponent.GetComponent<AgentHealthSystem>().TakeDamage(attackDamage, agentRef);

                // Set hit marker for visualization
                showHitMarker = true;
                hitPosition = hitPoint;

                // Reward for successful hit
                agentRef.AddReward(damageReward);

                Debug.Log($"⚔️ Agent {agentRef.teamID} hit opponent {opponent.teamID} for {attackDamage} damage!");
            }
        }

        // Hit marker disappears after a short time
        Invoke(nameof(HideHitMarker), 0.3f);
    }

    public void TakeDamage(float damage, CustomAgent attacker)
    {
        currentHealth -= damage;

        // Apply penalty for taking damage
        agentRef.AddReward(damagePenalty);

        // Check if agent is defeated
        if (currentHealth <= 0)
        {
            Debug.Log($"☠️ Agent {agentRef.teamID} defeated by Agent {attacker.teamID}!");
            attacker.AddReward(0.5f); // Bonus reward for defeating an opponent
            agentRef.EndEpisode(); // End episode for this agent
        }
    }

    private void HideHitMarker()
    {
        showHitMarker = false;
    }

    private void OnDrawGizmos()
    {
        Vector3 rayOrigin = transform.position + Vector3.up * 0.5f;

        // Draw attack range
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(rayOrigin + transform.forward * (attackRange/2), attackRange/2);

        // Draw hit marker if active
        if (showHitMarker)
        {
            Gizmos.color = hitMarkerColor;
            Gizmos.DrawSphere(hitPosition, 0.2f);
        }
    }
}