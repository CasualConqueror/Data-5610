using UnityEngine;

public class AgentBlockSystem : MonoBehaviour
{
    [Header("Block Settings")]
    public float blockRange = 1.5f;
    public float blockAngle = 120f; // Angle in degrees for successful block (forward cone)
    public GameObject blockShieldVisual; // Optional visual for when blocking
    public float blockReward = 0.02f; // Reward for a successful block
    public float blockPenalty = -0.03f; // Punishment when blocking with no threat
    public LayerMask opponentLayer;  // Layer mask to detect potential attackers

    [HideInInspector] public bool isBlocking = false;

    private CustomAgent agentRef;
    private Color blockRangeColor = Color.blue;
    private Color blockMarkerColor = Color.cyan;
    private bool showBlockMarker = false;
    private Vector3 blockPosition;

    // Flag to ensure punishment is applied only once per block activation.
    private bool punishedThisBlock = false;

    private void Awake()
    {
        agentRef = GetComponent<CustomAgent>();
    }

    public void Initialize()
    {
        isBlocking = false;
        showBlockMarker = false;
        punishedThisBlock = false;

        if (blockShieldVisual != null)
        {
            blockShieldVisual.SetActive(false);
        }
    }

    public void SetBlockState(bool blocking)
    {
        // If switching to blocking state, check for nearby opponents.
        if (blocking && !isBlocking)
        {
            // Check for opponents in range.
            Collider[] hitColliders = Physics.OverlapSphere(transform.position, blockRange, opponentLayer);
            if (hitColliders.Length == 0 && !punishedThisBlock)
            {
                // No opponent is near, so apply a small punishment.
                if (agentRef != null)
                {
                    agentRef.AddReward(blockPenalty);
                    Debug.Log($"[Block] Punishment applied: {blockPenalty}");
                }
                punishedThisBlock = true;
            }
        }
        // If agent is not blocking anymore, reset the punishment flag.
        if (!blocking)
        {
            punishedThisBlock = false;
        }

        isBlocking = blocking;

        // Update the blocking visual if assigned.
        if (blockShieldVisual != null)
        {
            blockShieldVisual.SetActive(isBlocking);
        }
    }

    // Check if an incoming attack is blocked (based on direction and distance).
    public bool IsAttackBlocked(Vector3 attackerPosition, Vector3 hitPoint)
    {
        Vector3 directionToAttacker = (attackerPosition - transform.position).normalized;
        float angleToAttacker = Vector3.Angle(transform.forward, directionToAttacker);
        float distanceToAttacker = Vector3.Distance(transform.position, attackerPosition);

        // Block is successful if:
        // 1. Attacker is within the block angle in front of the blocker
        // 2. Attacker is within block range
        return angleToAttacker <= blockAngle / 2 && distanceToAttacker <= blockRange;
    }

    public void BlockAttack(Vector3 hitPoint)
    {
        // Show block visual effect.
        showBlockMarker = true;
        blockPosition = hitPoint;

        // Reward for a successful block.
        if (agentRef != null)
        {
            agentRef.AddReward(blockReward);
        }

        // Hide block marker after a short delay.
        Invoke(nameof(HideBlockMarker), 0.3f);
    }

    private void HideBlockMarker()
    {
        showBlockMarker = false;
    }

    private void OnDrawGizmos()
    {
        if (!isBlocking && !Application.isEditor)
            return;

        Vector3 rayOrigin = transform.position + Vector3.up * 0.5f;
        Gizmos.color = blockRangeColor;

        // Visualize the block cone.
        Vector3 blockCenter = rayOrigin + transform.forward * (blockRange / 2);
        Gizmos.DrawRay(rayOrigin, transform.forward * blockRange);

        float halfAngleRad = (blockAngle / 2) * Mathf.Deg2Rad;
        Vector3 rightBlockDir = Quaternion.AngleAxis(blockAngle / 2, Vector3.up) * transform.forward;
        Vector3 leftBlockDir = Quaternion.AngleAxis(-blockAngle / 2, Vector3.up) * transform.forward;
        Gizmos.DrawRay(rayOrigin, rightBlockDir * blockRange);
        Gizmos.DrawRay(rayOrigin, leftBlockDir * blockRange);

        // Connect rays to form the cone shape.
        Vector3 rightPoint = rayOrigin + rightBlockDir * blockRange;
        Vector3 leftPoint = rayOrigin + leftBlockDir * blockRange;
        Vector3 forwardPoint = rayOrigin + transform.forward * blockRange;
        Gizmos.DrawLine(rightPoint, forwardPoint);
        Gizmos.DrawLine(leftPoint, forwardPoint);
        Gizmos.DrawLine(rightPoint, leftPoint);

        // Draw a wire sphere representing block range.
        Gizmos.DrawWireSphere(rayOrigin + transform.forward * (blockRange / 2), blockRange / 2);

        // Draw block marker if active.
        if (showBlockMarker)
        {
            Gizmos.color = blockMarkerColor;
            Gizmos.DrawSphere(blockPosition, 0.3f);
            Gizmos.DrawLine(blockPosition, blockPosition + Vector3.up * 0.5f);
        }
    }
}
