using UnityEngine;
using System.Collections.Generic;

public class AgentPerceptionSystem : MonoBehaviour
{
    [Header("Raycast Settings")]
    public int rayCount = 8; // Number of rays to cast around the agent
    public float rayLength = 10f; // Maximum length of raycasts
    public bool visualizeAllRays = true; // Option to visualize all raycasts
    public LayerMask targetLayer; // Layer mask for target
    public LayerMask opponentLayer; // Layer for opponent agents

    [HideInInspector] public List<RaycastHit> raycastHits; // Store raycast results
    [HideInInspector] public List<bool> rayHitResults; // Store whether each ray hit something

    private CustomAgent agentRef;
    private Color raycastColor = Color.yellow;

    private void Awake()
    {
        agentRef = GetComponent<CustomAgent>();
    }

    public void Initialize()
    {
        // Initialize raycast storage
        raycastHits = new List<RaycastHit>(rayCount);
        rayHitResults = new List<bool>(rayCount);
        for (int i = 0; i < rayCount; i++)
        {
            raycastHits.Add(new RaycastHit());
            rayHitResults.Add(false);
        }
    }

    public void PerformRaycasts()
    {
        Vector3 rayOrigin = transform.position + Vector3.up * 0.5f;

        // Clear previous results
        for (int i = 0; i < rayCount; i++)
        {
            rayHitResults[i] = false;
        }

        // Cast rays in all directions
        for (int i = 0; i < rayCount; i++)
        {
            // Calculate direction based on index (distribute evenly in 360 degrees)
            float angle = i * (360f / rayCount);
            Vector3 direction = Quaternion.Euler(0, angle, 0) * Vector3.forward;

            // First check for target
            if (Physics.Raycast(rayOrigin, direction, out RaycastHit targetHit, rayLength, targetLayer))
            {
                raycastHits[i] = targetHit;
                rayHitResults[i] = true;
            }
            // Then check for opponents
            else if (Physics.Raycast(rayOrigin, direction, out RaycastHit opponentHit, rayLength, opponentLayer))
            {
                raycastHits[i] = opponentHit;
                rayHitResults[i] = true;
            }
            // Finally check for any obstacles
            else if (Physics.Raycast(rayOrigin, direction, out RaycastHit obstacleHit, rayLength))
            {
                raycastHits[i] = obstacleHit;
                rayHitResults[i] = true;
            }
        }
    }

    public CustomAgent FindClosestOpponent()
    {
        CustomAgent closestOpponent = null;
        float closestDistance = float.MaxValue;

        for (int i = 0; i < rayCount; i++)
        {
            if (rayHitResults[i])
            {
                if (raycastHits[i].collider.gameObject.layer == (int)Mathf.Log(opponentLayer.value, 2))
                {
                    CustomAgent opponent = raycastHits[i].collider.GetComponent<CustomAgent>();
                    if (opponent != null && opponent.teamID != agentRef.teamID)
                    {
                        float distance = raycastHits[i].distance;
                        if (distance < closestDistance)
                        {
                            closestDistance = distance;
                            closestOpponent = opponent;
                        }
                    }
                }
            }
        }

        return closestOpponent;
    }

    public Vector3 GetDirectionToTarget(Transform target)
    {
        for (int i = 0; i < rayCount; i++)
        {
            if (rayHitResults[i])
            {
                if (raycastHits[i].collider.gameObject.layer == (int)Mathf.Log(targetLayer.value, 2))
                {
                    return (raycastHits[i].point - transform.position).normalized;
                }
            }
        }

        // If target not found by raycast, use direct vector
        return (target.position - transform.position).normalized;
    }

    private void OnDrawGizmos()
    {
        if (!Application.isPlaying)
            return;

        Vector3 rayOrigin = transform.position + Vector3.up * 0.5f;

        // Draw main detection ray
        Gizmos.color = raycastColor;
        Gizmos.DrawRay(rayOrigin, transform.forward * 10f);

        // Draw all raycasts if enabled
        if (visualizeAllRays)
        {
            for (int i = 0; i < rayCount; i++)
            {
                float angle = i * (360f / rayCount);
                Vector3 direction = Quaternion.Euler(0, angle, 0) * Vector3.forward;

                if (rayHitResults != null && i < rayHitResults.Count && rayHitResults[i])
                {
                    // Draw ray with hit
                    Gizmos.color = Color.green;
                    Gizmos.DrawLine(rayOrigin, raycastHits[i].point);
                    Gizmos.DrawSphere(raycastHits[i].point, 0.1f);

                    // Different color based on what was hit
                    if (raycastHits[i].collider.gameObject.layer == (int)Mathf.Log(targetLayer.value, 2))
                    {
                        Gizmos.color = Color.yellow; // Target color
                    }
                    else if (raycastHits[i].collider.gameObject.layer == (int)Mathf.Log(opponentLayer.value, 2))
                    {
                        Gizmos.color = Color.red; // Opponent color
                    }
                    else
                    {
                        Gizmos.color = Color.gray; // Obstacle color
                    }
                    Gizmos.DrawSphere(raycastHits[i].point, 0.15f);
                }
                else
                {
                    // Draw ray without hit
                    Gizmos.color = new Color(0.5f, 0.5f, 0.5f, 0.5f); // Semi-transparent gray
                    Gizmos.DrawRay(rayOrigin, direction * rayLength);
                }
            }
        }
        else if (!Application.isPlaying)
        {
            // Simple visualization in editor when not playing
            for (int i = 0; i < rayCount; i++)
            {
                float angle = i * (360f / rayCount);
                Vector3 direction = Quaternion.Euler(0, angle, 0) * Vector3.forward;

                Gizmos.color = new Color(0.5f, 0.5f, 0.5f, 0.3f);
                Gizmos.DrawRay(rayOrigin, direction * rayLength);
            }
        }
    }
}