using UnityEngine;

public class AgentMovementSystem : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 5f;
    public float rotationSpeed = 120f;

    private Rigidbody rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    public void Move(float moveX, float moveZ, float rotateY)
    {
        // Apply rotation
        transform.Rotate(0, rotateY * rotationSpeed * Time.deltaTime, 0);

        // Apply movement
        Vector3 moveDir = new Vector3(moveX, 0, moveZ);

        // Use Rigidbody for movement if available (better for physics)
        if (rb != null)
        {
            Vector3 newPos = transform.position + moveDir * moveSpeed * Time.deltaTime;
            rb.MovePosition(newPos);
        }
        else
        {
            transform.position += moveDir * moveSpeed * Time.deltaTime;
        }
    }

    public void ResetMovement()
    {
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
    }
}