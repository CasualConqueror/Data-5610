using UnityEngine;

/// <summary>
/// This helper class connects the separated agent components together
/// by forwarding events between them.
/// </summary>
public class AgentComponentsConnector : MonoBehaviour
{
    private CustomAgent agent;
    private AgentHealthSystem healthSystem;
    private AgentBlockSystem blockSystem;
    private AgentPerceptionSystem perceptionSystem;
    private AgentMovementSystem movementSystem;

    private void Awake()
    {
        // Get references to all components
        agent = GetComponent<CustomAgent>();
        healthSystem = GetComponent<AgentHealthSystem>();
        blockSystem = GetComponent<AgentBlockSystem>();
        perceptionSystem = GetComponent<AgentPerceptionSystem>();
        movementSystem = GetComponent<AgentMovementSystem>();

        // Validate required components
        if (agent == null || healthSystem == null || blockSystem == null ||
            perceptionSystem == null || movementSystem == null)
        {
            Debug.LogError("Missing required components on " + gameObject.name);
            enabled = false;
            return;
        }
    }

    // Extend the TryAttack method
    public void ExtendedTryAttack(CustomAgent opponent, Vector3 hitPoint)
    {
        // Call original functionality
        healthSystem.TryAttack(opponent, hitPoint);
    }

    // Extend the BlockAttack method
    public void ExtendedBlockAttack(Vector3 hitPoint)
    {
        // Call original functionality
        blockSystem.BlockAttack(hitPoint);
    }

    // Extend the TakeDamage method
    public void ExtendedTakeDamage(float damage, CustomAgent attacker)
    {
        // Call original functionality
        healthSystem.TakeDamage(damage, attacker);
    }
}
