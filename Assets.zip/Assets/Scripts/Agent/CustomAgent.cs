using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

public class CustomAgent : Agent
{
    [Header("References")]
    public Transform target;
    public LLMManager llm;

    // Constants
    private const int LLM_MUTATION_CHANCE = 1500;
    public float targetReachReward = 1.0f;
    // New: small punishment when attacking with no enemy nearby.
    public float attackPenalty = -0.03f;

    // Component references
    private AgentMovementSystem movementSystem;
    private AgentHealthSystem healthSystem;
    private AgentBlockSystem blockSystem;
    private AgentPerceptionSystem perceptionSystem;
    public AgentAbilityManager abilityManager;  // Must be assigned (or set by AgentAbilityManager)

    // Team ID (for team-based scenarios)
    public int teamID = 0;

    public override void Initialize()
    {
        base.Initialize();

        // Get all required components.
        movementSystem = GetComponent<AgentMovementSystem>();
        healthSystem = GetComponent<AgentHealthSystem>();
        blockSystem = GetComponent<AgentBlockSystem>();
        perceptionSystem = GetComponent<AgentPerceptionSystem>();

        // Initialize systems.
        healthSystem.Initialize();
        blockSystem.Initialize();
        perceptionSystem.Initialize();
    }

    public override void OnEpisodeBegin()
    {
        // Reset systems.
        healthSystem.Initialize();
        blockSystem.Initialize();
        movementSystem.ResetMovement();

        // Randomize agent spawn position.
        transform.localPosition = new Vector3(Random.Range(-5f, 5f), 1f, Random.Range(-5f, 5f));

        // Randomize target position if assigned.
        if (target != null)
        {
            target.localPosition = new Vector3(Random.Range(-5f, 5f), 1f, Random.Range(-5f, 5f));
        }
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // First update perception via raycasts.
        perceptionSystem.PerformRaycasts();

        // --- Base Observations (Total = 79) ---
        // 1. Agent position (x, y, z)
        sensor.AddObservation(transform.localPosition);

        // 2. Agent's forward direction (normalized x, z)
        Vector3 forward = transform.forward;
        sensor.AddObservation(forward.x);
        sensor.AddObservation(forward.z);

        // 3. Target position (x, y, z)
        sensor.AddObservation(target.localPosition);

        // 4. Direction to target (normalized x, z)
        Vector3 dirToTarget = (target.localPosition - transform.localPosition).normalized;
        sensor.AddObservation(dirToTarget.x);
        sensor.AddObservation(dirToTarget.z);

        // 5. Agent's health (normalized)
        sensor.AddObservation(healthSystem.currentHealth / healthSystem.maxHealth);

        // 6. Attack cooldown (normalized)
        sensor.AddObservation(healthSystem.attackTimer / healthSystem.attackCooldown);

        // 7. Blocking flag (1 if blocking, 0 otherwise)
        sensor.AddObservation(blockSystem.isBlocking ? 1f : 0f);

        // 8. Observations from multiple raycasts.
        for (int i = 0; i < perceptionSystem.rayCount; i++)
        {
            if (perceptionSystem.rayHitResults[i])
            {
                sensor.AddObservation(1f);
                sensor.AddObservation(perceptionSystem.raycastHits[i].distance / perceptionSystem.rayLength);
                int hitLayer = perceptionSystem.raycastHits[i].collider.gameObject.layer;
                if (hitLayer == (int)Mathf.Log(perceptionSystem.targetLayer.value, 2))
                {
                    sensor.AddObservation(1f);
                    sensor.AddObservation(0f);
                }
                else if (hitLayer == (int)Mathf.Log(perceptionSystem.opponentLayer.value, 2))
                {
                    sensor.AddObservation(0f);
                    sensor.AddObservation(1f);
                    CustomAgent opponent = perceptionSystem.raycastHits[i].collider.GetComponent<CustomAgent>();
                    if (opponent != null && opponent.teamID != this.teamID)
                    {
                        AgentHealthSystem opponentHealth = opponent.GetComponent<AgentHealthSystem>();
                        AgentBlockSystem opponentBlock = opponent.GetComponent<AgentBlockSystem>();
                        sensor.AddObservation(opponentHealth.currentHealth / opponentHealth.maxHealth);
                        sensor.AddObservation(opponentBlock.isBlocking ? 1f : 0f);
                    }
                    else
                    {
                        sensor.AddObservation(1f);
                        sensor.AddObservation(0f);
                    }
                }
                else
                {
                    sensor.AddObservation(0f);
                    sensor.AddObservation(0f);
                    sensor.AddObservation(1f);
                    sensor.AddObservation(0f);
                }
            }
            else
            {
                sensor.AddObservation(0f);
                sensor.AddObservation(1f);
                sensor.AddObservation(0f);
                sensor.AddObservation(0f);
                sensor.AddObservation(1f);
                sensor.AddObservation(0f);
            }
        }

        // 9. Raycast for target detection.
        float raycastLength = 10f;
        Ray ray = new Ray(transform.position + Vector3.up * 0.5f, transform.forward);
        if (Physics.Raycast(ray, out RaycastHit hit, raycastLength, perceptionSystem.targetLayer))
        {
            sensor.AddObservation(1f);
            sensor.AddObservation(hit.distance / raycastLength);
        }
        else
        {
            sensor.AddObservation(0f);
            sensor.AddObservation(1f);
        }

        // 10. Raycast for front opponent detection.
        if (Physics.Raycast(ray, out RaycastHit opponentHit, raycastLength, perceptionSystem.opponentLayer))
        {
            CustomAgent opponent = opponentHit.collider.GetComponent<CustomAgent>();
            if (opponent != null && opponent.teamID != this.teamID)
            {
                AgentHealthSystem opponentHealth = opponent.GetComponent<AgentHealthSystem>();
                AgentBlockSystem opponentBlock = opponent.GetComponent<AgentBlockSystem>();
                sensor.AddObservation(1f);
                sensor.AddObservation(opponentHit.distance / raycastLength);
                sensor.AddObservation(opponentHealth.currentHealth / opponentHealth.maxHealth);
                sensor.AddObservation(opponentBlock.isBlocking ? 1f : 0f);
            }
            else
            {
                sensor.AddObservation(0f);
                sensor.AddObservation(1f);
                sensor.AddObservation(1f);
                sensor.AddObservation(0f);
            }
        }
        else
        {
            sensor.AddObservation(0f);
            sensor.AddObservation(1f);
            sensor.AddObservation(1f);
            sensor.AddObservation(0f);
        }

        // --- Ability Observations (Slots: indices 79 to 90 = 12 values) ---
        // We want the last 12 observations (91 - 79 = 12) to be overwritten by abilities.
        int extraSlots = 91 - 79; // 12 extra observation slots for abilities
        if (abilityManager != null)
        {
            float[] abilityObs = abilityManager.GetAbilityObservations();
            // If the returned array has fewer than 12 values, fill the remainder with a neutral value (0.5)
            for (int i = 0; i < extraSlots; i++)
            {
                if (i < abilityObs.Length)
                    sensor.AddObservation(abilityObs[i]);
                else
                    sensor.AddObservation(0.5f);
            }
        }
        else
        {
            // If no ability manager is available, fill all 12 with neutral values.
            for (int i = 0; i < extraSlots; i++)
            {
                sensor.AddObservation(0.5f);
            }
        }
    }


    public override void OnActionReceived(ActionBuffers actions)
    {
        // Update attack cooldown timer.
        healthSystem.UpdateCooldowns();

        // Get block discrete action.
        int blockAction = actions.DiscreteActions[1];
        blockSystem.SetBlockState(blockAction == 1);

        // Get movement continuous actions (only when not blocking).
        float moveX = 0f;
        float moveZ = 0f;
        float rotateY = actions.ContinuousActions[2]; // Rotation.
        if (!blockSystem.isBlocking)
        {
            moveX = actions.ContinuousActions[0];
            moveZ = actions.ContinuousActions[1];
        }

        // Apply movement.
        movementSystem.Move(moveX, moveZ, rotateY);

        // Process attack discrete action.
        int attackAction = actions.DiscreteActions[0];
        if (attackAction == 1 && healthSystem.attackTimer <= 0 && !blockSystem.isBlocking)
        {
            // Find closest opponent.
            CustomAgent opponent = perceptionSystem.FindClosestOpponent();
            if (opponent != null)
            {
                Vector3 dirToOpponent = (opponent.transform.position - transform.position).normalized;
                float angleToOpponent = Vector3.Angle(transform.forward, dirToOpponent);
                float distanceToOpponent = Vector3.Distance(transform.position, opponent.transform.position);
                if (angleToOpponent <= 45f && distanceToOpponent <= healthSystem.attackRange)
                {
                    Vector3 attackPoint = opponent.transform.position;
                    healthSystem.TryAttack(opponent, attackPoint);
                }
                else
                {
                    // Opponent exists, but is not in the optimal range/angle.
                    AddReward(attackPenalty);
                    Debug.Log($"[Attack] Punishment applied: {attackPenalty} (Opponent not in proper range)");
                }
            }
            else
            {
                // No opponent found; apply punishment.
                AddReward(attackPenalty);
                Debug.Log($"[Attack] Punishment applied: {attackPenalty} (No opponent nearby)");
            }
        }

        // Log received actions.
        Debug.Log($"🚀 Agent {teamID} Action: X={moveX:F2}, Z={moveZ:F2}, Rotate={rotateY:F2}, Attack={attackAction}, Block={blockAction}");

        // Reward if agent is close enough to the target.
        float distance = Vector3.Distance(transform.localPosition, target.localPosition);
        if (distance < 1.5f)
        {
            SetReward(targetReachReward);
            Debug.Log($"🎯 Agent {teamID} reached target!");
            EndEpisode();
        }

        // Occasionally trigger an LLM simulation for adjustments.
        if (Random.Range(0, LLM_MUTATION_CHANCE) == 0 && llm != null)
        {
            llm.SimulateLLMCall(distance);
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var continuousActions = actionsOut.ContinuousActions;
        var discreteActions = actionsOut.DiscreteActions;

        // Movement via Horizontal and Vertical axes.
        continuousActions[0] = Input.GetAxis("Horizontal");
        continuousActions[1] = Input.GetAxis("Vertical");

        // Rotation via Q and E keys.
        if (Input.GetKey(KeyCode.Q))
            continuousActions[2] = -1.0f;
        else if (Input.GetKey(KeyCode.E))
            continuousActions[2] = 1.0f;
        else
            continuousActions[2] = 0f;

        // Attack (Space) and Block (B) discrete actions.
        discreteActions[0] = Input.GetKey(KeyCode.Space) ? 1 : 0;
        discreteActions[1] = Input.GetKey(KeyCode.B) ? 1 : 0;
    }
}
