using UnityEngine;

public class EnvironmentManager : MonoBehaviour
{
    public GameObject environmentPrefab;
    public int numberOfEnvironments = 4;
    public float spacing = 20f; // Spacing between each environment

    void Start()
    {
        for (int i = 0; i < numberOfEnvironments; i++)
        {
            // Arrange environments in a grid or line; here we use a line on the X-axis
            Vector3 spawnPosition = new Vector3(i * spacing, 0, 0);
            Instantiate(environmentPrefab, spawnPosition, Quaternion.identity, transform);
        }
    }
}
