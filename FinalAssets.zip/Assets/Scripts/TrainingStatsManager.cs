using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class TrainingStatsManager : MonoBehaviour
{
    public static TrainingStatsManager Instance { get; private set; }

    [System.Serializable]
    public class EpisodeStats
    {
        public int completedEpisodes;
        public float averageReward;
        public int successfulReaches;
        // Add other metrics if needed
    }

    public Dictionary<int, EpisodeStats> environmentStats = new Dictionary<int, EpisodeStats>();
    
    private void Awake()
    {
        if (Instance == null) {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else {
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// Records the result of an episode for the given environment id.
    /// </summary>
    public void RecordEpisodeResult(int environmentId, float reward, bool targetReached)
    {
        if (!environmentStats.ContainsKey(environmentId))
            environmentStats[environmentId] = new EpisodeStats();

        var stats = environmentStats[environmentId];
        stats.completedEpisodes++;
        stats.averageReward = ((stats.averageReward * (stats.completedEpisodes - 1)) + reward) / stats.completedEpisodes;
        if (targetReached)
            stats.successfulReaches++;
    }

    /// <summary>
    /// Resets all environment statistics.
    /// </summary>
    public void ResetStats()
    {
        environmentStats.Clear();
    }

    /// <summary>
    /// Exports the current statistics to a JSON string.
    /// </summary>
    public string ExportStatsToJson()
    {
        // Convert the dictionary to a list of serializable entries.
        List<EnvironmentStatsEntry> entries = new List<EnvironmentStatsEntry>();
        foreach (var kvp in environmentStats)
        {
            entries.Add(new EnvironmentStatsEntry { environmentId = kvp.Key, stats = kvp.Value });
        }

        // Wrap the list in a container.
        EnvironmentStatsWrapper wrapper = new EnvironmentStatsWrapper { statsList = entries };
        return JsonUtility.ToJson(wrapper, true);
    }

    /// <summary>
    /// Saves the current statistics JSON to a file at the specified path.
    /// </summary>
    public void SaveStatsToFile(string filePath)
    {
        string json = ExportStatsToJson();
        File.WriteAllText(filePath, json);
        Debug.Log("Training stats saved to: " + filePath);
    }

    // Helper class for serializing the dictionary of environment stats.
    [System.Serializable]
    private class EnvironmentStatsWrapper
    {
        public List<EnvironmentStatsEntry> statsList;
    }

    [System.Serializable]
    private class EnvironmentStatsEntry
    {
        public int environmentId;
        public EpisodeStats stats;
    }
}
