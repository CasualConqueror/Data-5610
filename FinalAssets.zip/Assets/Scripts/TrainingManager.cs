using UnityEngine;
using System.Collections.Generic;
using Unity.MLAgents;
using AgentKnowledgeSystem; // Correct namespace import

public class TrainingManager : MonoBehaviour
{
    public static TrainingManager Instance;

    [Header("Training Statistics")]
    public float totalDamageDealt;
    public int totalEpisodes;
    public int successfulEpisodes;

    [Header("Knowledge Sharing")]
    [SerializeField] private bool _useSharedKnowledge = true;
    [SerializeField] private float _knowledgeDecayInterval = 300f; // 5 minutes
    [SerializeField] private bool _debugLogging = false;
    private float _lastDecayTime;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        _lastDecayTime = Time.time;
    }

    private void Start()
    {
        // Initialize AgentKnowledgePoolManager if using shared knowledge
        if (_useSharedKnowledge)
        {
            InitializeKnowledgePool();
        }
    }

    private void Update()
    {
        // Apply decay to shared knowledge at regular intervals
        if (_useSharedKnowledge && Time.time - _lastDecayTime > _knowledgeDecayInterval)
        {
            AgentKnowledgePoolManager.Instance?.ApplyGlobalDecay();
            _lastDecayTime = Time.time;

            if (_debugLogging)
            {
                Debug.Log($"Applied knowledge decay at time {Time.time}");
            }
        }
    }

    /// <summary>
    /// Initialize the knowledge pool
    /// </summary>
    private void InitializeKnowledgePool()
    {
        // Ensure the knowledge pool manager exists
        AgentKnowledgePoolManager knowledgePoolManager = AgentKnowledgePoolManager.Instance;

        if (knowledgePoolManager != null)
        {
            if (_debugLogging)
            {
                Debug.Log("Knowledge pool initialized for training");
            }
        }
        else
        {
            // Create the knowledge pool manager if it doesn't exist
            GameObject poolManagerObj = new GameObject("AgentKnowledgePoolManager");
            poolManagerObj.AddComponent<AgentKnowledgePoolManager>();
            DontDestroyOnLoad(poolManagerObj);

            if (_debugLogging)
            {
                Debug.Log("Created new AgentKnowledgePoolManager");
            }
        }
    }

    /// <summary>
    /// Report damage to track global statistics and optionally add to the knowledge pool
    /// </summary>
    public void ReportDamage(float damage)
    {
        totalDamageDealt += damage;

        // If using shared knowledge, report to the knowledge pool
        if (_useSharedKnowledge && AgentKnowledgePoolManager.Instance != null)
        {
            int environmentId = (int)Academy.Instance.EnvironmentParameters.GetWithDefault("env_id", 0);

            // Report global damage event to all team pools
            ReportGlobalDamage(damage, environmentId);
        }
    }

    /// <summary>
    /// Report a global damage event to all team knowledge pools
    /// </summary>
    private void ReportGlobalDamage(float damage, int environmentId)
    {
        // Create a global damage record
        RewardRecord globalDamageRecord = new RewardRecord(
            Time.time,
            environmentId,
            0,  // Global event, not tied to a specific episode
            0,  // Global event, not tied to a specific agent
            damage * 0.01f,  // Convert damage to a small reward value
            "GlobalDamage"
        );

        // Add to all agent type pools
        foreach (int teamId in GetAllTeamIds())
        {
            AgentKnowledgePoolManager.Instance.AddRewardRecord(teamId, globalDamageRecord);
        }

        if (_debugLogging)
        {
            Debug.Log($"Reported global damage {damage} to all team pools");
        }
    }


    /// <summary>
    /// Get all team IDs from the registry
    /// </summary>
    private List<int> GetAllTeamIds()
    {
        if (AgentRegistry.Instance == null)
            return new List<int>();

        HashSet<int> teamIds = new HashSet<int>();

        // Get all registered agents
        List<CustomAgent> allAgents = AgentRegistry.Instance.GetAllAgents();

        // Extract unique team IDs
        foreach (var agent in allAgents)
        {
            if (agent != null)
            {
                teamIds.Add(agent.teamID);
            }
        }

        return new List<int>(teamIds);
    }

    /// <summary>
    /// Called at the end of an episode to analyze training data
    /// </summary>
    public void OnEpisodeEnd(int environmentId, int episodeId)
    {
        totalEpisodes++;

        // Example: Analyze pooled knowledge to adjust training parameters
        if (_useSharedKnowledge && AgentKnowledgePoolManager.Instance != null)
        {
            AnalyzePooledKnowledge();
        }

        // Export knowledge periodically
        if (_useSharedKnowledge && totalEpisodes % 100 == 0)
        {
            AgentKnowledgePoolManager.Instance?.ExportAllKnowledgePools();
        }
    }

    /// <summary>
    /// Analyze pooled knowledge to potentially adjust training parameters
    /// </summary>
    private void AnalyzePooledKnowledge()
    {
        if (AgentKnowledgePoolManager.Instance == null)
            return;

        foreach (int teamId in GetAllTeamIds())
        {
            // Get statistics for this team
            Dictionary<string, float> stats =
                AgentKnowledgePoolManager.Instance.GetKnowledgePool(teamId).GetAllStatistics();

            // Get action-specific reward statistics
            RewardStatistics attackStats =
                AgentKnowledgePoolManager.Instance.GetRewardStatisticsForAction(teamId, "Attack");
            RewardStatistics blockStats =
                AgentKnowledgePoolManager.Instance.GetRewardStatisticsForAction(teamId, "Block");

            if (_debugLogging)
            {
                Debug.Log($"Team {teamId} - Avg reward: {stats["AvgReward"]:F2}, " +
                          $"Attack effectiveness: {attackStats.AverageReward:F2}, " +
                          $"Block effectiveness: {blockStats.AverageReward:F2}");
            }

            // You could use these statistics to adjust training parameters
            // For example, increase attack damage if attacks are rarely successful
            // or modify block effectiveness based on pooled knowledge
        }
    }

    /// <summary>
    /// Record a successful episode
    /// </summary>
    public void RecordSuccessfulEpisode()
    {
        successfulEpisodes++;
    }

    /// <summary>
    /// Reset all training statistics
    /// </summary>
    public void ResetTrainingStats()
    {
        totalDamageDealt = 0;
        totalEpisodes = 0;
        successfulEpisodes = 0;

        // Clear knowledge pools if using shared knowledge
        if (_useSharedKnowledge && AgentKnowledgePoolManager.Instance != null)
        {
            AgentKnowledgePoolManager.Instance.ClearAllKnowledgePools();
        }
    }
}