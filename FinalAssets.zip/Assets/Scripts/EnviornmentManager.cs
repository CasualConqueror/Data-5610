using UnityEngine;
using System.Collections;

public class EnvironmentManager : MonoBehaviour
{
    public GameObject environmentPrefab;
    public int numberOfEnvironments = 4;
    public float spacing = 20f; // Spacing between each environment
    public bool debugMode = true; // Enable for additional debugging information

    void Start()
    {
        if (environmentPrefab == null)
        {
            Debug.LogError("[EnvironmentManager] Environment prefab is not assigned! Please assign it in the inspector.");
            return;
        }

        StartCoroutine(WaitForSingletonsAndCreateEnvironments());
    }

    private IEnumerator WaitForSingletonsAndCreateEnvironments()
    {
        int attempts = 0;
        int maxAttempts = 10;

        // Wait until both singletons exist, with a maximum number of attempts
        while ((AgentRegistry.Instance == null || AgentEventSystem.Instance == null) && attempts < maxAttempts)
        {
            if (debugMode)
            {
                Debug.LogWarning($"[EnvironmentManager] Waiting for singletons to initialize... Attempt {attempts+1}/{maxAttempts}");
                Debug.LogWarning($"[EnvironmentManager] AgentRegistry.Instance: {(AgentRegistry.Instance != null ? "Found" : "Not Found")}");
                Debug.LogWarning($"[EnvironmentManager] AgentEventSystem.Instance: {(AgentEventSystem.Instance != null ? "Found" : "Not Found")}");
            }

            attempts++;
            yield return new WaitForSeconds(0.5f);
        }

        // Check if we found the singletons
        if (AgentRegistry.Instance == null || AgentEventSystem.Instance == null)
        {
            Debug.LogError("[EnvironmentManager] Required singletons not found after maximum attempts. Cannot create environments.");
            yield break;
        }

        // Now create environments
        if (debugMode)
        {
            Debug.LogWarning($"[EnvironmentManager] Creating {numberOfEnvironments} environments with spacing {spacing}");
        }

        // First, make sure any previous environment children are removed
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            DestroyImmediate(transform.GetChild(i).gameObject);
        }

        // Create new environments
        for (int i = 0; i < numberOfEnvironments; i++)
        {
            // Arrange environments in a grid or line; here we use a line on the X-axis
            Vector3 spawnPosition = new Vector3(i * spacing, 0, 0);

            try
            {
                GameObject environment = Instantiate(environmentPrefab, spawnPosition, Quaternion.identity);

                // Explicitly set parent after instantiation to ensure proper parenting
                environment.transform.SetParent(this.transform, false);

                if (debugMode)
                {
                    Debug.LogWarning($"[EnvironmentManager] Created environment {i+1} at position {spawnPosition}");
                    environment.name = $"Environment_{i+1}";
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[EnvironmentManager] Failed to create environment {i+1}: {e.Message}");
            }
        }

        // Verify environments were actually created
        if (transform.childCount > 0)
        {
            Debug.LogWarning($"[EnvironmentManager] Successfully created {transform.childCount} environments as children");
        }
        else
        {
            Debug.LogError("[EnvironmentManager] Failed to create any environments as children!");
        }
    }
}