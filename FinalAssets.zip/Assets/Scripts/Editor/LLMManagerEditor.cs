using UnityEngine;
using UnityEditor;
using System;  // Add this for Action<T>

/// <summary>
/// Custom editor for the LLMManager to provide a better interface in the Unity Inspector
/// </summary>
[CustomEditor(typeof(LLMManager))]
public class LLMManagerEditor : Editor
{
    // Serialized properties
    private SerializedProperty enableLLMIntegration;
    private SerializedProperty observationBatchSize;
    private SerializedProperty logObservationsToFile;
    private SerializedProperty logFilePath;
    private SerializedProperty detailedLogging;

    private SerializedProperty maxStoredEventsPerType;
    private SerializedProperty maxAgentsTracked;

    private SerializedProperty abilityTemplateFolder;
    private SerializedProperty abilityGenerationInterval;
    private SerializedProperty useRandomAbilityVariations;

    private SerializedProperty defensiveAbilityTemplate;
    private SerializedProperty offensiveAbilityTemplate;
    private SerializedProperty utilityAbilityTemplate;

    private SerializedProperty autoGenerateTemplates;
    private SerializedProperty templatesFolder;

    private SerializedProperty useActualLLMAPI;
    private SerializedProperty apiKey;
    private SerializedProperty apiEndpoint;
    private SerializedProperty modelName;
    private SerializedProperty temperature;
    private SerializedProperty maxTokens;
    private SerializedProperty maxDailyCost;

    private SerializedProperty abilityReplacementThreshold;
    private SerializedProperty requestNewAbilityThreshold;

    // Foldout states
    private bool showLLMIntegrationSettings = true;
    private bool showEventSamplingSettings = false;
    private bool showAbilityGenerationSettings = true;
    private bool showAbilityTemplateSettings = false;
    private bool showAPISettings = true;
    private bool showEffectivenessSettings = false;

    // Custom styles
    private GUIStyle headerStyle;
    private GUIStyle sectionStyle;
    private GUIStyle warningStyle;

    private void OnEnable()
    {
        // Find all serialized properties
        enableLLMIntegration = serializedObject.FindProperty("_enableLLMIntegration");
        observationBatchSize = serializedObject.FindProperty("_observationBatchSize");
        logObservationsToFile = serializedObject.FindProperty("_logObservationsToFile");
        logFilePath = serializedObject.FindProperty("_logFilePath");
        detailedLogging = serializedObject.FindProperty("_detailedLogging");

        maxStoredEventsPerType = serializedObject.FindProperty("_maxStoredEventsPerType");
        maxAgentsTracked = serializedObject.FindProperty("_maxAgentsTracked");

        abilityTemplateFolder = serializedObject.FindProperty("_abilityTemplateFolder");
        abilityGenerationInterval = serializedObject.FindProperty("_abilityGenerationInterval");
        useRandomAbilityVariations = serializedObject.FindProperty("_useRandomAbilityVariations");

        defensiveAbilityTemplate = serializedObject.FindProperty("_defensiveAbilityTemplate");
        offensiveAbilityTemplate = serializedObject.FindProperty("_offensiveAbilityTemplate");
        utilityAbilityTemplate = serializedObject.FindProperty("_utilityAbilityTemplate");

        autoGenerateTemplates = serializedObject.FindProperty("_autoGenerateTemplates");
        templatesFolder = serializedObject.FindProperty("_templatesFolder");

        useActualLLMAPI = serializedObject.FindProperty("_useActualLLMAPI");
        apiKey = serializedObject.FindProperty("_apiKey");
        apiEndpoint = serializedObject.FindProperty("_apiEndpoint");
        modelName = serializedObject.FindProperty("_modelName");
        temperature = serializedObject.FindProperty("_temperature");
        maxTokens = serializedObject.FindProperty("_maxTokens");
        maxDailyCost = serializedObject.FindProperty("_maxDailyCost");

        abilityReplacementThreshold = serializedObject.FindProperty("_abilityReplacementThreshold");
        requestNewAbilityThreshold = serializedObject.FindProperty("_requestNewAbilityThreshold");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        // Initialize custom styles
        InitializeStyles();

        // Main title
        EditorGUILayout.LabelField("LLM Manager Settings", headerStyle);
        EditorGUILayout.Space();

        // LLM Integration Settings
        showLLMIntegrationSettings = EditorGUILayout.Foldout(showLLMIntegrationSettings, "LLM Integration Settings", true, sectionStyle);
        if (showLLMIntegrationSettings)
        {
            EditorGUI.indentLevel++;

            EditorGUILayout.PropertyField(enableLLMIntegration, new GUIContent("Enable LLM Integration"));
            EditorGUILayout.PropertyField(observationBatchSize, new GUIContent("Observation Batch Size"));
            EditorGUILayout.PropertyField(logObservationsToFile, new GUIContent("Log Observations To File"));

            if (logObservationsToFile.boolValue)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(logFilePath, new GUIContent("Log File Path"));
                EditorGUILayout.PropertyField(detailedLogging, new GUIContent("Detailed Logging"));
                EditorGUI.indentLevel--;
            }

            EditorGUI.indentLevel--;
        }

        EditorGUILayout.Space();

        // Event Sampling Settings
        showEventSamplingSettings = EditorGUILayout.Foldout(showEventSamplingSettings, "Event Sampling Settings", true, sectionStyle);
        if (showEventSamplingSettings)
        {
            EditorGUI.indentLevel++;

            EditorGUILayout.PropertyField(maxStoredEventsPerType, new GUIContent("Max Stored Events Per Type"));
            EditorGUILayout.PropertyField(maxAgentsTracked, new GUIContent("Max Agents Tracked"));

            EditorGUI.indentLevel--;
        }

        EditorGUILayout.Space();

        // Ability Generation Settings
        showAbilityGenerationSettings = EditorGUILayout.Foldout(showAbilityGenerationSettings, "Ability Generation Settings", true, sectionStyle);
        if (showAbilityGenerationSettings)
        {
            EditorGUI.indentLevel++;

            EditorGUILayout.PropertyField(abilityTemplateFolder, new GUIContent("Ability Template Folder"));
            EditorGUILayout.PropertyField(abilityGenerationInterval, new GUIContent("Ability Generation Interval (seconds)"));
            EditorGUILayout.PropertyField(useRandomAbilityVariations, new GUIContent("Use Random Ability Variations"));

            EditorGUI.indentLevel--;
        }

        EditorGUILayout.Space();

        // Ability Template Settings
        showAbilityTemplateSettings = EditorGUILayout.Foldout(showAbilityTemplateSettings, "Ability Template Settings", true, sectionStyle);
        if (showAbilityTemplateSettings)
        {
            EditorGUI.indentLevel++;

            EditorGUILayout.PropertyField(defensiveAbilityTemplate, new GUIContent("Defensive Ability Template"));
            EditorGUILayout.PropertyField(offensiveAbilityTemplate, new GUIContent("Offensive Ability Template"));
            EditorGUILayout.PropertyField(utilityAbilityTemplate, new GUIContent("Utility Ability Template"));

            EditorGUILayout.Space();

            EditorGUILayout.PropertyField(autoGenerateTemplates, new GUIContent("Auto-Generate Templates"));
            if (autoGenerateTemplates.boolValue)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(templatesFolder, new GUIContent("Templates Folder"));
                EditorGUI.indentLevel--;
            }

            EditorGUI.indentLevel--;
        }

        EditorGUILayout.Space();

        // API Settings
        showAPISettings = EditorGUILayout.Foldout(showAPISettings, "LLM API Settings", true, sectionStyle);
        if (showAPISettings)
        {
            EditorGUI.indentLevel++;

            EditorGUILayout.PropertyField(useActualLLMAPI, new GUIContent("Use Actual LLM API"));

            if (useActualLLMAPI.boolValue)
            {
                EditorGUI.indentLevel++;

                // API Key handling with enhanced security
                string displayKey = string.IsNullOrEmpty(apiKey.stringValue) ? "" : new string('*', apiKey.stringValue.Length);
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.PrefixLabel("API Key");

                if (GUILayout.Button("Edit", GUILayout.Width(50)))
                {
                    // Show a dialog to enter the API key
                    string newKey = EditorInputDialog.Show("Enter API Key", "Enter your LLM API Key:", apiKey.stringValue);
                    if (!string.IsNullOrEmpty(newKey))
                    {
                        apiKey.stringValue = newKey;
                        LLMManager manager = (LLMManager)target;
                        manager.SaveAPIKey(newKey);
                    }
                }

                EditorGUILayout.LabelField(displayKey);
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.PropertyField(apiEndpoint, new GUIContent("API Endpoint"));
                EditorGUILayout.PropertyField(modelName, new GUIContent("Model Name"));
                EditorGUILayout.Slider(temperature, 0f, 1f, new GUIContent("Temperature"));
                EditorGUILayout.PropertyField(maxTokens, new GUIContent("Max Tokens"));
                EditorGUILayout.PropertyField(maxDailyCost, new GUIContent("Max Daily Cost (USD)"));

                if (string.IsNullOrEmpty(apiKey.stringValue))
                {
                    EditorGUILayout.HelpBox("API Key is required to use the actual LLM API.", MessageType.Warning);
                }

                EditorGUI.indentLevel--;
            }

            EditorGUI.indentLevel--;
        }

        EditorGUILayout.Space();

        // Effectiveness Threshold Settings
        showEffectivenessSettings = EditorGUILayout.Foldout(showEffectivenessSettings, "Effectiveness Threshold Settings", true, sectionStyle);
        if (showEffectivenessSettings)
        {
            EditorGUI.indentLevel++;

            EditorGUILayout.Slider(abilityReplacementThreshold, 0f, 1f, new GUIContent("Ability Replacement Threshold"));
            EditorGUILayout.Slider(requestNewAbilityThreshold, 0f, 1f, new GUIContent("Request New Ability Threshold"));

            if (abilityReplacementThreshold.floatValue >= requestNewAbilityThreshold.floatValue)
            {
                EditorGUILayout.HelpBox("Ability Replacement Threshold should be lower than Request New Ability Threshold.", MessageType.Warning);
            }

            EditorGUI.indentLevel--;
        }

        serializedObject.ApplyModifiedProperties();
    }

    private void InitializeStyles()
    {
        if (headerStyle == null)
        {
            headerStyle = new GUIStyle(EditorStyles.boldLabel);
            headerStyle.fontSize = 14;
            headerStyle.alignment = TextAnchor.MiddleCenter;
            headerStyle.margin = new RectOffset(0, 0, 10, 10);
        }

        if (sectionStyle == null)
        {
            sectionStyle = new GUIStyle(EditorStyles.foldout);
            sectionStyle.fontStyle = FontStyle.Bold;
        }

        if (warningStyle == null)
        {
            warningStyle = new GUIStyle(EditorStyles.helpBox);
            warningStyle.normal.textColor = Color.red;
        }
    }
}

/// <summary>
/// Utility class for showing input dialogs in the editor
/// </summary>
public class EditorInputDialog : EditorWindow
{
    private string dialogTitle = "";  // Renamed from title to avoid warning
    private string message = "";
    private string inputText = "";
    private bool isCancelled = false;

    public static string Show(string title, string message, string defaultText = "")
    {
        EditorInputDialog window = CreateInstance<EditorInputDialog>();
        window.dialogTitle = title;  // Use the renamed field
        window.message = message;
        window.inputText = defaultText;
        window.position = new Rect(Screen.currentResolution.width / 2, Screen.currentResolution.height / 2, 300, 120);
        window.ShowModalUtility();

        return window.isCancelled ? null : window.inputText;
    }

    private void OnGUI()
    {
        EditorGUILayout.LabelField(dialogTitle, EditorStyles.boldLabel);  // Use the renamed field
        EditorGUILayout.Space();
        EditorGUILayout.LabelField(message);

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("", GUILayout.Width(10));
        inputText = EditorGUILayout.TextField(inputText, GUILayout.ExpandWidth(true));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space();

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Cancel"))
        {
            isCancelled = true;
            Close();
        }

        if (GUILayout.Button("OK"))
        {
            isCancelled = false;
            Close();
        }
        EditorGUILayout.EndHorizontal();
    }
}