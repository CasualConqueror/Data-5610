using UnityEngine;
using System.Collections.Generic;
using Unity.MLAgents;
using System;
using System.IO;
using AgentKnowledgeSystem;

public class CurriculumLearningManager : MonoBehaviour
    {
        // Singleton instance
        private static CurriculumLearningManager _instance;

        [Header("Agent Registration")]
        [SerializeField] private bool _autoRegisterAgents = true;
        [SerializeField] private float _scanInterval = 5f;

        [Header("Curriculum Settings")]
        [SerializeField] private bool _enableProgressiveComplexity = true;
        [SerializeField] private int _episodesPerProgressCheck = 20;

        [Header("Training Analytics")]
        [SerializeField] private bool _enableAnalytics = true;
        [SerializeField] private string _analyticsPath = "TrainingAnalytics";
        [SerializeField] private float _analyticsUpdateInterval = 60f; // 1 minute

        [Header("Team Settings")]
        [SerializeField] private int _team1Id = 1; // Evader/Target Reacher
        [SerializeField] private int _team2Id = 2; // Hunter/Attacker

        // Tracking of all agents by team
        private Dictionary<int, List<CustomAgent>> _teamAgents = new Dictionary<int, List<CustomAgent>>();

        // Tracking environment IDs
        private int _environmentId = 0;

        // Performance metrics
        private Dictionary<int, float> _teamAverageRewards = new Dictionary<int, float>();
        private Dictionary<int, int> _teamEpisodeCompletions = new Dictionary<int, int>();
        private Dictionary<int, float> _teamSuccessRates = new Dictionary<int, float>();

        // Timers
        private float _lastScanTime = 0f;
        private float _lastAnalyticsTime = 0f;
        private int _currentEpisodeCheck = 0;

        public static CurriculumLearningManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = FindObjectOfType<CurriculumLearningManager>();

                    if (_instance == null)
                    {
                        GameObject go = new GameObject("CurriculumLearningManager");
                        _instance = go.AddComponent<CurriculumLearningManager>();
                        DontDestroyOnLoad(go);
                    }
                }
                return _instance;
            }
        }

        private void Awake()
        {
            // Ensure singleton behavior
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }

            _instance = this;
            DontDestroyOnLoad(gameObject);

            // Initialize ALL dictionaries with both team IDs
            _teamAgents = new Dictionary<int, List<CustomAgent>>();
            _teamAverageRewards = new Dictionary<int, float>();
            _teamEpisodeCompletions = new Dictionary<int, int>();
            _teamSuccessRates = new Dictionary<int, float>();

            // Initialize team agents lists
            _teamAgents[_team1Id] = new List<CustomAgent>();
            _teamAgents[_team2Id] = new List<CustomAgent>();

            // Initialize metrics for team 1
            _teamAverageRewards[_team1Id] = 0f;
            _teamEpisodeCompletions[_team1Id] = 0;
            _teamSuccessRates[_team1Id] = 0f;

            // Initialize metrics for team 2
            _teamAverageRewards[_team2Id] = 0f;
            _teamEpisodeCompletions[_team2Id] = 0;
            _teamSuccessRates[_team2Id] = 0f;

            // Get environment ID from Academy parameters
            _environmentId = (int)Academy.Instance.EnvironmentParameters.GetWithDefault("env_id", 0);

            Debug.Log($"Curriculum Learning Manager initialized for environment {_environmentId}");
        }

        private void Start()
        {
            if (_autoRegisterAgents)
            {
                ScanAndRegisterAgents();
            }

            // Create analytics directory if needed
            if (_enableAnalytics)
            {
                string directoryPath = Path.Combine(Application.persistentDataPath, _analyticsPath);
                Directory.CreateDirectory(directoryPath);
            }
        }

        private void Update()
        {
            // Periodically scan for new agents if auto-registration is enabled
            if (_autoRegisterAgents && Time.time - _lastScanTime > _scanInterval)
            {
                ScanAndRegisterAgents();
                _lastScanTime = Time.time;
            }

            // Generate analytics regularly
            if (_enableAnalytics && Time.time - _lastAnalyticsTime > _analyticsUpdateInterval)
            {
                RecordAnalytics();
                _lastAnalyticsTime = Time.time;
            }
        }

        /// <summary>
        /// Scans the scene for agents and registers them with the curriculum system
        /// </summary>
        private void ScanAndRegisterAgents()
        {
            // Ensure the dictionary entries exist
            if (!_teamAgents.ContainsKey(_team1Id))
                _teamAgents[_team1Id] = new List<CustomAgent>();
            if (!_teamAgents.ContainsKey(_team2Id))
                _teamAgents[_team2Id] = new List<CustomAgent>();

            // Clear previous lists
            _teamAgents[_team1Id].Clear();
            _teamAgents[_team2Id].Clear();

            // Find all agents in the scene
            CustomAgent[] agents = FindObjectsOfType<CustomAgent>();

            foreach (CustomAgent agent in agents)
            {
                // Register with appropriate team
                if (agent.teamID == _team1Id)
                {
                    _teamAgents[_team1Id].Add(agent);
                }
                else if (agent.teamID == _team2Id)
                {
                    _teamAgents[_team2Id].Add(agent);
                }
            }

            Debug.Log($"Registered {_teamAgents[_team1Id].Count} Team 1 agents and " +
                     $"{_teamAgents[_team2Id].Count} Team 2 agents");
        }

        /// <summary>
        /// Manually register an agent with the curriculum system
        /// </summary>
        public void RegisterAgent(CustomAgent agent)
        {
            if (agent.teamID == _team1Id)
            {
                if (!_teamAgents[_team1Id].Contains(agent))
                {
                    _teamAgents[_team1Id].Add(agent);
                    Debug.Log($"Manually registered Team 1 agent {agent.agentId}");
                }
            }
            else if (agent.teamID == _team2Id)
            {
                if (!_teamAgents[_team2Id].Contains(agent))
                {
                    _teamAgents[_team2Id].Add(agent);
                    Debug.Log($"Manually registered Team 2 agent {agent.agentId}");
                }
            }
        }

        /// <summary>
        /// Reports an episode completion for tracking and curriculum progression
        /// </summary>
        public void ReportEpisodeCompletion(int teamId, float reward, bool success)
        {
            // Update team statistics
            _teamEpisodeCompletions[teamId]++;

            // Update running average reward
            float currentAvg = _teamAverageRewards[teamId];
            int completions = _teamEpisodeCompletions[teamId];
            _teamAverageRewards[teamId] = ((currentAvg * (completions - 1)) + reward) / completions;

            // Update success rate
            if (success)
            {
                float currentSuccess = _teamSuccessRates[teamId];
                _teamSuccessRates[teamId] = ((currentSuccess * (completions - 1)) + 1f) / completions;
            }

            // Check for curriculum progression
            _currentEpisodeCheck++;
            if (_enableProgressiveComplexity && _currentEpisodeCheck >= _episodesPerProgressCheck)
            {
                CheckCurriculumProgression();
                _currentEpisodeCheck = 0;
            }

            // Log progress
            Debug.Log($"Team {teamId} - Episode completed: reward={reward:F2}, success={success}, " +
                     $"avg reward={_teamAverageRewards[teamId]:F2}, success rate={_teamSuccessRates[teamId]:F2}");
        }

        /// <summary>
        /// Checks if curriculum progression should occur
        /// </summary>
        private void CheckCurriculumProgression()
        {
            if (AgentKnowledgePoolManager.Instance == null)
                return;

            // Get the current stage for each team
            var team1Pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(_team1Id);
            var team2Pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(_team2Id);

            // Retrieve current curriculum stages
            var team1Stage = team1Pool.CurrentStage;
            var team2Stage = team2Pool.CurrentStage;

            // Force re-evaluation of progression thresholds
            team1Pool.UpdateCurriculumStage();
            team2Pool.UpdateCurriculumStage();

            // Update environment complexity if stages have changed
            if (team1Stage != team1Pool.CurrentStage || team2Stage != team2Pool.CurrentStage)
            {
                UpdateEnvironmentComplexity();
            }

            // Trigger a performance balance check
            if (AgentKnowledgePoolManager.Instance != null)
            {
                AgentKnowledgePoolManager.Instance.BalanceTeamPerformance();
            }
        }

        /// <summary>
        /// Updates environment complexity based on curriculum stages
        /// </summary>
        private void UpdateEnvironmentComplexity()
        {
            if (AgentKnowledgePoolManager.Instance == null)
                return;

            // Get the current stage for each team
            var team1Pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(_team1Id);
            var team2Pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(_team2Id);

            // Apply team-specific ML-Agent reward function adjustments
            AgentKnowledgePoolManager.Instance.ConfigureRewardComplexity(_team1Id, team1Pool.CurrentStage);
            AgentKnowledgePoolManager.Instance.ConfigureRewardComplexity(_team2Id, team2Pool.CurrentStage);

            // Update all registered agents with new curriculum information
            UpdateAllAgents();

            // Trigger experience replay to reinforce successful strategies
            AgentKnowledgePoolManager.Instance.TriggerExperienceReplay();

            Debug.Log($"Updated environment complexity: Team 1 stage = {team1Pool.CurrentStage}, " +
                     $"Team 2 stage = {team2Pool.CurrentStage}");
        }

        /// <summary>
        /// Updates all registered agents with new curriculum settings
        /// </summary>
        private void UpdateAllAgents()
        {
            // Update Team 1 agents (Evaders/Target Reachers)
            foreach (CustomAgent agent in _teamAgents[_team1Id])
            {
                // Get the agent's health and block systems
                AgentHealthSystem healthSystem = agent.GetComponent<AgentHealthSystem>();
                AgentBlockSystem blockSystem = agent.GetComponent<AgentBlockSystem>();

                // Apply learned strategies
                if (healthSystem != null)
                    healthSystem.ApplyLearnedStrategies();

                if (blockSystem != null)
                    blockSystem.ApplyLearnedStrategies();
            }

            // Update Team 2 agents (Hunters/Attackers)
            foreach (CustomAgent agent in _teamAgents[_team2Id])
            {
                // Get the agent's health and block systems
                AgentHealthSystem healthSystem = agent.GetComponent<AgentHealthSystem>();
                AgentBlockSystem blockSystem = agent.GetComponent<AgentBlockSystem>();

                // Apply learned strategies
                if (healthSystem != null)
                    healthSystem.ApplyLearnedStrategies();

                if (blockSystem != null)
                    blockSystem.ApplyLearnedStrategies();
            }
        }

        /// <summary>
        /// Records analytics data for training progress
        /// </summary>
        private void RecordAnalytics()
        {
            if (!_enableAnalytics)
                return;

            // Create analytics data object
            TrainingAnalytics analytics = new TrainingAnalytics()
            {
                timestamp = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                environmentId = _environmentId,
                team1Agents = _teamAgents[_team1Id].Count,
                team2Agents = _teamAgents[_team2Id].Count,
                team1EpisodeCompletions = _teamEpisodeCompletions[_team1Id],
                team2EpisodeCompletions = _teamEpisodeCompletions[_team2Id],
                team1AvgReward = _teamAverageRewards[_team1Id],
                team2AvgReward = _teamAverageRewards[_team2Id],
                team1SuccessRate = _teamSuccessRates[_team1Id],
                team2SuccessRate = _teamSuccessRates[_team2Id]
            };

            // Get curriculum stages if available
            if (AgentKnowledgePoolManager.Instance != null)
            {
                var team1Pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(_team1Id);
                var team2Pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(_team2Id);

                analytics.team1CurriculumStage = (int)team1Pool.CurrentStage;
                analytics.team2CurriculumStage = (int)team2Pool.CurrentStage;
            }

            // Save to file
            string filePath = Path.Combine(Application.persistentDataPath, _analyticsPath,
                                          $"analytics_{_environmentId}_{System.DateTime.Now:yyyyMMdd_HHmmss}.json");

            string json = JsonUtility.ToJson(analytics, true);
            File.WriteAllText(filePath, json);

            Debug.Log($"Recorded training analytics to {filePath}");
        }

        /// <summary>
        /// Gets the current curriculum stage for a specific team
        /// </summary>
        public AgentKnowledgePool.CurriculumStage GetCurrentStage(int teamId)
        {
            if (AgentKnowledgePoolManager.Instance == null)
                return AgentKnowledgePool.CurriculumStage.Initial;

            return AgentKnowledgePoolManager.Instance.GetKnowledgePool(teamId).CurrentStage;
        }

        /// <summary>
        /// Applies a cross-learning update to transfer knowledge between environments
        /// </summary>
        public void ApplyCrossEnvironmentLearning()
        {
            if (AgentKnowledgePoolManager.Instance == null)
                return;

            // Trigger adversarial learning
            AgentKnowledgePoolManager.Instance.EnableAdversarialLearning();

            // Apply global decay to ensure fresh data has more influence
            AgentKnowledgePoolManager.Instance.ApplyGlobalDecay();

            // Update all agents with cross-environment learning
            UpdateAllAgents();

            Debug.Log("Applied cross-environment learning update");
        }
    }

/// <summary>
/// Simple data class for tracking training analytics
/// </summary>
[System.Serializable]
    public class TrainingAnalytics
        {
            // Timestamp when analytics were recorded
            public string timestamp;

            // Unique identifier for the training environment
            public int environmentId;

            // Agent population counts
            public int team1Agents;
            public int team2Agents;

            // Episode completion statistics
            public int team1EpisodeCompletions;
            public int team2EpisodeCompletions;

            // Performance metrics
            public float team1AvgReward;
            public float team2AvgReward;
            public float team1SuccessRate;
            public float team2SuccessRate;

            // Curriculum progress
            public int team1CurriculumStage;
            public int team2CurriculumStage;

            // Extended metrics for deeper analysis
            public float team1AvgCompletionTime;  // Average time to complete episodes
            public float team2AvgCompletionTime;

            // Combat statistics
            public float team1AvgDamageDealt;
            public float team2AvgDamageDealt;
            public float team1AvgDamageTaken;
            public float team2AvgDamageTaken;

            // Spatial metrics
            public float team1AvgDistanceTraveled;
            public float team2AvgDistanceTraveled;

            // Learning metrics
            public float team1KnowledgePoolSize;  // Number of observations in pool
            public float team2KnowledgePoolSize;
            public float team1SelectivityRate;    // Percentage of observations accepted
            public float team2SelectivityRate;

            // Default constructor initializes timestamp to current time
            public TrainingAnalytics()
            {
                timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            }

            /// <summary>
            /// Creates a formatted string representation of key analytics
            /// </summary>
            public override string ToString()
            {
                return $"Analytics [{timestamp}] Environment: {environmentId}\n" +
                       $"Team 1 ({team1Agents} agents): Stage {team1CurriculumStage}, " +
                       $"Reward {team1AvgReward:F2}, Success {team1SuccessRate:P2}\n" +
                       $"Team 2 ({team2Agents} agents): Stage {team2CurriculumStage}, " +
                       $"Reward {team2AvgReward:F2}, Success {team2SuccessRate:P2}";
            }

            /// <summary>
            /// Calculates the performance disparity between teams
            /// </summary>
            public float GetPerformanceDisparity()
            {
                // Calculate normalized reward disparity
                float rewardDisparity = Mathf.Abs(team1AvgReward - team2AvgReward) /
                                       Mathf.Max(0.1f, Mathf.Max(Mathf.Abs(team1AvgReward),
                                                                Mathf.Abs(team2AvgReward)));

                // Calculate success rate disparity
                float successDisparity = Mathf.Abs(team1SuccessRate - team2SuccessRate);

                // Combine metrics with weightings
                return (rewardDisparity * 0.7f) + (successDisparity * 0.3f);
            }

            /// <summary>
            /// Determines if dynamic difficulty adjustment is needed
            /// </summary>
            public bool NeedsDifficultyAdjustment(float disparityThreshold = 0.3f)
            {
                return GetPerformanceDisparity() > disparityThreshold;
            }

            /// <summary>
            /// Identifies which team is underperforming
            /// </summary>
            public int GetUnderperformingTeamId()
            {
                // Consider both reward and success rate with weighting
                float team1Performance = (team1AvgReward * 0.7f) + (team1SuccessRate * 0.3f);
                float team2Performance = (team2AvgReward * 0.7f) + (team2SuccessRate * 0.3f);

                return (team1Performance < team2Performance) ? 1 : 2;
            }

            /// <summary>
            /// Exports analytics to a formatted JSON string
            /// </summary>
            public string ToJson()
            {
                return JsonUtility.ToJson(this, true);
            }

            /// <summary>
            /// Creates a TrainingAnalytics object from JSON
            /// </summary>
            public static TrainingAnalytics FromJson(string json)
            {
                try
                {
                    return JsonUtility.FromJson<TrainingAnalytics>(json);
                }
                catch (Exception e)
                {
                    Debug.LogError($"Failed tos parse TrainingAnalytics from JSON: {e.Message}");
                    return new TrainingAnalytics();
                }
            }
        }