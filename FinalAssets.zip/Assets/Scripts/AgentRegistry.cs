using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Centralized registry for all agents in the environment to facilitate
/// efficient agent-to-agent communication without requiring visual contact.
/// </summary>
public class AgentRegistry : MonoBehaviour
{
    // Singleton pattern
    public static AgentRegistry Instance { get; private set; }

    // Dictionary to track all agents by their unique IDs
    private Dictionary<int, CustomAgent> agentsById = new Dictionary<int, CustomAgent>();

    // Dictionary to track agents by team
    private Dictionary<int, List<CustomAgent>> agentsByTeam = new Dictionary<int, List<CustomAgent>>();

    // Optional: Spatial partitioning for faster proximity queries
    private Dictionary<Vector2Int, List<CustomAgent>> spatialGrid = new Dictionary<Vector2Int, List<CustomAgent>>();
    private float gridCellSize = 5f; // Size of each spatial grid cell

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }


    /// <summary>
    /// Gets all registered agents
    /// </summary>
    public List<CustomAgent> GetAllAgents()
    {
        List<CustomAgent> result = new List<CustomAgent>();
        foreach (var agent in agentsById.Values)
        {
            if (agent != null)
            {
                result.Add(agent);
            }
        }
        return result;
    }

    public CustomAgent GetAgentById(int agentId)
    {
        if (agentsById.ContainsKey(agentId))
            return agentsById[agentId];
        return null;
    }


    /// <summary>
    /// Register an agent with the registry.
    /// </summary>
    public void RegisterAgent(CustomAgent agent, int agentId)
    {
        // Register by ID
        if (!agentsById.ContainsKey(agentId))
            agentsById.Add(agentId, agent);
        else
            agentsById[agentId] = agent;

        // Register by team
        int teamId = agent.teamID;
        if (!agentsByTeam.ContainsKey(teamId))
        {
            agentsByTeam[teamId] = new List<CustomAgent>();
        }
        if (!agentsByTeam[teamId].Contains(agent))
        {
            agentsByTeam[teamId].Add(agent);
        }

        // Update spatial grid for fast queries
        UpdateAgentSpatialPosition(agent);
    }

    /// <summary>
    /// Unregister an agent from the registry.
    /// </summary>
    public void UnregisterAgent(CustomAgent agent, int agentId)
    {
        // Remove from ID registry
        if (agentsById.ContainsKey(agentId))
            agentsById.Remove(agentId);

        // Remove from team registry
        int teamId = agent.teamID;
        if (agentsByTeam.ContainsKey(teamId))
            agentsByTeam[teamId].Remove(agent);

        // Remove from spatial grid
        Vector2Int gridPos = GetGridPosition(agent.transform.position);
        if (spatialGrid.ContainsKey(gridPos) && spatialGrid[gridPos].Contains(agent))
            spatialGrid[gridPos].Remove(agent);
    }

    /// <summary>
    /// Update an agent's position in the spatial grid.
    /// </summary>
    public void UpdateAgentSpatialPosition(CustomAgent agent)
    {
        Vector2Int gridPos = GetGridPosition(agent.transform.position);

        // Remove from all existing grid cells (optimization: track last cell for each agent if needed)
        foreach (var cell in spatialGrid.Values)
        {
            if (cell.Contains(agent))
                cell.Remove(agent);
        }

        // Add to new grid cell
        if (!spatialGrid.ContainsKey(gridPos))
            spatialGrid[gridPos] = new List<CustomAgent>();

        if (!spatialGrid[gridPos].Contains(agent))
            spatialGrid[gridPos].Add(agent);
    }

    /// <summary>
    /// Get nearby agents within a certain radius without using Physics.OverlapSphere.
    /// </summary>
    public List<CustomAgent> GetNearbyAgents(Vector3 position, float radius, int excludeTeamId = -1)
    {
        List<CustomAgent> nearbyAgents = new List<CustomAgent>();
        Vector2Int centerCell = GetGridPosition(position);
        int cellRadius = Mathf.CeilToInt(radius / gridCellSize);

        // Iterate over cells in the grid that fall within the radius
        for (int x = -cellRadius; x <= cellRadius; x++)
        {
            for (int z = -cellRadius; z <= cellRadius; z++)
            {
                Vector2Int checkCell = new Vector2Int(centerCell.x + x, centerCell.y + z);
                if (spatialGrid.ContainsKey(checkCell))
                {
                    foreach (var agent in spatialGrid[checkCell])
                    {
                        if (agent != null &&
                            (excludeTeamId == -1 || agent.teamID != excludeTeamId) &&
                            Vector3.Distance(position, agent.transform.position) <= radius)
                        {
                            nearbyAgents.Add(agent);
                        }
                    }
                }
            }
        }

        return nearbyAgents;
    }

    /// <summary>
    /// Find the closest opponent from a different team.
    /// </summary>
    public CustomAgent FindClosestOpponent(Vector3 position, int teamId, float maxDistance = 20f)
    {
        CustomAgent closest = null;
        float closestDistance = maxDistance;

        // Iterate through all teams other than the specified one
        foreach (var kvp in agentsByTeam)
        {
            if (kvp.Key != teamId && kvp.Value.Count > 0)
            {
                List<CustomAgent> nearbyAgents = GetNearbyAgents(position, maxDistance, teamId);
                foreach (var agent in nearbyAgents)
                {
                    float distance = Vector3.Distance(position, agent.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closest = agent;
                    }
                }
            }
        }

        return closest;
    }

    /// <summary>
    /// Get all agents on a specific team.
    /// </summary>
    public List<CustomAgent> GetTeamAgents(int teamId)
    {
        if (agentsByTeam.ContainsKey(teamId))
            return new List<CustomAgent>(agentsByTeam[teamId]);
        return new List<CustomAgent>();
    }

    /// <summary>
    /// Clear all data in the registry (useful for resetting between training sessions).
    /// </summary>
    public void ResetRegistry()
    {
        agentsById.Clear();
        agentsByTeam.Clear();
        spatialGrid.Clear();
    }

    /// <summary>
    /// Convert a world position to a grid position.
    /// </summary>
    private Vector2Int GetGridPosition(Vector3 worldPosition)
    {
        return new Vector2Int(
            Mathf.FloorToInt(worldPosition.x / gridCellSize),
            Mathf.FloorToInt(worldPosition.z / gridCellSize)
        );
    }
}