using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Unity.MLAgents;

/// <summary>
/// Complete knowledge sharing system for ML-Agents that allows
/// agents to pool and share observations, rewards, and experiences.
/// </summary>
namespace AgentKnowledgeSystem
{


    [Serializable]
    public enum AbilityType
    {
        Defensive,
        Offensive,
        Utility
    }
    /// <summary>
    /// Represents a single observation from an agent
    /// </summary>
    [Serializable]
    public class AgentObservation
    {
        // Timestamp of the observation
        public float Timestamp;

        // Environment ID this observation came from
        public int EnvironmentId;

        // Episode number
        public int EpisodeId;

        // Agent ID within the environment
        public int AgentId;

        // Importance weight of this observation (used for decay)
        public float Weight = 1.0f;

        // The actual observation data (could be raycast results, sensor data, etc.)
        public float[] ObservationData;

        // Additional context about the observation (e.g., situation, state)
        public string Context;

        // Enhanced context categorization
        public enum ObservationContext
        {
            None,
            NearTarget,     // Agent_1 near target
            EvasiveAction,  // Agent_1 successfully evading
            HunterNearby,   // Hunter detected nearby
            SuccessfulHunt, // Agent_2 successfully tracking
            DamageDealt,    // Agent_2 dealing damage
            DamageTaken     // Agent_1 taking damage
        }

        public ObservationContext ContextType { get; set; } = ObservationContext.None;

        public AgentObservation(float timestamp, int environmentId, int episodeId, int agentId,
                               float[] observationData, string context = "",
                               ObservationContext contextType = ObservationContext.None)
        {
            Timestamp = timestamp;
            EnvironmentId = environmentId;
            EpisodeId = episodeId;
            AgentId = agentId;
            ObservationData = observationData;
            Context = context;
            ContextType = contextType;
        }

        // Default constructor for JSON deserialization
        public AgentObservation() { }
    }

    /// <summary>
    /// Represents a reward or punishment received by an agent
    /// </summary>
    [Serializable]
    public class RewardRecord
    {
        // Timestamp of the reward
        public float Timestamp;

        // Environment ID this reward came from
        public int EnvironmentId;

        // Episode number
        public int EpisodeId;

        // Agent ID within the environment
        public int AgentId;

        // The reward value (positive for rewards, negative for punishments)
        public float Value;

        // Importance weight of this record (used for decay)
        public float Weight = 1.0f;

        // Reason for the reward/punishment (e.g., "Damage", "Block", "TargetReached")
        public string Reason;

        public RewardRecord(float timestamp, int environmentId, int episodeId, int agentId, float value, string reason = "")
        {
            Timestamp = timestamp;
            EnvironmentId = environmentId;
            EpisodeId = episodeId;
            AgentId = agentId;
            Value = value;
            Reason = reason;
        }

        // Default constructor for JSON deserialization
        public RewardRecord() { }
    }

    /// <summary>
    /// Statistics for a specific action type's rewards
    /// </summary>
    [Serializable]
    public class RewardStatistics
    {
        public float TotalReward = 0f;
        public int Count = 0;
        public float AverageReward = 0f;
        public float MaxReward = float.MinValue;
        public float MinReward = float.MaxValue;
        public float RecentAverageReward = 0f;
    }

    /// <summary>
    /// Entry for serializing dictionary data
    /// </summary>
    [Serializable]
    public class StatEntry
    {
        public string Key;
        public float Value;
    }

    /// <summary>
    /// Entry for serializing action stats dictionary data
    /// </summary>
    [Serializable]
    public class ActionStatEntry
    {
        public string ActionType;
        public RewardStatistics Stats;
    }

    /// <summary>
    /// Represents a knowledge pool for a specific agent type/team
    /// </summary>
    [Serializable]
    public class AgentKnowledgePool
    {
        // Curriculum stages for progressive learning
        public enum CurriculumStage
        {
            Initial,        // Basic movement and awareness
            Intermediate,   // Strategic positioning
            Advanced,       // Team coordination
            Expert          // Complex strategies
        }

        public CurriculumStage CurrentStage { get; private set; } = CurriculumStage.Initial;

        // Progression thresholds for curriculum advancement
        public float[] StageProgressionThresholds = new float[] { 0.5f, 1.5f, 3.0f };  // Average rewards needed to advance

        // Queue of recent observations
        [SerializeField]
        private List<AgentObservation> _observations;

        // List of reward records
        [SerializeField]
        private List<RewardRecord> _rewardRecords;

        // Statistical summaries
        [SerializeField]
        private List<StatEntry> _serializedStatistics = new List<StatEntry>();
        private Dictionary<string, float> _statistics = new Dictionary<string, float>();

        // Action-specific reward statistics
        [SerializeField]
        private List<ActionStatEntry> _serializedActionStats = new List<ActionStatEntry>();
        private Dictionary<string, RewardStatistics> _actionRewardStats = new Dictionary<string, RewardStatistics>();

        // Capacity limits
        private int _maxObservations;
        private int _maxRewardRecords;

        // Selective Sharing settings
        [SerializeField] public bool _useSelectiveSharing = true;
        [SerializeField] public float _topPercentileThreshold = 0.25f; // Share only top 25% observations

        // Staged Learning settings
        [SerializeField] public bool _useStagedLearning = true;
        [SerializeField] public int _minEpisodesBeforeSharing = 10; // Wait 10 episodes before sharing
        [SerializeField] public float _sharingScalingFactor = 0.02f; // Scale up sharing gradually by 2% per episode

        private int _totalEpisodes = 0;

        public AgentKnowledgePool()
        {
            _observations = new List<AgentObservation>();
            _rewardRecords = new List<RewardRecord>();
            _statistics = new Dictionary<string, float>();
            _actionRewardStats = new Dictionary<string, RewardStatistics>();
        }

        public AgentKnowledgePool(int maxObservations, int maxRewardRecords)
        {
            _maxObservations = maxObservations;
            _maxRewardRecords = maxRewardRecords;
            _observations = new List<AgentObservation>(_maxObservations);
            _rewardRecords = new List<RewardRecord>(_maxRewardRecords);
            _statistics = new Dictionary<string, float>();
            _actionRewardStats = new Dictionary<string, RewardStatistics>();
        }

        /// <summary>
        /// Adds an observation to the pool, but only if it meets quality criteria
        /// </summary>
        public void AddObservation(AgentObservation observation)
        {
            // For staged learning - check if we've reached the minimum episode count
            if (_useStagedLearning && observation.EpisodeId < _minEpisodesBeforeSharing)
            {
                // During early training, agents learn independently
                return;
            }

            // For selective sharing - check if this observation is high quality
            if (_useSelectiveSharing && !IsHighQualityObservation(observation))
            {
                // Skip low-quality observations
                return;
            }

            // Remove oldest observation if at capacity
            if (_observations.Count >= _maxObservations)
            {
                _observations.RemoveAt(0);
            }

            // Track highest episode ID to determine training stage
            _totalEpisodes = Math.Max(_totalEpisodes, observation.EpisodeId);

            _observations.Add(observation);

            // Update statistics
            UpdateStatistics();

            // Update curriculum stage based on performance
            UpdateCurriculumStage();
        }

        /// <summary>
        /// Update the curriculum stage based on recent performance
        /// </summary>
        public void UpdateCurriculumStage()
        {
            float recentAvgReward = GetAverageReward(100);

            if (recentAvgReward >= StageProgressionThresholds[2] && CurrentStage != CurriculumStage.Expert)
            {
                CurrentStage = CurriculumStage.Expert;
                Debug.Log($"Advanced to EXPERT curriculum stage with avg reward: {recentAvgReward}");
            }
            else if (recentAvgReward >= StageProgressionThresholds[1] && CurrentStage != CurriculumStage.Advanced)
            {
                CurrentStage = CurriculumStage.Advanced;
                Debug.Log($"Advanced to ADVANCED curriculum stage with avg reward: {recentAvgReward}");
            }
            else if (recentAvgReward >= StageProgressionThresholds[0] && CurrentStage != CurriculumStage.Intermediate)
            {
                CurrentStage = CurriculumStage.Intermediate;
                Debug.Log($"Advanced to INTERMEDIATE curriculum stage with avg reward: {recentAvgReward}");
            }
        }

        /// <summary>
        /// Determines if an observation is high-quality (in the top percentile)
        /// </summary>
        private bool IsHighQualityObservation(AgentObservation observation)
        {
            // If we don't have enough data yet, accept everything
            if (_rewardRecords.Count < 10)
                return true;

            // Get the agent's recent reward as a quality indicator
            float recentReward = GetAgentRecentReward(observation.AgentId);

            // Calculate the threshold value (top X% of rewards)
            float thresholdValue = CalculatePercentileThreshold(_topPercentileThreshold);

            // Only accept observations from agents performing in the top percentile
            return recentReward >= thresholdValue;
        }

        /// <summary>
        /// Gets an agent's recent average reward as a quality indicator
        /// </summary>
        private float GetAgentRecentReward(int agentId)
        {
            var agentRecords = _rewardRecords
                .Where(r => r.AgentId == agentId)
                .OrderByDescending(r => r.Timestamp)
                .Take(10)
                .ToList();

            if (agentRecords.Count == 0)
                return 0f;

            return agentRecords.Average(r => r.Value);
        }

        /// <summary>
        /// Calculates a percentile threshold from all reward records
        /// </summary>
        private float CalculatePercentileThreshold(float percentile)
        {
            // Get all unique agent IDs
            var agentIds = _rewardRecords.Select(r => r.AgentId).Distinct().ToList();

            // Calculate average reward for each agent
            List<float> agentAvgRewards = new List<float>();
            foreach (int agentId in agentIds)
            {
                float avgReward = _rewardRecords
                    .Where(r => r.AgentId == agentId)
                    .Average(r => r.Value);

                agentAvgRewards.Add(avgReward);
            }

            // Sort rewards to find percentile threshold
            agentAvgRewards.Sort();

            // Calculate index for desired percentile
            int index = Math.Max(0, (int)(agentAvgRewards.Count * (1 - percentile)) - 1);

            // Return the threshold value
            return (index >= 0 && index < agentAvgRewards.Count) ?
                agentAvgRewards[index] :
                float.MinValue;
        }

        /// <summary>
        /// Adds a reward record to the pool, removing oldest if at capacity
        /// </summary>
        public void AddRewardRecord(RewardRecord record)
        {
            // Remove oldest record if at capacity
            if (_rewardRecords.Count >= _maxRewardRecords)
            {
                _rewardRecords.RemoveAt(0);
            }

            _rewardRecords.Add(record);

            // Update action-specific stats
            UpdateActionRewardStatistics(record);

            // Update general statistics
            UpdateStatistics();
        }

        /// <summary>
        /// Gets the most recent observations up to the specified count
        /// </summary>
        public List<AgentObservation> GetRecentObservations(int count)
        {
            return _observations.OrderByDescending(o => o.Timestamp).Take(count).ToList();
        }

        /// <summary>
        /// Gets the average reward over the last n records
        /// </summary>
        public float GetAverageReward(int lastNRecords = 100)
        {
            int recordsToConsider = Math.Min(lastNRecords, _rewardRecords.Count);

            if (recordsToConsider == 0)
                return 0f;

            return _rewardRecords
                .OrderByDescending(r => r.Timestamp)
                .Take(recordsToConsider)
                .Average(r => r.Value);
        }

        /// <summary>
        /// Updates action-specific reward statistics
        /// </summary>
        private void UpdateActionRewardStatistics(RewardRecord record)
        {
            string actionType = record.Reason;
            if (string.IsNullOrEmpty(actionType))
                actionType = "Default";

            if (!_actionRewardStats.ContainsKey(actionType))
            {
                _actionRewardStats[actionType] = new RewardStatistics();
            }

            RewardStatistics stats = _actionRewardStats[actionType];
            stats.TotalReward += record.Value;
            stats.Count++;
            stats.AverageReward = stats.TotalReward / stats.Count;

            if (record.Value > stats.MaxReward)
                stats.MaxReward = record.Value;

            if (record.Value < stats.MinReward)
                stats.MinReward = record.Value;

            // Calculate recent average (last 20 records)
            int recentCount = 20;
            var recentRecords = _rewardRecords
                .Where(r => r.Reason == actionType)
                .OrderByDescending(r => r.Timestamp)
                .Take(recentCount)
                .ToList();

            if (recentRecords.Count > 0)
            {
                stats.RecentAverageReward = recentRecords.Average(r => r.Value);
            }

            // Update serialized version for JSON
            UpdateSerializedActionStats();
        }

        /// <summary>
        /// Get reward statistics for a specific action type
        /// </summary>
        public RewardStatistics GetRewardStatisticsForAction(string actionType)
        {
            if (string.IsNullOrEmpty(actionType))
                actionType = "Default";

            if (_actionRewardStats.ContainsKey(actionType))
                return _actionRewardStats[actionType];

            return new RewardStatistics();
        }

        /// <summary>
        /// Updates statistical summaries based on current data
        /// </summary>
        private void UpdateStatistics()
        {
            // Calculate various statistics
            if (_rewardRecords.Count > 0)
            {
                _statistics["AvgReward"] = _rewardRecords.Average(r => r.Value);
                _statistics["MaxReward"] = _rewardRecords.Max(r => r.Value);
                _statistics["MinReward"] = _rewardRecords.Min(r => r.Value);

                // Calculate recent trend (last 100 records or less)
                int recentCount = Math.Min(100, _rewardRecords.Count);
                if (recentCount > 0)
                {
                    _statistics["RecentAvgReward"] = _rewardRecords
                        .OrderByDescending(r => r.Timestamp)
                        .Take(recentCount)
                        .Average(r => r.Value);
                }
            }

            if (_observations.Count > 0)
            {
                _statistics["ObservationCount"] = _observations.Count;
                _statistics["UniqueEnvironments"] = _observations.Select(o => o.EnvironmentId).Distinct().Count();
            }

            // Add selective sharing statistics
            _statistics["SharingPercentileThreshold"] = _topPercentileThreshold;
            _statistics["StagedLearningEpisode"] = _totalEpisodes;

            // Add curriculum stage information
            _statistics["CurriculumStage"] = (float)CurrentStage;

            // Update serialized version for JSON
            UpdateSerializedStatistics();
        }

        /// <summary>
        /// Update the serialized statistics list for JSON serialization
        /// </summary>
        private void UpdateSerializedStatistics()
        {
            _serializedStatistics.Clear();
            foreach (var kvp in _statistics)
            {
                _serializedStatistics.Add(new StatEntry { Key = kvp.Key, Value = kvp.Value });
            }
        }

        /// <summary>
        /// Update the serialized action stats list for JSON serialization
        /// </summary>
        private void UpdateSerializedActionStats()
        {
            _serializedActionStats.Clear();
            foreach (var kvp in _actionRewardStats)
            {
                _serializedActionStats.Add(new ActionStatEntry { ActionType = kvp.Key, Stats = kvp.Value });
            }
        }

        /// <summary>
        /// Gets a specific statistic from the pool
        /// </summary>
        public float GetStatistic(string name, float defaultValue = 0f)
        {
            if (_statistics.TryGetValue(name, out float value))
                return value;

            return defaultValue;
        }

        /// <summary>
        /// Gets all statistics as a dictionary
        /// </summary>
        public Dictionary<string, float> GetAllStatistics()
        {
            return new Dictionary<string, float>(_statistics);
        }

        /// <summary>
        /// Calculate the current sharing factor based on training progress
        /// </summary>
        private float CalculateSharingFactor()
        {
            float sharingFactor = 1.0f;
            if (_useStagedLearning)
            {
                // Calculate how far into training we are (after minimum episodes)
                int episodesAfterMin = Math.Max(0, _totalEpisodes - _minEpisodesBeforeSharing);

                // Gradually increase sharing factor (capped at 1.0)
                sharingFactor = Math.Min(1.0f, episodesAfterMin * _sharingScalingFactor);
            }
            return sharingFactor;
        }

        /// <summary>
        /// Generate a combined observation vector from all recent observations with context awareness
        /// </summary>
        public float[] GetCombinedObservationVector(int vectorSize, AgentObservation.ObservationContext preferredContext = AgentObservation.ObservationContext.None)
        {
            float[] combinedVector = new float[vectorSize];

            // If no observations, return zeros
            if (_observations.Count == 0)
                return combinedVector;

            // Apply staged learning factor
            float sharingFactor = CalculateSharingFactor();

            // Get observations, prioritizing preferred context
            var recentObs = _observations
                .OrderByDescending(o => o.ContextType == preferredContext ? 2f : 1f) // Prioritize preferred context
                .ThenByDescending(o => o.Timestamp)
                .Take(Math.Min(10, _observations.Count))
                .ToList();

            // Weight observations by context relevance and recency
            float totalWeight = 0f;
            float[] weightedVector = new float[vectorSize];

            foreach (var obs in recentObs)
            {
                float contextWeight = (obs.ContextType == preferredContext) ? 2.0f : 1.0f;
                float recencyWeight = 1.0f / (1.0f + (Time.time - obs.Timestamp) * 0.1f); // Decay by time
                float weight = obs.Weight * contextWeight * recencyWeight;

                totalWeight += weight;

                for (int i = 0; i < vectorSize && i < obs.ObservationData.Length; i++)
                {
                    weightedVector[i] += obs.ObservationData[i] * weight;
                }
            }

            // Normalize by total weight and apply sharing factor
            if (totalWeight > 0)
            {
                for (int i = 0; i < vectorSize; i++)
                {
                    combinedVector[i] = (weightedVector[i] / totalWeight) * sharingFactor;
                }
            }

            return combinedVector;
        }

        /// <summary>
        /// Perform experience replay to reinforce successful strategies
        /// </summary>
        public void PerformExperienceReplay(int episodeFrequency = 10)
        {
            // Only trigger replay on specific episode intervals
            if (_totalEpisodes % episodeFrequency != 0)
                return;

            // Select top-performing observations
            var topObservations = _observations
                .OrderByDescending(o => o.Weight)
                .Take(5)
                .ToList();

            // Temporarily boost their importance
            foreach (var obs in topObservations)
            {
                // Make a copy with boosted weight and current timestamp
                var replayObs = new AgentObservation
                {
                    Timestamp = Time.time, // Current time
                    EnvironmentId = obs.EnvironmentId,
                    EpisodeId = _totalEpisodes, // Current episode
                    AgentId = obs.AgentId,
                    ObservationData = obs.ObservationData.ToArray(), // Make a copy
                    Context = obs.Context + "_Replay",
                    ContextType = obs.ContextType,
                    Weight = obs.Weight * 1.5f // Boost importance
                };

                // Add back to the pool
                _observations.Add(replayObs);

                // Keep pool size in check
                if (_observations.Count > _maxObservations)
                {
                    _observations.RemoveAt(0);
                }
            }
        }

        /// <summary>
        /// Apply decay to all observations and rewards to ensure older data becomes less important
        /// </summary>
        public void ApplyDecay(float observationDecayRate, float rewardDecayRate)
        {
            // Apply decay to oldest observations (front of the list)
            for (int i = 0; i < _observations.Count; i++)
            {
                // Older observations receive more decay
                float decayFactor = observationDecayRate * (1 + i / (float)_observations.Count);
                _observations[i].Weight = Mathf.Max(0.1f, _observations[i].Weight - decayFactor);
            }

            // Apply decay to oldest rewards (front of the list)
            for (int i = 0; i < _rewardRecords.Count; i++)
            {
                // Older rewards receive more decay
                float decayFactor = rewardDecayRate * (1 + i / (float)_rewardRecords.Count);
                _rewardRecords[i].Weight = Mathf.Max(0.1f, _rewardRecords[i].Weight - decayFactor);
            }
        }

        /// <summary>
        /// Serializes the pool to JSON
        /// </summary>
        public string ToJson()
        {
            // Make sure serialized collections are up to date
            UpdateSerializedStatistics();
            UpdateSerializedActionStats();

            // Create a serializable wrapper
            KnowledgePoolData data = new KnowledgePoolData
            {
                Observations = _observations,
                RewardRecords = _rewardRecords,
                Statistics = _serializedStatistics,
                ActionRewardStats = _serializedActionStats,
                UseSelectiveSharing = _useSelectiveSharing,
                TopPercentileThreshold = _topPercentileThreshold,
                UseStagedLearning = _useStagedLearning,
                MinEpisodesBeforeSharing = _minEpisodesBeforeSharing,
                SharingScalingFactor = _sharingScalingFactor,
                TotalEpisodes = _totalEpisodes,
                CurrentCurriculumStage = (int)CurrentStage,
                StageProgressionThresholds = StageProgressionThresholds
            };

            return JsonUtility.ToJson(data, true);
        }

        /// <summary>
        /// Deserializes the pool from JSON
        /// </summary>
        public static AgentKnowledgePool FromJson(string json, int maxObservations, int maxRewardRecords)
        {
            try
            {
                KnowledgePoolData data = JsonUtility.FromJson<KnowledgePoolData>(json);

                AgentKnowledgePool pool = new AgentKnowledgePool(maxObservations, maxRewardRecords);
                pool._observations = data.Observations;
                pool._rewardRecords = data.RewardRecords;

                // Rebuild dictionaries from serialized lists
                foreach (var stat in data.Statistics)
                {
                    pool._statistics[stat.Key] = stat.Value;
                }

                foreach (var actionStat in data.ActionRewardStats)
                {
                    pool._actionRewardStats[actionStat.ActionType] = actionStat.Stats;
                }

                // Restore selective sharing and staged learning settings
                pool._useSelectiveSharing = data.UseSelectiveSharing;
                pool._topPercentileThreshold = data.TopPercentileThreshold;
                pool._useStagedLearning = data.UseStagedLearning;
                pool._minEpisodesBeforeSharing = data.MinEpisodesBeforeSharing;
                pool._sharingScalingFactor = data.SharingScalingFactor;
                pool._totalEpisodes = data.TotalEpisodes;

                // Restore curriculum learning settings
                pool.CurrentStage = (CurriculumStage)data.CurrentCurriculumStage;
                if (data.StageProgressionThresholds != null && data.StageProgressionThresholds.Length > 0)
                {
                    pool.StageProgressionThresholds = data.StageProgressionThresholds;
                }

                return pool;
            }
            catch (Exception e)
            {
                Debug.LogError($"Failed to deserialize knowledge pool: {e.Message}");
                return new AgentKnowledgePool(maxObservations, maxRewardRecords);
            }
        }

        [Serializable]
        private class KnowledgePoolData
        {
            public List<AgentObservation> Observations;
            public List<RewardRecord> RewardRecords;
            public List<StatEntry> Statistics;
            public List<ActionStatEntry> ActionRewardStats;

            // Selective sharing settings
            public bool UseSelectiveSharing;
            public float TopPercentileThreshold;

            // Staged learning settings
            public bool UseStagedLearning;
            public int MinEpisodesBeforeSharing;
            public float SharingScalingFactor;
            public int TotalEpisodes;

            // Curriculum learning settings
            public int CurrentCurriculumStage;
            public float[] StageProgressionThresholds;
        }
    }
}