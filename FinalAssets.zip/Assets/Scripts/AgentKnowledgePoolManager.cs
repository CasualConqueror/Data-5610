using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Unity.MLAgents;
using AgentKnowledgeSystem;

/// <summary>
/// Singleton manager that maintains knowledge pools for different agent types.
/// This persists across environment resets and scene loads to enable cross-environment learning.
/// </summary>
public class AgentKnowledgePoolManager : MonoBehaviour
{
    // Singleton instance
    private static AgentKnowledgePoolManager _instance;

    // Lock object for thread safety
    private readonly object _lockObject = new object();

    // Dictionary mapping agent types to their respective knowledge pools
    private Dictionary<int, AgentKnowledgePool> _knowledgePools = new Dictionary<int, AgentKnowledgePool>();

    // Export settings
    [Header("Export Settings")]
    [SerializeField] private bool _autoExportEnabled = true;
    [SerializeField] private float _autoExportInterval = 300f; // 5 minutes
    [SerializeField] private string _exportPath = "AgentKnowledgeExport";
    private float _lastExportTime;

    [Header("Pool Settings")]
    // Maximum number of observations to keep per agent type
    [SerializeField] private int _maxObservationsPerType = 1000;
    // Maximum number of reward records to keep per agent type
    [SerializeField] private int _maxRewardRecordsPerType = 10000;
    // Whether to log detailed information about knowledge sharing
    [SerializeField] private bool _debugMode = false;

    [Header("Decay Settings")]
    // How quickly older observations lose importance (0-1)
    [SerializeField] private float _observationDecayRate = 0.01f;
    // How quickly older reward records lose importance (0-1)
    [SerializeField] private float _rewardDecayRate = 0.005f;

    [Header("Selective Sharing")]
    [SerializeField] private bool _useSelectiveSharing = true;
    [SerializeField] private float _topPercentileThreshold = 0.25f; // Top 25%
    [Tooltip("Only share observations from agents in the top X% of performers")]

    [Header("Staged Learning")]
    [SerializeField] private bool _useStagedLearning = true;
    [SerializeField] private int _minEpisodesBeforeSharing = 50;
    [SerializeField] private float _sharingScalingFactor = 0.02f;

    [Header("Team-Specific Settings")]
    // Enhanced curriculum learning for specific teams
    [SerializeField] private bool _useTeamSpecificSettings = true;
    [Tooltip("Apply different learning parameters based on team roles")]

    [Header("Dynamic Difficulty")]
    [SerializeField] private bool _useDynamicDifficulty = true;
    [SerializeField] private float _performanceDisparityThreshold = 0.3f;
    [SerializeField] private float _adjustmentFactor = 0.1f;
    [Tooltip("Adjust parameters to balance teams when performance gap exceeds threshold")]

    [Header("Adversarial Learning")]
    [SerializeField] private bool _useAdversarialLearning = true;
    [SerializeField] private int _adversarialUpdateFrequency = 50;
    [Tooltip("Enable agents to learn counter-strategies against opposing teams")]

    // Track last times for system updates
    private float _lastBalanceCheckTime = 0f;
    private int _lastAdversarialUpdate = 0;
    private int _highestEpisodeId = 0;

    public static AgentKnowledgePoolManager Instance
    {
        get
        {
            if (_instance == null)
            {
                // Try to find existing instance
                _instance = FindObjectOfType<AgentKnowledgePoolManager>();

                // If no instance exists, create a new one
                if (_instance == null)
                {
                    GameObject go = new GameObject("AgentKnowledgePoolManager");
                    _instance = go.AddComponent<AgentKnowledgePoolManager>();
                    DontDestroyOnLoad(go);
                }
            }
            return _instance;
        }
    }

    private void Awake()
    {
        // Ensure singleton behavior
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
            return;
        }

        _instance = this;
        DontDestroyOnLoad(gameObject);
        _lastExportTime = Time.time;
        _lastBalanceCheckTime = Time.time;

        if (_debugMode)
        {
            Debug.Log("AgentKnowledgePoolManager initialized with " +
                    $"selective sharing: {_useSelectiveSharing} (top {_topPercentileThreshold*100}%), " +
                    $"staged learning: {_useStagedLearning} (min episodes: {_minEpisodesBeforeSharing})");
        }

        // Initialize team-specific settings if enabled
        if (_useTeamSpecificSettings)
        {
            // Configure optimal settings for each team based on their roles
            ConfigureTeamSpecificSettings(1); // Agent_1 (Target Reacher/Evader)
            ConfigureTeamSpecificSettings(2); // Agent_2 (Hunter/Attacker)
        }
    }

    private void Update()
    {
        // Auto-export knowledge pools if enabled
        if (_autoExportEnabled && Time.time - _lastExportTime > _autoExportInterval)
        {
            ExportAllKnowledgePools();
            _lastExportTime = Time.time;
        }

        // Check for team performance balance (every 30 seconds)
        if (_useDynamicDifficulty && Time.time - _lastBalanceCheckTime > 30f)
        {
            BalanceTeamPerformance();
            _lastBalanceCheckTime = Time.time;
        }

        // Check if we should apply decay to old observations
        if (Time.frameCount % 500 == 0)
        {
            ApplyGlobalDecay();
        }
    }

    /// <summary>
    /// Configures team-specific knowledge sharing settings based on agent roles
    /// </summary>
    public void ConfigureTeamSpecificSettings(int teamId)
    {
        var pool = GetKnowledgePool(teamId);

        if (teamId == 1) // Agent_1 - Evader/Target Reacher team
        {
            // Agent_1 benefits more from observations about successful evasion tactics
            pool._topPercentileThreshold = 0.2f;  // More selective - only share the best 20%
            pool._sharingScalingFactor = 0.03f;   // Learn a bit faster from shared knowledge

            // Adjust curriculum stage thresholds
            pool.StageProgressionThresholds = new float[] { 0.5f, 1.2f, 2.5f };

            if (_debugMode)
            {
                Debug.Log($"Configured Team 1 (Evader) with selective threshold {pool._topPercentileThreshold}, " +
                          $"scaling factor {pool._sharingScalingFactor}");
            }
        }
        else if (teamId == 2) // Agent_2 - Hunter/Attacker team
        {
            // Agent_2 benefits from wider variety of tracking strategies
            pool._topPercentileThreshold = 0.3f;  // Less selective - share top 30%
            pool._sharingScalingFactor = 0.025f;  // Standard learning rate

            // Adjust curriculum stage thresholds for hunting behavior
            pool.StageProgressionThresholds = new float[] { 0.4f, 1.0f, 2.0f };

            if (_debugMode)
            {
                Debug.Log($"Configured Team 2 (Hunter) with selective threshold {pool._topPercentileThreshold}, " +
                          $"scaling factor {pool._sharingScalingFactor}");
            }
        }
    }

    /// <summary>
    /// Gets or creates a knowledge pool for the specified agent team/type
    /// </summary>
    public AgentKnowledgePool GetKnowledgePool(int teamId)
    {
        lock (_lockObject)
        {
            if (!_knowledgePools.TryGetValue(teamId, out AgentKnowledgePool pool))
            {
                pool = new AgentKnowledgePool(_maxObservationsPerType, _maxRewardRecordsPerType);

                // Configure selective sharing and staged learning
                pool._useSelectiveSharing = _useSelectiveSharing;
                pool._topPercentileThreshold = _topPercentileThreshold;
                pool._useStagedLearning = _useStagedLearning;
                pool._minEpisodesBeforeSharing = _minEpisodesBeforeSharing;
                pool._sharingScalingFactor = _sharingScalingFactor;

                _knowledgePools.Add(teamId, pool);

                if (_debugMode)
                {
                    Debug.Log($"Created new knowledge pool for team ID: {teamId}");
                }
            }
            return pool;
        }
    }

    /// <summary>
    /// Adds an observation to the knowledge pool for the specified agent team/type
    /// </summary>
    public void AddObservation(int teamId, AgentObservation observation)
    {
        lock (_lockObject)
        {
            GetKnowledgePool(teamId).AddObservation(observation);

            // Track highest episode ID for adversarial learning scheduling
            _highestEpisodeId = Mathf.Max(_highestEpisodeId, observation.EpisodeId);

            // Check if we should update adversarial learning
            if (_useAdversarialLearning &&
                _highestEpisodeId - _lastAdversarialUpdate >= _adversarialUpdateFrequency)
            {
                EnableAdversarialLearning();
                _lastAdversarialUpdate = _highestEpisodeId;
            }

            if (_debugMode)
            {
                Debug.Log($"Team {teamId} added observation from environment {observation.EnvironmentId}, " +
                         $"episode {observation.EpisodeId}");
            }
        }
    }

    /// <summary>
    /// Adds a reward record to the knowledge pool for the specified agent team/type
    /// </summary>
    public void AddRewardRecord(int teamId, RewardRecord record)
    {
        lock (_lockObject)
        {
            GetKnowledgePool(teamId).AddRewardRecord(record);

            if (_debugMode)
            {
                Debug.Log($"Team {teamId} added reward record: {record.Value:F2} for reason: {record.Reason}");
            }
        }
    }

    /// <summary>
    /// Gets recent observations for the specified agent team/type
    /// </summary>
    public List<AgentObservation> GetRecentObservations(int teamId, int count)
    {
        lock (_lockObject)
        {
            return GetKnowledgePool(teamId).GetRecentObservations(count);
        }
    }

    /// <summary>
    /// Gets the average reward for the specified agent team/type over the last n records
    /// </summary>
    public float GetAverageReward(int teamId, int lastNRecords = 100)
    {
        lock (_lockObject)
        {
            return GetKnowledgePool(teamId).GetAverageReward(lastNRecords);
        }
    }

    /// <summary>
    /// Gets reward statistics for a specific action type for the specified agent team/type
    /// </summary>
    public RewardStatistics GetRewardStatisticsForAction(int teamId, string actionType)
    {
        lock (_lockObject)
        {
            return GetKnowledgePool(teamId).GetRewardStatisticsForAction(actionType);
        }
    }

    /// <summary>
    /// Gets the combined agent observation array for the specified agent team/type
    /// This is useful for agents to incorporate shared knowledge into their decision-making
    /// </summary>
    public float[] GetCombinedObservationVector(int teamId, int vectorSize,
                                              AgentObservation.ObservationContext preferredContext =
                                              AgentObservation.ObservationContext.None)
    {
        lock (_lockObject)
        {
            return GetKnowledgePool(teamId).GetCombinedObservationVector(vectorSize, preferredContext);
        }
    }

    /// <summary>
    /// Adjusts learning parameters to balance performance between teams
    /// </summary>
    public void BalanceTeamPerformance()
    {
        if (_knowledgePools.Count < 2)
            return;

        // Get performance metrics for both teams
        float team1Avg = GetAverageReward(1, 100);
        float team2Avg = GetAverageReward(2, 100);

        // Calculate performance disparity ratio
        float disparity = Mathf.Abs(team1Avg - team2Avg) /
                        Mathf.Max(0.1f, Mathf.Max(Mathf.Abs(team1Avg), Mathf.Abs(team2Avg)));

        // If significant disparity exists, adjust sharing parameters
        if (disparity > _performanceDisparityThreshold) // 30% difference in performance
        {
            int underperformingTeam = (team1Avg < team2Avg) ? 1 : 2;
            int outperformingTeam = (underperformingTeam == 1) ? 2 : 1;

            // Boost knowledge sharing for underperforming team
            var underTeamPool = GetKnowledgePool(underperformingTeam);
            underTeamPool._sharingScalingFactor = Mathf.Min(0.05f,
                                                          underTeamPool._sharingScalingFactor * (1f + _adjustmentFactor));

            // Reduce knowledge sharing for outperforming team
            var overTeamPool = GetKnowledgePool(outperformingTeam);
            overTeamPool._sharingScalingFactor = Mathf.Max(0.01f,
                                                          overTeamPool._sharingScalingFactor * (1f - _adjustmentFactor));

            if (_debugMode)
            {
                Debug.Log($"Adjusted team balance: Team {underperformingTeam} sharing boosted to " +
                        $"{underTeamPool._sharingScalingFactor:F3}, Team {outperformingTeam} sharing " +
                        $"reduced to {overTeamPool._sharingScalingFactor:F3}");
            }
        }
    }

    /// <summary>
    /// Enables adversarial learning between teams by sharing counter-strategies
    /// </summary>
    public void EnableAdversarialLearning()
    {
        // 1. Cross-team observation analysis
        var team1Observations = GetRecentObservations(1, 20);
        var team2Observations = GetRecentObservations(2, 20);

        // 2. Extract successful strategies for each team
        var team1SuccessPatterns = ExtractSuccessPatterns(team1Observations);
        var team2SuccessPatterns = ExtractSuccessPatterns(team2Observations);

        // 3. Share counter-strategy information between teams
        InjectCounterStrategies(2, team1SuccessPatterns); // Team 2 learns to counter Team 1 strategies
        InjectCounterStrategies(1, team2SuccessPatterns); // Team 1 learns to counter Team 2 strategies

        if (_debugMode)
        {
            Debug.Log($"Performed adversarial learning update at episode {_highestEpisodeId}");
        }
    }

    private float[] ExtractSuccessPatterns(List<AgentObservation> observations)
    {
        // Analyze highest-reward observations to extract successful patterns
        var successfulObs = observations
            .OrderByDescending(o => o.Weight)
            .Take(5)
            .ToList();

        // Simple average of successful observation patterns
        if (successfulObs.Count == 0 || successfulObs[0].ObservationData == null ||
            successfulObs[0].ObservationData.Length == 0)
            return new float[0];

        int vecSize = successfulObs[0].ObservationData.Length;
        float[] patterns = new float[vecSize];

        foreach (var obs in successfulObs)
        {
            for (int i = 0; i < vecSize; i++)
            {
                patterns[i] += obs.ObservationData[i] / successfulObs.Count;
            }
        }

        return patterns;
    }

    private void InjectCounterStrategies(int teamId, float[] opponentPatterns)
    {
        if (opponentPatterns == null || opponentPatterns.Length == 0)
            return;

        // Create a special "counter-strategy" observation
        var counterObs = new AgentObservation
        {
            Timestamp = Time.time,
            EnvironmentId = 0,
            EpisodeId = _highestEpisodeId,
            AgentId = 0,
            ObservationData = opponentPatterns,
            Context = "CounterStrategy",
            ContextType = AgentObservation.ObservationContext.None,
            Weight = 1.5f // Give counter-strategies higher weight
        };

        // Add this to the team's pool with special handling
        var pool = GetKnowledgePool(teamId);
        pool.AddObservation(counterObs);

        if (_debugMode)
        {
            Debug.Log($"Injected counter-strategy observation for Team {teamId}");
        }
    }

    /// <summary>
    /// Exports all knowledge pools to JSON files
    /// </summary>
    public void ExportAllKnowledgePools()
    {
        lock (_lockObject)
        {
            string directoryPath = Path.Combine(Application.persistentDataPath, _exportPath);
            Directory.CreateDirectory(directoryPath);

            foreach (var kvp in _knowledgePools)
            {
                int teamId = kvp.Key;
                AgentKnowledgePool pool = kvp.Value;

                string filePath = Path.Combine(directoryPath, $"team_{teamId}_knowledge_{DateTime.Now:yyyyMMdd_HHmmss}.json");
                string json = pool.ToJson();
                File.WriteAllText(filePath, json);

                if (_debugMode)
                {
                    Debug.Log($"Exported knowledge pool for team {teamId} to {filePath}");
                }
            }
        }
    }

    /// <summary>
    /// Clears all knowledge pools
    /// </summary>
    public void ClearAllKnowledgePools()
    {
        lock (_lockObject)
        {
            _knowledgePools.Clear();
            if (_debugMode)
            {
                Debug.Log("All knowledge pools cleared");
            }
        }
    }

    /// <summary>
    /// Applies decay to all observations and rewards in all pools
    /// This ensures older data becomes less important over time
    /// </summary>
    public void ApplyGlobalDecay()
    {
        lock (_lockObject)
        {
            foreach (var pool in _knowledgePools.Values)
            {
                pool.ApplyDecay(_observationDecayRate, _rewardDecayRate);
            }

            if (_debugMode)
            {
                Debug.Log($"Applied global decay: observations={_observationDecayRate}, rewards={_rewardDecayRate}");
            }
        }
    }

    /// <summary>
    /// Gets statistics about selective sharing and staged learning
    /// </summary>
    public void LogSharingStatistics()
    {
        lock (_lockObject)
        {
            foreach (var kvp in _knowledgePools)
            {
                int teamId = kvp.Key;
                AgentKnowledgePool pool = kvp.Value;

                var stats = pool.GetAllStatistics();
                int totalEpisodes = (int)stats.GetValueOrDefault("StagedLearningEpisode", 0);
                float percentile = stats.GetValueOrDefault("SharingPercentileThreshold", 0f) * 100f;

                int episodesAfterMin = Math.Max(0, totalEpisodes - pool._minEpisodesBeforeSharing);
                float currentSharingFactor = Math.Min(1.0f, episodesAfterMin * pool._sharingScalingFactor);
                int curriculumStage = (int)stats.GetValueOrDefault("CurriculumStage", 0);

                if (_debugMode)
                {
                    Debug.Log($"Team {teamId} knowledge sharing: " +
                            $"Stage={curriculumStage}, " +
                            $"Selective={pool._useSelectiveSharing} (top {percentile:F1}%), " +
                            $"Staged={pool._useStagedLearning} (episode {totalEpisodes}, factor={currentSharingFactor:F2})");
                }
            }
        }
    }

    /// <summary>
    /// Configures reward function complexity based on curriculum stage
    /// </summary>
    public void ConfigureRewardComplexity(int teamId, AgentKnowledgePool.CurriculumStage stage)
    {
        // These values would need to be communicated to your agent scripts
        if (teamId == 1) // Agent_1 (Evader)
        {
            switch (stage)
            {
                case AgentKnowledgePool.CurriculumStage.Initial:
                    // Simple rewards for basic movement and reaching targets
                    PlayerPrefs.SetFloat("Team1_TargetReward", 1.0f);
                    PlayerPrefs.SetFloat("Team1_DamageMultiplier", 0.5f);
                    PlayerPrefs.SetFloat("Team1_MovementPenalty", 0.001f);
                    break;

                case AgentKnowledgePool.CurriculumStage.Intermediate:
                    // More emphasis on avoiding Agent_2
                    PlayerPrefs.SetFloat("Team1_TargetReward", 1.0f);
                    PlayerPrefs.SetFloat("Team1_DamageMultiplier", 1.0f);
                    PlayerPrefs.SetFloat("Team1_MovementPenalty", 0.002f);
                    break;

                case AgentKnowledgePool.CurriculumStage.Advanced:
                    // Strategic target prioritization
                    PlayerPrefs.SetFloat("Team1_TargetReward", 1.5f);
                    PlayerPrefs.SetFloat("Team1_DamageMultiplier", 1.5f);
                    PlayerPrefs.SetFloat("Team1_MovementPenalty", 0.003f);
                    break;

                case AgentKnowledgePool.CurriculumStage.Expert:
                    // Full complexity
                    PlayerPrefs.SetFloat("Team1_TargetReward", 2.0f);
                    PlayerPrefs.SetFloat("Team1_DamageMultiplier", 2.0f);
                    PlayerPrefs.SetFloat("Team1_MovementPenalty", 0.005f);
                    break;
            }
        }
        else if (teamId == 2) // Agent_2 (Hunter)
        {
            switch (stage)
            {
                case AgentKnowledgePool.CurriculumStage.Initial:
                    // Basic rewards for finding Agent_1
                    PlayerPrefs.SetFloat("Team2_DamageDealtReward", 1.0f);
                    PlayerPrefs.SetFloat("Team2_ProximityReward", 0.5f);
                    PlayerPrefs.SetFloat("Team2_MovementPenalty", 0.001f);
                    break;

                case AgentKnowledgePool.CurriculumStage.Intermediate:
                    // More emphasis on dealing damage
                    PlayerPrefs.SetFloat("Team2_DamageDealtReward", 1.5f);
                    PlayerPrefs.SetFloat("Team2_ProximityReward", 0.3f);
                    PlayerPrefs.SetFloat("Team2_MovementPenalty", 0.002f);
                    break;

                case AgentKnowledgePool.CurriculumStage.Advanced:
                    // Strategic pursuit behavior
                    PlayerPrefs.SetFloat("Team2_DamageDealtReward", 2.0f);
                    PlayerPrefs.SetFloat("Team2_ProximityReward", 0.2f);
                    PlayerPrefs.SetFloat("Team2_MovementPenalty", 0.003f);
                    break;

                case AgentKnowledgePool.CurriculumStage.Expert:
                    // Full complexity
                    PlayerPrefs.SetFloat("Team2_DamageDealtReward", 2.5f);
                    PlayerPrefs.SetFloat("Team2_ProximityReward", 0.1f);
                    PlayerPrefs.SetFloat("Team2_MovementPenalty", 0.005f);
                    break;
            }
        }

        if (_debugMode)
        {
            Debug.Log($"Updated reward complexity for Team {teamId} to {stage} stage");
        }
    }

    /// <summary>
    /// Monitors and triggers experience replay for important experiences
    /// </summary>
    public void TriggerExperienceReplay(int episodeFrequency = 10)
    {
        lock (_lockObject)
        {
            foreach (var pool in _knowledgePools.Values)
            {
                pool.PerformExperienceReplay(episodeFrequency);
            }
        }
    }
}