using UnityEngine;
using AgentKnowledgeSystem; // Import the knowledge sharing namespace

using ObservationContext = AgentKnowledgeSystem.AgentObservation.ObservationContext;
using CurriculumStage = AgentKnowledgeSystem.AgentKnowledgePool.CurriculumStage;

public class AgentHealthSystem : MonoBehaviour
{
    [Header("Health Settings")]
    public float maxHealth = 100f;
    [HideInInspector] public float currentHealth;

    [Header("Combat Settings")]
    public int teamID = 0;
    public float attackRange = 1.25f;
    public float attackDamage = 10f;
    public float attackCooldown = 1f;
    [HideInInspector] public float attackTimer = 0f;

    [Header("LLM Integration")]
    public float lastDamageTime = 0f;
    public float lastAttackTime = 0f;

    [Header("Rewards")]
    public float damageReward = 0.05f;
    public float damagePenalty = -0.03f;

    // Dynamic reward scaling based on curriculum stage
    [Header("Curriculum Learning")]
    [SerializeField] private bool _useCurriculumScaling = true;
    [SerializeField] private float[] _damageRewardByStage = new float[] { 0.05f, 0.1f, 0.15f, 0.2f };
    [SerializeField] private float[] _damagePenaltyByStage = new float[] { -0.03f, -0.05f, -0.08f, -0.1f };

    // Context tracking for knowledge sharing
    private AgentObservation.ObservationContext _lastCombatContext = AgentObservation.ObservationContext.None;

    private CustomAgent agentRef;
    private AgentKnowledgePool.CurriculumStage _currentStage = AgentKnowledgePool.CurriculumStage.Initial;

    private void Awake()
    {
        agentRef = GetComponent<CustomAgent>();
    }

    public void Initialize()
    {
        currentHealth = maxHealth;
        attackTimer = 0f;

        // Get current curriculum stage from knowledge pool if available
        UpdateCurriculumStage();
    }

    /// <summary>
    /// Updates the current curriculum stage and associated rewards
    /// </summary>
    private void UpdateCurriculumStage()
    {
        if (!_useCurriculumScaling || AgentKnowledgePoolManager.Instance == null)
            return;

        // Get the pool for this team
        var pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(teamID);

        // Get current stage
        _currentStage = pool.CurrentStage;

        // Update reward values based on stage
        int stageIndex = (int)_currentStage;
        if (stageIndex >= 0 && stageIndex < _damageRewardByStage.Length)
        {
            damageReward = _damageRewardByStage[stageIndex];
            damagePenalty = _damagePenaltyByStage[stageIndex];
        }

        // Log the update
        Debug.Log($"Agent {agentRef.agentId} (Team {teamID}) updated to curriculum stage {_currentStage} " +
                 $"with damage reward {damageReward:F2}, penalty {damagePenalty:F2}");
    }

    public void UpdateCooldowns()
    {
        // Reduce attack timer
        if (attackTimer > 0)
            attackTimer -= Time.deltaTime;

        // Check curriculum stage updates periodically (every 5 seconds)
        if (Time.frameCount % 300 == 0 && _useCurriculumScaling)
        {
            UpdateCurriculumStage();
        }
    }

    public void TryAttack(CustomAgent opponent, Vector3 hitPoint)
    {
        // Reset the attack timer to the cooldown value.
        attackTimer = attackCooldown;

        // Update the lastAttackTime for LLM tracking
        lastAttackTime = Time.time;

        if (opponent != null)
        {
            AgentBlockSystem opponentBlockSystem = opponent.GetComponent<AgentBlockSystem>();

            // Set combat context for knowledge sharing
            _lastCombatContext = AgentObservation.ObservationContext.DamageDealt;

            if (opponentBlockSystem != null && opponentBlockSystem.isBlocking &&
                opponentBlockSystem.IsAttackBlocked(transform.position, hitPoint))
            {
                opponentBlockSystem.BlockAttack(hitPoint);

                // Update context for knowledge sharing
                _lastCombatContext = AgentObservation.ObservationContext.None;
            }
            else
            {
                // Attack successful - damage scales with curriculum stage for increased challenge
                float scaledDamage = attackDamage * (1.0f + 0.25f * (int)_currentStage);
                opponent.GetComponent<AgentHealthSystem>().TakeDamage(scaledDamage, agentRef);

                // Apply reward based on current curriculum stage
                agentRef.AddReward(damageReward, "Attack");

                // Modify reward based on target health to encourage finishing off opponents
                // at advanced curriculum stages
                if (_currentStage >= AgentKnowledgePool.CurriculumStage.Advanced)
                {
                    float targetHealthPercent = opponent.GetComponent<AgentHealthSystem>().currentHealth /
                                               opponent.GetComponent<AgentHealthSystem>().maxHealth;

                    // Bonus reward for attacking low-health opponents (finish them off!)
                    if (targetHealthPercent < 0.3f)
                    {
                        float bonusReward = damageReward * 0.5f * (1.0f - targetHealthPercent);
                        agentRef.AddReward(bonusReward, "FinishingAttack");
                    }
                }
            }
        }
    }

    // This method resets the attack timer for the agent.
    public void ResetAttackTimer()
    {
        attackTimer = attackCooldown;
    }

    public void TakeDamage(float damage, CustomAgent attacker)
    {
        currentHealth -= damage;

        // Update the lastDamageTime for LLM tracking
        lastDamageTime = Time.time;

        // Set context for knowledge sharing
        _lastCombatContext = AgentObservation.ObservationContext.DamageTaken;

        // Apply penalty for taking damage (scaled by curriculum stage)
        agentRef.AddReward(damagePenalty, "Damage");

        // Report damage for global tracking (cross-environment sharing)
        TrainingManager.Instance?.ReportDamage(damage);

        // Advanced stages: penalize being cornered (no escape routes)
        if (_currentStage >= AgentKnowledgePool.CurriculumStage.Advanced)
        {
            // Check if close to obstacles in multiple directions
            int blockedDirections = CountBlockedDirections();
            if (blockedDirections >= 3) // Agent is cornered
            {
                float cornerPenalty = damagePenalty * 0.5f * blockedDirections;
                agentRef.AddReward(cornerPenalty, "Cornered");
            }
        }

        if (currentHealth <= 0)
        {
            // Scale defeat/victory rewards based on curriculum stage for better agent adaptation
            float defeatMultiplier = 1.0f + 0.5f * (int)_currentStage;
            float victoryMultiplier = 1.0f + 0.25f * (int)_currentStage;

            attacker.AddReward(0.5f * victoryMultiplier, "Victory"); // Bonus for defeating an opponent
            agentRef.AddReward(-0.5f * defeatMultiplier, "Defeat");  // Penalty for being defeated
            agentRef.EndEpisode();
            agentRef.NotifyEpisodeEnding();
        }
    }

    /// <summary>
    /// Count how many directions around the agent are blocked by obstacles
    /// Used for detecting if agent is cornered
    /// </summary>
    private int CountBlockedDirections()
    {
        int blockedCount = 0;
        Vector3 origin = transform.position + Vector3.up * 0.5f;
        float checkDistance = 1.5f;

        // Check in 4 cardinal directions
        Vector3[] directions = new Vector3[]
        {
            Vector3.forward,
            Vector3.right,
            Vector3.back,
            Vector3.left
        };

        foreach (Vector3 dir in directions)
        {
            if (Physics.Raycast(origin, dir, checkDistance))
            {
                blockedCount++;
            }
        }

        return blockedCount;
    }

    /// <summary>
    /// Gets the current combat context for knowledge sharing
    /// </summary>
    public AgentObservation.ObservationContext GetCombatContext()
    {
        return _lastCombatContext;
    }

    /// <summary>
    /// Adjusts attack parameters based on curriculum stage and learned strategies
    /// </summary>
    public void ApplyLearnedStrategies()
    {
        if (AgentKnowledgePoolManager.Instance == null)
            return;

        // Get team-specific strategies
        RewardStatistics attackStats =
            AgentKnowledgePoolManager.Instance.GetRewardStatisticsForAction(teamID, "Attack");

        // Expert stage: adjust attack range based on success statistics
        if (_currentStage == AgentKnowledgePool.CurriculumStage.Expert && attackStats.Count > 50)
        {
            // Calculate optimal attack range based on recent success patterns
            float optimalRange = attackRange;

            if (attackStats.RecentAverageReward > attackStats.AverageReward)
            {
                // Recent strategies are working better than average - slightly increase range
                optimalRange *= 1.05f;
            }
            else if (attackStats.RecentAverageReward < attackStats.AverageReward * 0.8f)
            {
                // Recent strategies not working well - be more cautious with range
                optimalRange *= 0.95f;
            }

            // Apply within reasonable bounds
            attackRange = Mathf.Clamp(optimalRange, 1.0f, 2.0f);
        }
    }
}