using UnityEngine;
using System.Collections.Generic;

public class AgentPerceptionSystem : MonoBehaviour
{
    [Header("References")]
    // You can assign your current CustomAgent in the Inspector.
    public CustomAgent assignedAgent;

    [Header("Raycast Settings")]
    public int rayCount = 8;            // Number of rays to cast around the agent.
    public float rayLength = 10f;       // Maximum length of raycasts.
    public LayerMask targetLayer;       // Layer mask for target.
    public LayerMask opponentLayer;     // Layer for opponent agents.
    public LayerMask wallLayer;         // Layer for walls.

    [Header("Facing Reward Settings")]
    public float maxFacingReward = 1.0f;  // Maximum reward for perfectly facing the opponent.
    public float facingThreshold = 0.8f;  // Dot product threshold for considering "facing" (~36 degrees).

    [HideInInspector] public List<RaycastHit> raycastHits;  // Store raycast results.
    [HideInInspector] public List<bool> rayHitResults;        // Store whether each ray hit something.

    private CustomAgent agentRef;

    // Static data provider for cross-environment information sharing.
    public static Dictionary<int, Dictionary<string, object>> sharedAgentData = new Dictionary<int, Dictionary<string, object>>();

    private void Awake()
    {
        // If the assignedAgent is provided in the Inspector, use it.
        if (assignedAgent != null)
        {
            agentRef = assignedAgent;
        }
        else
        {
            // First, try getting CustomAgent on the same GameObject.
            agentRef = GetComponent<CustomAgent>();

            // If not found, try to find it in parent GameObjects.
            if (agentRef == null)
            {
                agentRef = GetComponentInParent<CustomAgent>();
            }

            // If it's still not found, log an error and disable this component.
            if (agentRef == null)
            {
                Debug.LogError("AgentPerceptionSystem: CustomAgent not found on this GameObject or any of its parents. Please assign one in the Inspector.");
                enabled = false;  // Disable this script to prevent further errors.
            }
        }
    }

    public void Initialize()
    {
        // Check again to be safe.
        if (agentRef == null)
        {
            Debug.LogError("AgentPerceptionSystem.Initialize() failed: agentRef is null. Aborting initialization.");
            return;
        }

        // Initialize raycast storage.
        raycastHits = new List<RaycastHit>(rayCount);
        rayHitResults = new List<bool>(rayCount);

        // Clear any existing items first to prevent duplicates
        raycastHits.Clear();
        rayHitResults.Clear();

        for (int i = 0; i < rayCount; i++)
        {
            raycastHits.Add(new RaycastHit());
            rayHitResults.Add(false);
        }

        // Initialize shared data for this agent if it doesn't exist.
        int instanceID = agentRef.GetInstanceID();
        if (!sharedAgentData.ContainsKey(instanceID))
        {
            sharedAgentData[instanceID] = new Dictionary<string, object>();
        }

        // Log successful initialization
        Debug.Log($"AgentPerceptionSystem initialized with {rayCount} rays");
    }

    public void PerformRaycasts()
    {
        Vector3 rayOrigin = transform.position + Vector3.up * 0.5f;

        // Clear previous results.
        for (int i = 0; i < rayCount; i++)
        {
            rayHitResults[i] = false;
        }

        // Cast rays in all directions.
        for (int i = 0; i < rayCount; i++)
        {
            // Calculate direction based on index (evenly distribute in 360°).
            float angle = i * (360f / rayCount);
            Vector3 direction = Quaternion.Euler(0, angle, 0) * Vector3.forward;

            // First check for target.
            if (Physics.Raycast(rayOrigin, direction, out RaycastHit targetHit, rayLength, targetLayer))
            {
                raycastHits[i] = targetHit;
                rayHitResults[i] = true;
            }
            // Then check for opponents.
            else if (Physics.Raycast(rayOrigin, direction, out RaycastHit opponentHit, rayLength, opponentLayer))
            {
                raycastHits[i] = opponentHit;
                rayHitResults[i] = true;
            }
            // Then check for walls
            else if (Physics.Raycast(rayOrigin, direction, out RaycastHit wallHit, rayLength, wallLayer))
            {
                raycastHits[i] = wallHit;
                rayHitResults[i] = true;
            }
            // Finally check for any obstacles (using non-alloc variant for performance).
            else
            {
                RaycastHit obstacleHit;
                if (Physics.Raycast(rayOrigin, direction, out obstacleHit, rayLength))
                {
                    raycastHits[i] = obstacleHit;
                    rayHitResults[i] = true;
                }
            }
        }

        // Update shared data with perception results.
        if (agentRef != null)
        {
            int instanceID = agentRef.GetInstanceID();
            if (sharedAgentData.ContainsKey(instanceID))
            {
                sharedAgentData[instanceID]["lastPerceptionUpdate"] = Time.time;
            }
        }
    }

    public CustomAgent FindClosestOpponent()
    {
        // Add these null checks
        if (raycastHits == null || rayHitResults == null)
        {
            Debug.LogWarning("FindClosestOpponent: raycastHits or rayHitResults is null. Make sure Initialize() was called.");
            return null;
        }

        CustomAgent closestOpponent = null;
        float closestDistance = float.MaxValue;

        for (int i = 0; i < rayCount; i++)
        {
            // Check if index is valid
            if (i >= rayHitResults.Count || i >= raycastHits.Count)
            {
                continue;
            }

            if (rayHitResults[i])
            {
                // Add null check for collider
                if (raycastHits[i].collider == null)
                {
                    continue;
                }

                GameObject hitObject = raycastHits[i].collider.gameObject;

                // Add null check for gameObject
                if (hitObject == null)
                {
                    continue;
                }

                // Check if it's on the opponent layer
                if (hitObject.layer == (int)Mathf.Log(opponentLayer.value, 2))
                {
                    CustomAgent opponent = hitObject.GetComponent<CustomAgent>();

                    // Check if opponent and agentRef are not null
                    if (opponent != null && agentRef != null && opponent.teamID != agentRef.teamID)
                    {
                        float distance = raycastHits[i].distance;
                        if (distance < closestDistance)
                        {
                            closestDistance = distance;
                            closestOpponent = opponent;
                        }
                    }
                }
            }
        }

        return closestOpponent;
    }

    public Vector3 GetDirectionToTarget(Transform target)
    {
        for (int i = 0; i < rayCount; i++)
        {
            if (rayHitResults[i])
            {
                if (raycastHits[i].collider.gameObject.layer == (int)Mathf.Log(targetLayer.value, 2))
                {
                    return (raycastHits[i].point - transform.position).normalized;
                }
            }
        }
        // If target not found via raycast, use direct vector.
        return (target.position - transform.position).normalized;
    }

    /// <summary>
    /// Calculate reward based on how well the agent is facing a specific opponent.
    /// </summary>
    public float CalculateFacingReward(CustomAgent opponent)
    {
        if (opponent == null)
            return 0f;

        Vector3 directionToOpponent = (opponent.transform.position - transform.position).normalized;
        directionToOpponent.y = 0;
        Vector3 forwardDirection = transform.forward;
        forwardDirection.y = 0;
        forwardDirection.Normalize();
        directionToOpponent.Normalize();
        float dotProduct = Vector3.Dot(forwardDirection, directionToOpponent);

        if (dotProduct < facingThreshold)
        {
            return Mathf.Max(0, dotProduct) * maxFacingReward;
        }
        else
        {
            return maxFacingReward;
        }
    }

    /// <summary>
    /// Calculate facing reward for the closest opponent.
    /// </summary>
    public float CalculateFacingRewardForClosestOpponent()
    {
        CustomAgent closestOpponent = FindClosestOpponent();
        return CalculateFacingReward(closestOpponent);
    }

    // Share agent data with other environments.
    public static void ShareAgentData(int agentID, string key, object value)
    {
        if (!sharedAgentData.ContainsKey(agentID))
        {
            sharedAgentData[agentID] = new Dictionary<string, object>();
        }
        sharedAgentData[agentID][key] = value;
    }

    // Retrieve shared agent data.
    public static object GetSharedAgentData(int agentID, string key, object defaultValue = null)
    {
        if (sharedAgentData.ContainsKey(agentID) && sharedAgentData[agentID].ContainsKey(key))
        {
            return sharedAgentData[agentID][key];
        }
        return defaultValue;
    }

    /// <summary>
    /// Performs synthetic (headless) perception using cached opponent data.
    /// This method updates the rayHitResults and raycastHits based on opponents passed in.
    /// </summary>
    /// <param name="cachedOpponents">List of nearby opponent agents.</param>
    public void PerformHeadlessPerception(List<CustomAgent> cachedOpponents)
    {
        Vector3 rayOrigin = transform.position + Vector3.up * 0.5f;

        // Clear previous results.
        for (int i = 0; i < rayCount; i++)
        {
            rayHitResults[i] = false;
            // Reset the stored hit structure.
            raycastHits[i] = new RaycastHit();
        }

        // For each synthetic ray...
        for (int i = 0; i < rayCount; i++)
        {
            // Calculate ray direction evenly distributed around 360°.
            float angle = i * (360f / rayCount);
            Vector3 rayDir = Quaternion.Euler(0, angle, 0) * Vector3.forward;

            bool hit = false;
            float closestDistance = rayLength;
            RaycastHit syntheticHit = new RaycastHit();

            // Check each cached opponent to see if they lie along this ray.
            foreach (CustomAgent opponent in cachedOpponents)
            {
                Vector3 dirToOpponent = (opponent.transform.position - transform.position).normalized;
                float angleToOpponent = Vector3.Angle(rayDir, dirToOpponent);
                float distToOpponent = Vector3.Distance(transform.position, opponent.transform.position);

                // If within tolerance (e.g., 20 degrees) and closer than any previous hit, record this opponent.
                if (angleToOpponent < 20f && distToOpponent < closestDistance)
                {
                    closestDistance = distToOpponent;
                    syntheticHit.distance = distToOpponent;
                    syntheticHit.point = opponent.transform.position;
                    // Do not assign to syntheticHit.collider as it is read-only.
                    hit = true;
                }
            }

            // For headless perception, also check for walls using actual raycasts
            if (!hit)
            {
                if (Physics.Raycast(rayOrigin, rayDir, out RaycastHit wallHit, rayLength, wallLayer))
                {
                    hit = true;
                    syntheticHit.distance = wallHit.distance;
                    syntheticHit.point = wallHit.point;
                    // Cannot assign collider directly
                }
            }

            if (hit)
            {
                rayHitResults[i] = true;
                raycastHits[i] = syntheticHit;
            }
        }

        // Update shared data to note when headless perception was last performed.
        int instanceID = agentRef.GetInstanceID();
        if (sharedAgentData.ContainsKey(instanceID))
        {
            sharedAgentData[instanceID]["lastHeadlessPerceptionUpdate"] = Time.time;
        }
    }

    /// <summary>
    /// Checks if a wall was detected at the specific ray index
    /// </summary>
    public bool IsWallDetected(int rayIndex)
    {
        if (rayIndex < 0 || rayIndex >= rayCount || !rayHitResults[rayIndex] || raycastHits[rayIndex].collider == null)
            return false;

        return raycastHits[rayIndex].collider.gameObject.layer == (int)Mathf.Log(wallLayer.value, 2);
    }

    /// <summary>
    /// Gets a list of all wall hit positions from the raycast results
    /// </summary>
    public List<Vector3> GetAllWallHitPositions()
    {
        List<Vector3> wallPositions = new List<Vector3>();

        for (int i = 0; i < rayCount; i++)
        {
            if (rayHitResults[i] && raycastHits[i].collider != null &&
                raycastHits[i].collider.gameObject.layer == (int)Mathf.Log(wallLayer.value, 2))
            {
                wallPositions.Add(raycastHits[i].point);
            }
        }

        return wallPositions;
    }

    /// <summary>
    /// Gets the distance to the closest wall detected by any ray
    /// </summary>
    public float GetDistanceToClosestWall()
    {
        float closestDistance = float.MaxValue;

        for (int i = 0; i < rayCount; i++)
        {
            if (IsWallDetected(i) && raycastHits[i].distance < closestDistance)
            {
                closestDistance = raycastHits[i].distance;
            }
        }

        return closestDistance == float.MaxValue ? -1f : closestDistance;
    }
}