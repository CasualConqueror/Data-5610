using UnityEngine;
using AgentKnowledgeSystem; // Import the knowledge sharing namespace

using ObservationContext = AgentKnowledgeSystem.AgentObservation.ObservationContext;
using CurriculumStage = AgentKnowledgeSystem.AgentKnowledgePool.CurriculumStage;

public class AgentBlockSystem : MonoBehaviour
{
    [Header("Block Settings")]
    public float blockRange = 1.5f;
    public float blockAngle = 120f; // Angle in degrees for a successful block (forward cone)
    public float blockReward = 0.02f; // Reward for a successful block
    public float blockPenalty = -0.03f; // Punishment when blocking with no threat
    public LayerMask opponentLayer;  // Layer mask to detect potential attackers

    [Header("Cooldown Settings")]
    public float blockCooldown = 0.75f; // Cooldown time in seconds
    private float nextBlockTime = 0f;  // Time after which a new block can be activated

    [Header("Curriculum Learning")]
    [SerializeField] private bool _useCurriculumScaling = true;
    [SerializeField] private float[] _blockRewardByStage = new float[] { 0.02f, 0.04f, 0.06f, 0.08f };
    [SerializeField] private float[] _blockPenaltyByStage = new float[] { -0.03f, -0.04f, -0.05f, -0.06f };
    [SerializeField] private float[] _blockAngleByStage = new float[] { 120f, 100f, 80f, 60f }; // Progressively narrower block angle

    [HideInInspector] public bool isBlocking = false;

    // Store variables for learning analysis
    private int successfulBlocks = 0;
    private int failedBlocks = 0;
    private float blockSuccessRate = 0f;

    // Context tracking for knowledge sharing
    private AgentObservation.ObservationContext _lastBlockContext = AgentObservation.ObservationContext.None;

    private CustomAgent agentRef;
    private AgentKnowledgePool.CurriculumStage _currentStage = AgentKnowledgePool.CurriculumStage.Initial;

    // Flag to ensure punishment is applied only once per block activation.
    private bool punishedThisBlock = false;

    private void Awake()
    {
        agentRef = GetComponent<CustomAgent>();
    }

    public void Initialize()
    {
        isBlocking = false;
        punishedThisBlock = false;
        successfulBlocks = 0;
        failedBlocks = 0;
        blockSuccessRate = 0f;

        // Get current curriculum stage from knowledge pool if available
        UpdateCurriculumStage();
    }

    /// <summary>
    /// Updates the current curriculum stage and associated parameters
    /// </summary>
    private void UpdateCurriculumStage()
    {
        if (!_useCurriculumScaling || AgentKnowledgePoolManager.Instance == null)
            return;

        // Get the pool for this team
        var pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(agentRef.teamID);

        // Get current stage
        _currentStage = pool.CurrentStage;

        // Update values based on stage
        int stageIndex = (int)_currentStage;
        if (stageIndex >= 0 && stageIndex < _blockRewardByStage.Length)
        {
            blockReward = _blockRewardByStage[stageIndex];
            blockPenalty = _blockPenaltyByStage[stageIndex];
            blockAngle = _blockAngleByStage[stageIndex];
        }

        // Log the update
        Debug.Log($"Agent {agentRef.agentId} (Team {agentRef.teamID}) block system updated to curriculum stage {_currentStage} " +
                 $"with block reward {blockReward:F2}, penalty {blockPenalty:F2}, angle {blockAngle}°");
    }

    /// <summary>
    /// Sets the blocking state of the agent. A cooldown is enforced when starting a block.
    /// </summary>
    public void SetBlockState(bool blocking)
    {
        // Periodically update curriculum stage
        if (Time.frameCount % 300 == 0 && _useCurriculumScaling)
        {
            UpdateCurriculumStage();
        }

        // Attempt to activate block only if transitioning from not blocking.
        if (blocking && !isBlocking)
        {
            // Check if the block is ready based on the cooldown timer.
            if (Time.time < nextBlockTime)
            {
                if (Debug.isDebugBuild)
                {
                    Debug.Log("[Block] Block is on cooldown.");
                }
                return; // If still in cooldown, ignore the block request.
            }

            // Update the next block time to current time plus cooldown duration.
            nextBlockTime = Time.time + blockCooldown;

            // Look for potential attackers in advanced curriculum stages
            if (_currentStage >= AgentKnowledgePool.CurriculumStage.Intermediate)
            {
                // Use a wider detection range in advanced stages to preemptively block
                float detectionRange = blockRange * (1.0f + 0.25f * (int)_currentStage);
                bool threatDetected = IsThreateningOpponentNearby(detectionRange);

                // If threat detected, set context for knowledge sharing
                if (threatDetected)
                {
                    _lastBlockContext = AgentObservation.ObservationContext.EvasiveAction;
                }
                else
                {
                    _lastBlockContext = AgentObservation.ObservationContext.None;
                }

                // In Expert stage, only apply penalty if no threat AND agent isn't near anything important
                if (_currentStage == AgentKnowledgePool.CurriculumStage.Expert && !threatDetected)
                {
                    // Check if near target, if not, apply penalty
                    bool nearTarget = IsNearTarget();
                    if (!nearTarget && !punishedThisBlock)
                    {
                        // Apply penalty for unnecessary blocking
                        if (agentRef != null)
                        {
                            agentRef.AddReward(blockPenalty, "UnnecessaryBlock");
                            failedBlocks++;
                            UpdateBlockSuccessRate();
                        }
                        punishedThisBlock = true;
                    }
                }
                else if (!threatDetected && !punishedThisBlock) // Lower stages: always punish if no threat
                {
                    // Apply penalty for unnecessary blocking
                    if (agentRef != null)
                    {
                        agentRef.AddReward(blockPenalty, "UnnecessaryBlock");
                        failedBlocks++;
                        UpdateBlockSuccessRate();
                    }
                    punishedThisBlock = true;
                }
            }
            else // Initial stage - simpler logic
            {
                Collider[] hitColliders = Physics.OverlapSphere(transform.position, blockRange, opponentLayer);
                if (hitColliders.Length == 0 && !punishedThisBlock)
                {
                    // No opponent is near, so apply a small punishment.
                    if (agentRef != null)
                    {
                        agentRef.AddReward(blockPenalty, "UnnecessaryBlock");
                        failedBlocks++;
                        UpdateBlockSuccessRate();
                    }
                    punishedThisBlock = true;

                    if (Debug.isDebugBuild)
                    {
                        Debug.Log($"[Block] Punishment applied: {blockPenalty}");
                    }
                }
            }
        }

        // Reset the punishment flag when turning off blocking.
        if (!blocking)
        {
            punishedThisBlock = false;
        }

        isBlocking = blocking;
    }

    /// <summary>
    /// Checks if an incoming attack is successfully blocked based on direction and distance.
    /// </summary>
    /// <param name="attackerPosition">The position of the attacker.</param>
    /// <param name="hitPoint">The intended hit point.</param>
    /// <returns>True if the attack is blocked; otherwise, false.</returns>
    public bool IsAttackBlocked(Vector3 attackerPosition, Vector3 hitPoint)
    {
        Vector3 directionToAttacker = (attackerPosition - transform.position).normalized;
        float angleToAttacker = Vector3.Angle(transform.forward, directionToAttacker);
        float distanceToAttacker = Vector3.Distance(transform.position, attackerPosition);

        // Block is successful if the attacker is within the block cone and range.
        // Block angle is determined by curriculum stage
        return isBlocking && angleToAttacker <= blockAngle / 2 && distanceToAttacker <= blockRange;
    }

    /// <summary>
    /// Called when an incoming attack is successfully blocked.
    /// Rewards the agent for blocking the attack.
    /// </summary>
    public void OnAttackBlocked()
    {
        if (agentRef != null)
        {
            // Reward for a successful block.
            agentRef.AddReward(blockReward, "Block");
            successfulBlocks++;
            UpdateBlockSuccessRate();

            // Set context for knowledge sharing
            _lastBlockContext = AgentObservation.ObservationContext.EvasiveAction;

            // In advanced stages, add extra reward for effective timing
            if (_currentStage >= AgentKnowledgePool.CurriculumStage.Advanced)
            {
                // Bonus reward for maintaining high block success rate
                if (blockSuccessRate > 0.7f)
                {
                    agentRef.AddReward(blockReward * 0.25f, "ConsistentBlocking");
                }
            }
        }

        if (Debug.isDebugBuild)
        {
            Debug.Log("[Block] Attack successfully blocked.");
        }
    }

    /// <summary>
    /// Called to process an attack block. This method can be used as a fallback if an attack is intercepted.
    /// </summary>
    /// <param name="hitPoint">The point at which the block occurred.</param>
    public void BlockAttack(Vector3 hitPoint)
    {
        // Reward the agent for a successful block.
        if (agentRef != null)
        {
            agentRef.AddReward(blockReward, "Block");
            successfulBlocks++;
            UpdateBlockSuccessRate();

            // Set context for knowledge sharing
            _lastBlockContext = AgentObservation.ObservationContext.EvasiveAction;
        }
    }

    /// <summary>
    /// Gets the current block context for knowledge sharing
    /// </summary>
    public AgentObservation.ObservationContext GetBlockContext()
    {
        return _lastBlockContext;
    }

    /// <summary>
    /// Check if a threatening opponent is nearby and potentially attacking
    /// </summary>
    private bool IsThreateningOpponentNearby(float detectionRange)
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, detectionRange, opponentLayer);

        foreach (var hitCollider in hitColliders)
        {
            CustomAgent opponent = hitCollider.GetComponent<CustomAgent>();
            if (opponent != null && opponent.teamID != agentRef.teamID)
            {
                // Check if opponent is facing us
                Vector3 directionFromOpponent = (transform.position - opponent.transform.position).normalized;
                float facingAngle = Vector3.Angle(opponent.transform.forward, directionFromOpponent);

                // If opponent is facing us within a reasonable cone (45 degrees), consider it threatening
                if (facingAngle < 45f)
                {
                    // Advanced stages: also check opponent's attack cooldown if visible
                    if (_currentStage >= AgentKnowledgePool.CurriculumStage.Advanced)
                    {
                        AgentHealthSystem opponentHealth = opponent.GetComponent<AgentHealthSystem>();
                        if (opponentHealth != null && opponentHealth.attackTimer <= 0.2f) // Attack is ready or nearly ready
                        {
                            return true; // Imminent attack threat
                        }
                    }
                    else
                    {
                        return true; // Basic threat detection
                    }
                }
            }
        }

        return false;
    }

    /// <summary>
    /// Check if the agent is near its target (for context-aware blocking in Expert stage)
    /// </summary>
    private bool IsNearTarget()
    {
        if (agentRef == null || agentRef.target == null)
            return false;

        float distanceToTarget = Vector3.Distance(transform.position, agentRef.target.position);
        return distanceToTarget < 3.0f; // Consider "near" if within 3 units
    }

    /// <summary>
    /// Update block success rate for learning analysis
    /// </summary>
    private void UpdateBlockSuccessRate()
    {
        int totalBlocks = successfulBlocks + failedBlocks;
        if (totalBlocks > 0)
        {
            blockSuccessRate = (float)successfulBlocks / totalBlocks;
        }
    }

    /// <summary>
    /// Adapts block parameters based on learned strategies from the knowledge pool
    /// Called periodically to optimize behavior
    /// </summary>
    public void ApplyLearnedStrategies()
    {
        if (AgentKnowledgePoolManager.Instance == null)
            return;

        // Get team-specific strategies
        RewardStatistics blockStats =
            AgentKnowledgePoolManager.Instance.GetRewardStatisticsForAction(agentRef.teamID, "Block");

        // Only apply if we have sufficient data
        if (blockStats.Count > 50)
        {
            // Adjust block cooldown based on success patterns
            if (blockStats.RecentAverageReward > blockStats.AverageReward * 1.2f)
            {
                // Recent blocking is very effective - slightly reduce cooldown
                blockCooldown = Mathf.Max(0.5f, blockCooldown * 0.95f);
            }
            else if (blockStats.RecentAverageReward < blockStats.AverageReward * 0.8f)
            {
                // Recent blocking is less effective - slightly increase cooldown to avoid overuse
                blockCooldown = Mathf.Min(1.0f, blockCooldown * 1.05f);
            }

            // Expert stage: optimize block angle based on success rate
            if (_currentStage == AgentKnowledgePool.CurriculumStage.Expert)
            {
                // If current block success rate is high, we can use a narrower angle for more precise blocking
                if (blockSuccessRate > 0.8f)
                {
                    blockAngle = Mathf.Max(45f, blockAngle * 0.95f);
                }
                // If success rate is low, use a wider angle for easier blocking
                else if (blockSuccessRate < 0.5f)
                {
                    blockAngle = Mathf.Min(120f, blockAngle * 1.05f);
                }
            }
        }
    }
}