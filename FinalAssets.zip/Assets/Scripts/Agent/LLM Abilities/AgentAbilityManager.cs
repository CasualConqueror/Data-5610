using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Policies;
using Unity.MLAgents.Actuators;
using System;
using System.IO;
using System.Reflection;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.Collections.Generic;
using AgentKnowledgeSystem;
using System.Linq;
using System.Text;

[Serializable]
public class AbilityInfo
{
    public string abilityName;
    public Action<CustomAgent> abilityAction;
    public float effectiveness; // This is now used for tracking how well the ability performs, not for reward calculation
    public int usageCount;      // Track how many times this ability was used
    public float avgReward;     // Average reward received after using this ability

    public AbilityInfo(string name, Action<CustomAgent> action, float initEffectiveness = 0.5f)
    {
        abilityName = name;
        abilityAction = action;
        effectiveness = initEffectiveness;
        usageCount = 0;
        avgReward = 0f;
    }
}

public class AgentAbilityManager : MonoBehaviour
{
    // ----------------------------
    // Energy Settings
    // ----------------------------
    public int maxEnergy = 100;
    public int currentEnergy { get; private set; }
    public int abilityCost = 30;
    public float energyRegenRate = 1f; // Energy regenerated per second

    // ----------------------------
    // Collection of Abilities
    // ----------------------------
    public List<AbilityInfo> abilities = new List<AbilityInfo>();

    // Current ability being used (for notifications)
    private string _currentAbilityName = "";

    // ----------------------------
    // Maximum Number of Ability Slots (Fixed at 3 now)
    // ----------------------------
    public int maxAbilities = 3;

    // ----------------------------
    // Ability File Settings (Dynamic Code)
    // ----------------------------
    public string abilityFolder = "Assets/GeneratedAbilities";
    public string abilityFileName = "Ability.txt";
    private string abilityFilePath;
    private DateTime lastWriteTime;

    // ----------------------------
    // Ability Usage Tracking
    // ----------------------------
    private int lastUsedAbilityIndex = -1;
    private float timeOfLastAbilityUse = 0f;
    private float[] recentAbilityRewards = new float[5]; // Store last 5 rewards for analysis
    private int rewardIndex = 0;

    // ----------------------------
    // Reference to LLMManager
    // ----------------------------
    public LLMManager llmManager;

    // ----------------------------
    // Reference to the Agent Component
    // ----------------------------
    private CustomAgent customAgent;

    // ----------------------------
    // LLM Request Timing
    // ----------------------------
    public float minTimeBetweenLLMRequests = 30f;
    private float lastLLMRequestTime = -1000f;
    public int minEpisodesBetweenRequests = 2;
    private int episodesSinceLastRequest = 0;

    // ----------------------------
    // Ability Generation Settings
    // ----------------------------
    public bool autoRequestNewAbilities = true;
    public float abilityGenerationThreshold = 0.3f;

    // ----------------------------
    // Debug Visualization
    // ----------------------------
    public bool debugObservations = true;
    
    // ----------------------------
    // Discrete Action Configuration
    // ----------------------------
    private int _abilityDiscreteActionSize = 4;  // None, Ability1, Ability2, Ability3
    
    // ----------------------------
    // Agent-specific identification
    // ----------------------------
    private bool _isAgent1 = false;
    private bool _isAgent2 = false;
    [SerializeField] private List<int> _agent1TeamIDs = new List<int> { 1 };
    [SerializeField] private List<int> _agent2TeamIDs = new List<int> { 2 };

    // ----------------------------
    // Initialization
    // ----------------------------
    void Start()
    {
        // Set energy to full at the start of the round
        currentEnergy = maxEnergy;
        
        // Get the CustomAgent component and assign a reference to this manager
        customAgent = GetComponent<CustomAgent>();
        if (customAgent == null)
        {
            Debug.LogError("AgentAbilityManager requires a CustomAgent component on the same GameObject.");
        }
        else
        {
            // Ensure that CustomAgent has a public field 'abilityManager'
            customAgent.abilityManager = this;
            
            // Determine agent type based on team ID
            _isAgent1 = _agent1TeamIDs.Contains(customAgent.teamID);
            _isAgent2 = _agent2TeamIDs.Contains(customAgent.teamID);
            
            if (debugObservations)
            {
                Debug.Log($"Agent {customAgent.agentId} (Team {customAgent.teamID}) identified as: " +
                         $"{(_isAgent1 ? "Agent_1" : (_isAgent2 ? "Agent_2" : "Generic Agent"))}");
            }
        }

        // Ensure the ability folder exists
                if (!Directory.Exists(abilityFolder))
                {
                    Directory.CreateDirectory(abilityFolder);
                }

                abilityFilePath = Path.Combine(abilityFolder, abilityFileName);
                if (!File.Exists(abilityFilePath))
                {
                    File.WriteAllText(abilityFilePath, "");
                }
                lastWriteTime = File.GetLastWriteTime(abilityFilePath);

                // Load any existing ability from the file
                LoadAbilityFromFile();

                // Initialize reward tracking
                for (int i = 0; i < recentAbilityRewards.Length; i++)
                {
                    recentAbilityRewards[i] = 0f;
                }

                // Check for LLMManager in the scene
                if (llmManager == null)
                {
                    llmManager = FindObjectOfType<LLMManager>();
                    if (llmManager != null)
                    {
                        Debug.Log("Found LLMManager in scene and assigned it to AgentAbilityManager");
                    }
                }

                // Set initial performance to trigger ability generation more easily
                for (int i = 0; i < recentAbilityRewards.Length; i++)
                {
                    recentAbilityRewards[i] = 0.4f;
                }

                Debug.Log($"AgentAbilityManager initialized. Auto-request: {autoRequestNewAbilities}, " +
                         $"Threshold: {abilityGenerationThreshold}, Current performance: {CalculateAveragePerformance():F2}");
            }

            // ----------------------------
            // Update Loop
            // ----------------------------
            void Update()
            {
                // Regenerate energy over time
                if (currentEnergy < maxEnergy)
                {
                    currentEnergy = Mathf.Min(maxEnergy, currentEnergy + Mathf.FloorToInt(energyRegenRate * Time.deltaTime));
                }

                // Continuously check for changes in the ability file
                DateTime newWriteTime = File.GetLastWriteTime(abilityFilePath);
                if (newWriteTime != lastWriteTime)
                {
                    lastWriteTime = newWriteTime;
                    LoadAbilityFromFile();
                }

                // Auto-request new abilities if enabled and appropriate
                if (autoRequestNewAbilities &&
                    Time.time - lastLLMRequestTime > minTimeBetweenLLMRequests &&
                    episodesSinceLastRequest >= minEpisodesBetweenRequests)
                {
                    float avgPerformance = CalculateAveragePerformance();
                    if (debugObservations)
                    {
                        Debug.Log($"Checking ability generation conditions: performance {avgPerformance:F2} > threshold {abilityGenerationThreshold} ? " +
                                 $"Abilities count: {abilities.Count}/{maxAbilities}, " +
                                 $"Time since last request: {Time.time - lastLLMRequestTime:F1}s, " +
                                 $"Episodes since last request: {episodesSinceLastRequest}");
                    }

                    if (avgPerformance > abilityGenerationThreshold && abilities.Count < maxAbilities)
                    {
                        RequestAbilityFromLLM();
                        lastLLMRequestTime = Time.time;
                        episodesSinceLastRequest = 0;
                    }
                }

                // For testing:
                // Press "L" to simulate an LLM request for a new ability
                if (Input.GetKeyDown(KeyCode.L))
                {
                    Debug.Log("L key pressed - requesting new ability manually");
                    RequestAbilityFromLLM();
                }
            }

            // ----------------------------
            // Process discrete action from ML-Agents
            // ----------------------------
            public void ProcessAbilityAction(int abilityAction)
            {
                // Skip if no action is requested (abilityAction == 0)
                if (abilityAction <= 0 || abilityAction > abilities.Count)
                    return;

                // Convert from 1-based to 0-based index (0 means no ability used)
                int abilityIndex = abilityAction - 1;

                // Try to use the selected ability
                TryUseAbility(abilityIndex);
            }

            // ----------------------------
            // Episode Management
            // ----------------------------
            public void OnEpisodeBegin()
            {
                currentEnergy = maxEnergy;
                episodesSinceLastRequest++;

                if (debugObservations)
                {
                    Debug.Log($"Episode began. Episodes since last ability request: {episodesSinceLastRequest}");
                }

                // Send ability state to LLM Manager
                if (llmManager != null && customAgent != null)
                {
                    SendAbilityStateToLLM();
                }
            }

            // ----------------------------
            // Calculate average agent performance
            // ----------------------------
            private float CalculateAveragePerformance()
            {
                float sum = 0f;
                for (int i = 0; i < recentAbilityRewards.Length; i++)
                {
                    sum += recentAbilityRewards[i];
                }
                return sum / recentAbilityRewards.Length;
            }

            // ----------------------------
            // Request Ability from LLM via LLMManager
            // ----------------------------
            void RequestAbilityFromLLM()
            {
                // Do not call the LLM if ability slots are full
                if (abilities.Count >= maxAbilities)
                {
                    Debug.Log("Ability slots are full. Not requesting a new ability.");
                    return;
                }

                if (llmManager == null)
                {
                    Debug.LogError("LLMManager is not assigned in AgentAbilityManager.");
                    return;
                }

                // Calculate performance score based on recent rewards
                float performanceScore = CalculateAveragePerformance();

                // Get additional context from the agent
                if (customAgent != null)
                {
                    // Check health status if available
                    AgentHealthSystem healthSystem = customAgent.GetComponent<AgentHealthSystem>();
                    if (healthSystem != null)
                    {
                        float healthPercent = healthSystem.currentHealth / healthSystem.maxHealth;
                        performanceScore = Mathf.Lerp(performanceScore, healthPercent, 0.3f);
                    }
                }

                // Request ability from LLM using updated LLMManager method
                string abilityCode = "";
                if (customAgent != null)
                {
                    // Use the updated LLMManager interface that's aware of agent context
                    abilityCode = llmManager.GenerateAbility(customAgent.agentId, customAgent.teamID, performanceScore);
                }
                else
                {
                    // Fall back to the older method if needed
                    abilityCode = llmManager.SimulateLLMCall(performanceScore);
                }

                // Generate a unique ability name based on performance
                string newAbilityName = GenerateAbilityName(performanceScore);
                if (abilities.Exists(a => a.abilityName == newAbilityName))
                {
                    // Ensure uniqueness
                    newAbilityName += "_" + DateTime.Now.Ticks.ToString().Substring(10);
                }

                // Log the request to LLM manager
                if (debugObservations)
                {
                    Debug.Log($"Requesting new ability from LLM with performance score: {performanceScore:F2}");
                }

                // Write the ability code to the file (this triggers the file watcher reload)
                Debug.Log($"Writing ability code to file: {abilityFilePath}");
                File.WriteAllText(abilityFilePath, abilityCode);
                Debug.Log("LLM ability received and written to file: " + abilityFilePath);

                // Track the most recent generated ability name for verification
                PlayerPrefs.SetString("LastGeneratedAbility", newAbilityName);
            }

            // ----------------------------
            // Generate a descriptive ability name based on performance
            // ----------------------------
            private string GenerateAbilityName(float performance)
            {
                string prefix = "";

                if (performance < 0.3f)
                {
                    prefix = "Defensive";
                }
                else if (performance < 0.7f)
                {
                    prefix = "Tactical";
                }
                else
                {
                    prefix = "Aggressive";
                }

                string[] suffixes = new string[] {
                    "Dash", "Teleport", "Shield", "Blast", "Strike",
                    "Surge", "Leap", "Wave", "Burst", "Flash"
                };

                return prefix + suffixes[UnityEngine.Random.Range(0, suffixes.Length)];
            }

            // ----------------------------
            // Load and Compile Ability Code
            // ----------------------------
            void LoadAbilityFromFile()
            {
                string codeContent = File.ReadAllText(abilityFilePath);
                if (string.IsNullOrWhiteSpace(codeContent))
                {
                    Debug.Log("Ability file is empty. No new ability loaded.");
                    return;
                }

                // Get the ability name from PlayerPrefs if available
                string abilityName = PlayerPrefs.GetString("LastGeneratedAbility", "DynamicAbility");

                // Try the compilation approach first
                Action<CustomAgent> compiledAbility = null;

                // Wrap the file content in a complete class definition
                string fullCode = @"
        using UnityEngine;
        using System;
        public static class DynamicAbility {
            public static void UseAbility(CustomAgent agent) {
                " + codeContent + @"
            }
        }
        ";

                Debug.Log($"Attempting to compile ability: {abilityName}");
                compiledAbility = CompileAbility(fullCode);

                // If compilation fails, use the template-based approach
                if (compiledAbility == null)
                {
                    Debug.Log("Compilation failed, using template-based approach instead");
                    compiledAbility = DetermineAppropriateAbility(codeContent, abilityName);
                }

                if (compiledAbility != null)
                {
                    abilities.Add(new AbilityInfo(abilityName, compiledAbility));
                    Debug.Log("Loaded new ability: " + abilityName);

                    // Store current ability name
                    _currentAbilityName = abilityName;

                    // Report to LLM Manager
                    if (llmManager != null && customAgent != null)
                    {
                        llmManager.RecordAgentStrategy(
                            customAgent.agentId,
                            customAgent.teamID,
                            "AbilityAcquisition",
                            $"Agent acquired new ability: {abilityName}",
                            0.8f
                        );
                    }
                }
            }

            // Method to determine ability type from name and code
            private AbilityType DetermineAbilityType(string abilityName, string codeContent)
            {
                string lowerName = abilityName.ToLower();
                string lowerCode = codeContent.ToLower();

                if (lowerName.Contains("defensive") ||
                    lowerCode.Contains("heal") ||
                    lowerCode.Contains("shield") ||
                    lowerCode.Contains("protect"))
                {
                    return AbilityType.Defensive;
                }
                else if (lowerName.Contains("aggressive") ||
                        lowerCode.Contains("blast") ||
                        lowerCode.Contains("attack") ||
                        lowerCode.Contains("damage"))
                {
                    return AbilityType.Offensive;
                }
                else
                {
                    return AbilityType.Utility;
                }
            }

            // New method to determine which ability to use based on the code content
            Action<CustomAgent> DetermineAppropriateAbility(string codeContent, string abilityName)
            {
                codeContent = codeContent.ToLower();

                if (codeContent.Contains("dash") || codeContent.Contains("move") || codeContent.Contains("teleport"))
                {
                    Debug.Log("Selected Dash ability template");
                    return DashAbility;
                }
                else if (codeContent.Contains("heal") || codeContent.Contains("health"))
                {
                    Debug.Log("Selected Healing ability template");
                    return HealAbility;
                }
                else if (codeContent.Contains("shield") || codeContent.Contains("protect") || codeContent.Contains("defense"))
                {
                    Debug.Log("Selected Shield ability template");
                    return ShieldAbility;
                }
                else if (codeContent.Contains("blast") || codeContent.Contains("attack") ||
                        codeContent.Contains("damage") || codeContent.Contains("energy"))
                {
                    Debug.Log("Selected Energy Blast ability template");
                    return EnergyBlastAbility;
                }
                else
                {
                    // Default to Dash if we can't determine the ability type
                    Debug.Log("Could not determine ability type from code, defaulting to Dash");
                    return DashAbility;
                }
            }

            // Template ability implementations - Updated for direct reward calculation
            private void DashAbility(CustomAgent agent)
            {
                Vector3 forward = agent.transform.forward;
                float dashDistance = 7.5f;
                Vector3 originalPosition = agent.transform.position;
                Vector3 targetPosition = originalPosition + forward * dashDistance;

                // Check for collisions
                RaycastHit hit;
                bool hitObstacle = Physics.Raycast(originalPosition, forward, out hit, dashDistance);
                if (hitObstacle) {
                    targetPosition = hit.point - (forward * 0.5f);
                    Debug.Log($"[Ability] Dash adjusted to avoid collision with {hit.collider.gameObject.name}");
                }

                // Apply the dash
                agent.transform.position = targetPosition;

                // Calculate actual distance traveled
                float distanceTraveled = Vector3.Distance(originalPosition, agent.transform.position);

                // Base reward calculation - more reward for longer dashes that don't hit obstacles
                float baseReward = 0.05f * (distanceTraveled / dashDistance);
                if (hitObstacle) {
                    // Reduced reward for hitting obstacle
                    baseReward *= 0.5f;
                }
                agent.AddReward(baseReward);

                // Report the outcome
                Debug.Log($"[Ability] Dash completed! Traveled {distanceTraveled:F1} units. Base reward: {baseReward:F3}");

                // Agent-specific reward logic
                if (_isAgent1)  // Agent_1
                {
                    // Calculate if we're dashing toward the target
                    bool dashingTowardTarget = false;
                    float targetReward = 0f;

                    if (agent.target != null)
                    {
                        Vector3 dirToTarget = (agent.target.position - originalPosition).normalized;
                        float dotToTarget = Vector3.Dot(forward, dirToTarget);
                        float distanceToTarget = Vector3.Distance(originalPosition, agent.target.position);
                        float newDistanceToTarget = Vector3.Distance(agent.transform.position, agent.target.position);

                        // Check if we're moving toward target (positive dot product and distance decreased)
                        if (dotToTarget > 0.5f && newDistanceToTarget < distanceToTarget)
                        {
                            dashingTowardTarget = true;
                            float distanceReduction = distanceToTarget - newDistanceToTarget;
                            targetReward = 0.1f * (distanceReduction / dashDistance);
                            agent.AddReward(targetReward);
                            Debug.Log($"[Ability] Dash moved toward target by {distanceReduction:F2} units. Reward: {targetReward:F3}");
                        }
                    }

                    // Check if we're dashing away from an opponent (Agent_2)
                    CustomAgent nearestOpponent = AgentRegistry.Instance.FindClosestOpponent(agent.transform.position, agent.teamID, 15f);
                    if (nearestOpponent != null)
                    {
                        Vector3 dirToOpponent = (nearestOpponent.transform.position - originalPosition).normalized;
                        float dotToOpponent = Vector3.Dot(forward, dirToOpponent);
                        float originalDistToOpponent = Vector3.Distance(originalPosition, nearestOpponent.transform.position);
                        float newDistToOpponent = Vector3.Distance(agent.transform.position, nearestOpponent.transform.position);

                        // If we're dashing away from opponent (negative dot product or increased distance)
                        if (dotToOpponent < -0.3f || newDistToOpponent > originalDistToOpponent)
                        {
                            float distanceGain = newDistToOpponent - originalDistToOpponent;
                            float escapeReward = 0.05f * Mathf.Clamp01(distanceGain / dashDistance);
                            agent.AddReward(escapeReward);
                            Debug.Log($"[Ability] Dash avoided opponent by {distanceGain:F2} units. Reward: {escapeReward:F3}");
                        }
                        // If we're not moving toward target and instead moving toward opponent, small penalty
                        else if (!dashingTowardTarget && dotToOpponent > 0.5f)
                        {
                            float penalty = -0.03f;
                            agent.AddReward(penalty);
                            Debug.Log($"[Ability] Dash moved toward opponent instead of target. Penalty: {penalty:F3}");
                        }
                    }
                }
                else if (_isAgent2)  // Agent_2
                {
                    // Check if we're dashing toward Agent_1
                    CustomAgent opponent = null;
                    foreach (var foundAgent in AgentRegistry.Instance.GetNearbyAgents(agent.transform.position, 20f))
                    {
                        if (_agent1TeamIDs.Contains(foundAgent.teamID))
                        {
                            opponent = foundAgent;
                            break;
                        }
                    }

                    if (opponent != null)
                    {
                        Vector3 dirToOpponent = (opponent.transform.position - originalPosition).normalized;
                        float dotToOpponent = Vector3.Dot(forward, dirToOpponent);
                        float originalDistToOpponent = Vector3.Distance(originalPosition, opponent.transform.position);
                        float newDistToOpponent = Vector3.Distance(agent.transform.position, opponent.transform.position);

                        // If we're dashing toward Agent_1 (positive dot product and decreased distance)
                        if (dotToOpponent > 0.5f && newDistToOpponent < originalDistToOpponent)
                        {
                            float distanceReduction = originalDistToOpponent - newDistToOpponent;
                            float pursuitReward = 0.15f * (distanceReduction / dashDistance);
                            agent.AddReward(pursuitReward);
                            Debug.Log($"[Ability] Dash closed distance to Agent_1 by {distanceReduction:F2} units. Reward: {pursuitReward:F3}");
                        }
                        // If we're dashing away from Agent_1, add penalty
                        else if (dotToOpponent < -0.3f || newDistToOpponent > originalDistToOpponent)
                        {
                            float distanceGain = newDistToOpponent - originalDistToOpponent;
                            float retreatPenalty = -0.05f * Mathf.Clamp01(distanceGain / dashDistance);
                            agent.AddReward(retreatPenalty);
                            Debug.Log($"[Ability] Dash retreated from Agent_1 by {distanceGain:F2} units. Penalty: {retreatPenalty:F3}");
                        }
                    }
                    else
                    {
                        // No Agent_1 found, explore mode - reward for longer, unobstructed dashes
                        float explorationReward = 0.02f * (distanceTraveled / dashDistance);
                        agent.AddReward(explorationReward);
                        Debug.Log($"[Ability] Dash exploration mode. Reward: {explorationReward:F3}");
                    }
                }
                else  // Generic agent that isn't Agent_1 or Agent_2
                {
                    // Basic distance-based reward
                    float genericReward = 0.05f * (distanceTraveled / dashDistance);
                    agent.AddReward(genericReward);
                    Debug.Log($"[Ability] Dash generic distance reward: {genericReward:F3}");
                }

                // Save this ability's usage for learning
                RecordAbilityUse(baseReward);
            }

            private void ShieldAbility(CustomAgent agent)
            {
                AgentHealthSystem health = agent.GetComponent<AgentHealthSystem>();
                if (health != null) {
                    // Calculate health before the boost
                    float healthBefore = health.currentHealth;

                    // Apply health boost
                    float healthBoost = 15f;
                    health.currentHealth = Mathf.Min(health.maxHealth, health.currentHealth + healthBoost);

                    // Calculate actual health gained
                    float actualHealthGained = health.currentHealth - healthBefore;

                    // Base reward - proportional to how much health was actually gained
                    float baseReward = actualHealthGained / healthBoost * 0.1f;
                    agent.AddReward(baseReward);

                    Debug.Log($"[Ability] Shield activated! +{actualHealthGained:F1} health. Reward: {baseReward:F3}");

                    // Agent-specific reward logic
                    if (_isAgent1)
                    {
                        // Agent_1 specific reward logic - rewarded for healing more when closer to target
                        float distanceToTarget = 0f;
                        if (agent.target != null)
                        {
                            distanceToTarget = Vector3.Distance(agent.transform.position, agent.target.position);
                            float proximityBonus = Mathf.Clamp01(1.0f - (distanceToTarget / 10f)) * 0.05f;
                            agent.AddReward(proximityBonus);
                            Debug.Log($"[Ability] Shield Burst - Agent_1 proximity bonus: {proximityBonus:F3}");
                        }
                    }
                    else if (_isAgent2)
                    {
                        // Agent_2 specific reward logic - rewarded for healing when near Agent_1
                        CustomAgent nearestOpponent = AgentRegistry.Instance.FindClosestOpponent(agent.transform.position, agent.teamID, 10f);
                        if (nearestOpponent != null && _agent1TeamIDs.Contains(nearestOpponent.teamID))
                        {
                            float distanceToOpponent = Vector3.Distance(agent.transform.position, nearestOpponent.transform.position);
                            float tacticalBonus = Mathf.Clamp01(1.0f - (distanceToOpponent / 8f)) * 0.05f;
                            agent.AddReward(tacticalBonus);
                            Debug.Log($"[Ability] Shield Burst - Agent_2 tactical bonus: {tacticalBonus:F3}");
                        }
                    }

                    // Additional reward or penalty based on tactical situation
                    if (health.currentHealth < health.maxHealth * 0.5f) {
                        // Extra reward for using when health is low (good timing)
                        float timingBonus = 0.05f;
                        agent.AddReward(timingBonus);
                        Debug.Log($"[Ability] Shield Burst good timing bonus: {timingBonus:F3}");
                    }
                    else if (health.currentHealth == health.maxHealth) {
                        // Small penalty for using at full health (wasteful)
                        float wastePenalty = -0.02f;
                        agent.AddReward(wastePenalty);
                        Debug.Log($"[Ability] Shield Burst wasted at full health: {wastePenalty:F3}");
                    }

                    // Record the overall reward
                    RecordAbilityUse(baseReward);
                } else {
                    Debug.LogWarning("[Ability] Shield Burst failed - no health system found.");
                    agent.AddReward(-0.01f); // Small penalty for failure
                    RecordAbilityUse(-0.01f);
                }
            }

            private void EnergyBlastAbility(CustomAgent agent)
            {
                List<CustomAgent> hitAgents = new List<CustomAgent>();
                int affectedAgents = 0;
                int affectedOpponents = 0;

                // Define blast parameters
                float blastRadius = 8f;
                float blastForce = 15f;
                float minDamage = 5f;

                // Apply blast force to nearby agents
                Collider[] hitColliders = Physics.OverlapSphere(agent.transform.position, blastRadius);

                foreach (var hitCollider in hitColliders) {
                    CustomAgent targetAgent = hitCollider.GetComponent<CustomAgent>();
                    if (targetAgent != null && targetAgent != agent) {
                        // Calculate direction and distance
                        Vector3 direction = (targetAgent.transform.position - agent.transform.position).normalized;
                        float distance = Vector3.Distance(agent.transform.position, targetAgent.transform.position);

                        // Calculate force based on distance (stronger closer to the blast)
                        float forceMagnitude = blastForce * (1 - distance/blastRadius);

                        // Apply force to the target using their movement system
                        AgentMovementSystem targetMovement = targetAgent.GetComponent<AgentMovementSystem>();
                        if (targetMovement != null) {
                            // Apply knockback effect
                            targetMovement.ApplyForce(direction * forceMagnitude, 0.5f);
                        }

                        // Track all affected agents
                        affectedAgents++;
                        hitAgents.Add(targetAgent);

                        // Apply damage if it's an opponent
                        if (targetAgent.teamID != agent.teamID) {
                            // Calculate damage based on distance (more damage closer to the blast)
                            float damage = minDamage * (1 - distance/blastRadius);

                            // Create damage event
                            AgentEventSystem.AgentEvent attackEvent = new AgentEventSystem.AgentEvent(
                                agent.agentId, targetAgent.transform.position, 0.5f, "Attack");
                            attackEvent.data["damage"] = damage;
                            attackEvent.data["bypassBlock"] = true;
                            AgentEventSystem.Instance.BroadcastEvent(attackEvent);

                            affectedOpponents++;
                        }
                    }
                }

                // Base reward calculation
                float baseReward = 0f;
                if (affectedOpponents > 0) {
                    // More reward for affecting more opponents
                    baseReward = Mathf.Min(affectedOpponents * 0.04f, 0.2f);
                    agent.AddReward(baseReward);
                    Debug.Log($"[Ability] Energy Blast affected {affectedOpponents} opponents! Base reward: {baseReward:F3}");
                } else if (affectedAgents > 0) {
                    // Small penalty for only affecting allies
                    baseReward = -0.02f;
                    agent.AddReward(baseReward);
                    Debug.Log($"[Ability] Energy Blast only affected allies. Penalty: {baseReward:F3}");
                } else {
                    // Larger penalty for not affecting anyone
                    baseReward = -0.05f;
                    agent.AddReward(baseReward);
                    Debug.Log($"[Ability] Energy Blast missed everyone! Penalty: {baseReward:F3}");
                }

                // Agent-specific reward logic
                if (_isAgent1 && affectedOpponents > 0 && agent.target != null) {
                    float targetProximityBonus = 0f;

                    foreach (var hitAgent in hitAgents) {
                        if (hitAgent != null && hitAgent.teamID != agent.teamID) {
                            float distanceToTarget = Vector3.Distance(hitAgent.transform.position, agent.target.position);
                            targetProximityBonus += Mathf.Clamp01(1.0f - (distanceToTarget / 10f)) * 0.02f;
                        }
                    }

                    if (targetProximityBonus > 0) {
                        agent.AddReward(targetProximityBonus);
                        Debug.Log($"[Ability] Energy Blast - Agent_1 strategic positioning bonus: {targetProximityBonus:F3}");
                    }
                }
                else if (_isAgent2 && affectedOpponents > 0) {
                    float targetHitBonus = 0f;

                    foreach (var hitAgent in hitAgents) {
                        if (hitAgent != null && _agent1TeamIDs.Contains(hitAgent.teamID)) {
                            targetHitBonus += 0.05f;
                        }
                    }

                    if (targetHitBonus > 0) {
                        agent.AddReward(targetHitBonus);
                        Debug.Log($"[Ability] Energy Blast - Agent_2 primary target bonus: {targetHitBonus:F3}");
                    }
                }

                // Record the overall ability usage
                RecordAbilityUse(baseReward);

                // Visual effect (in a real implementation, you would instantiate a particle system)
                Debug.Log($"[Ability] Energy Blast affected a total of {affectedAgents} agents!");
            }

            private void HealAbility(CustomAgent agent)
            {
                AgentHealthSystem health = agent.GetComponent<AgentHealthSystem>();
                if (health != null) {
                    // Define healing parameters
                    float healAmount = 20f;
                    float healRadius = 5f;

                    // Track state before healing
                    float selfHealthBefore = health.currentHealth;

                    // Heal self first
                    health.currentHealth = Mathf.Min(health.maxHealth, health.currentHealth + healAmount);
                    float selfHealingApplied = health.currentHealth - selfHealthBefore;

                    // Calculate base reward based on healing amount
                    float baseReward = 0.05f * (selfHealingApplied / healAmount);
                    agent.AddReward(baseReward);

                    // Heal nearby allies
                    int alliesHealed = 0;
                    float totalHealingApplied = selfHealingApplied;

                    Collider[] hitColliders = Physics.OverlapSphere(agent.transform.position, healRadius);
                    foreach (var hitCollider in hitColliders) {
                        CustomAgent targetAgent = hitCollider.GetComponent<CustomAgent>();
                        if (targetAgent != null && targetAgent != agent && targetAgent.teamID == agent.teamID) {
                            // Apply healing to ally
                            AgentHealthSystem allyHealth = targetAgent.GetComponent<AgentHealthSystem>();
                            if (allyHealth != null) {
                                float allyHealthBefore = allyHealth.currentHealth;
                                allyHealth.currentHealth = Mathf.Min(allyHealth.maxHealth, allyHealth.currentHealth + healAmount * 0.5f);
                                float allyHealingApplied = allyHealth.currentHealth - allyHealthBefore;

                                totalHealingApplied += allyHealingApplied;
                                alliesHealed++;

                                // Create a healing event
                                AgentEventSystem.AgentEvent healEvent = new AgentEventSystem.AgentEvent(
                                    agent.agentId, targetAgent.transform.position, 0.5f, "Heal");
                                healEvent.data["amount"] = allyHealingApplied;
                                AgentEventSystem.Instance.BroadcastEvent(healEvent);
                            }
                        }
                    }

                    // Additional reward for healing allies
                    float allyBonus = 0.02f * alliesHealed;
                    agent.AddReward(allyBonus);

                    Debug.Log($"[Ability] Healing Pulse healed self for {selfHealingApplied:F1} and {alliesHealed} allies for a total of {totalHealingApplied:F1} health. Rewards: {baseReward:F3} + {allyBonus:F3}");

                    // Agent-specific rewards
                    if (_isAgent1)
                    {
                        // Agent_1: Higher reward for healing when near target
                        if (agent.target != null)
                        {
                            float distanceToTarget = Vector3.Distance(agent.transform.position, agent.target.position);
                            float proximityBonus = Mathf.Clamp01(1.0f - (distanceToTarget / 10f)) * 0.05f;
                            agent.AddReward(proximityBonus);
                            Debug.Log($"[Ability] Healing Pulse - Agent_1 proximity bonus: {proximityBonus:F3}");
                        }
                    }
                    else if (_isAgent2)
                    {
                        // Agent_2: Higher reward for healing in proximity to Agent_1
                        CustomAgent agent1 = null;
                        foreach (var foundAgent in AgentRegistry.Instance.GetNearbyAgents(agent.transform.position, 20f))
                        {
                            if (_agent1TeamIDs.Contains(foundAgent.teamID))
                            {
                                agent1 = foundAgent;
                                break;
                            }
                        }

                        if (agent1 != null)
                        {
                            float distanceToAgent1 = Vector3.Distance(agent.transform.position, agent1.transform.position);
                            float proximityBonus = Mathf.Clamp01(1.0f - (distanceToAgent1 / 15f)) * 0.04f;
                            agent.AddReward(proximityBonus);
                            Debug.Log($"[Ability] Healing Pulse - Agent_2 tactical bonus: {proximityBonus:F3}");
                        }
                    }

                    // Record the overall reward
                    RecordAbilityUse(baseReward + allyBonus);
                } else {
                    Debug.LogWarning("[Ability] Healing Pulse failed - no health system found");
                    agent.AddReward(-0.01f); // Small penalty for failure
                    RecordAbilityUse(-0.01f);
                }
            }

            Action<CustomAgent> CompileAbility(string sourceCode)
            {
                try
                {
                    // Create a new code provider
                    CSharpCodeProvider provider = new CSharpCodeProvider();

                    // Create compiler parameters with more careful assembly handling
                    CompilerParameters parameters = new CompilerParameters();
                    parameters.GenerateInMemory = true;
                    parameters.TreatWarningsAsErrors = false;

                    // Explicitly reference only what we need
                    parameters.ReferencedAssemblies.Add(typeof(object).Assembly.Location); // mscorlib
                    parameters.ReferencedAssemblies.Add(typeof(UnityEngine.Object).Assembly.Location); // UnityEngine
                    parameters.ReferencedAssemblies.Add(typeof(CustomAgent).Assembly.Location); // Assembly containing CustomAgent

                    // Add reference to Unity ML-Agents assembly
                    string mlAgentsAssemblyName = "Unity.ML-Agents";
                    string netStandardAssemblyName = "netstandard";
                    bool foundMlAgents = false;
                    bool foundNetStandard = false;

                    // Try to find needed assemblies in currently loaded assemblies
                    foreach (Assembly loadedAssembly in AppDomain.CurrentDomain.GetAssemblies())
                    {
                        string assemblyName = loadedAssembly.GetName().Name;

                        if (assemblyName == mlAgentsAssemblyName)
                        {
                            string path = loadedAssembly.Location;
                            if (!string.IsNullOrEmpty(path))
                            {
                                parameters.ReferencedAssemblies.Add(path);
                                foundMlAgents = true;
                                Debug.Log($"Found ML-Agents assembly at: {path}");
                            }
                        }
                        else if (assemblyName == netStandardAssemblyName)
                        {
                            string path = loadedAssembly.Location;
                            if (!string.IsNullOrEmpty(path))
                            {
                                parameters.ReferencedAssemblies.Add(path);
                                foundNetStandard = true;
                                Debug.Log($"Found netstandard assembly at: {path}");
                            }
                        }
                    }

                    // Log if we couldn't find either assembly
                    if (!foundMlAgents)
                    {
                        Debug.LogWarning("Could not find ML-Agents assembly in loaded assemblies.");
                    }

                    if (!foundNetStandard)
                    {
                        Debug.LogWarning("Could not find netstandard assembly in loaded assemblies.");

                        // Try to use our helper method to find netstandard.dll in other locations
                        string netStandardPath = GetNetStandardPath();
                        if (!string.IsNullOrEmpty(netStandardPath))
                        {
                            parameters.ReferencedAssemblies.Add(netStandardPath);
                            foundNetStandard = true;
                            Debug.Log($"Found netstandard assembly using helper at: {netStandardPath}");
                        }
                        else
                        {
                            // Try to look for netstandard in common runtime paths
                            string[] possiblePaths = new string[] {
                                // Common paths where netstandard might be found
                                Path.Combine(UnityEngine.Application.dataPath, "../Library/ScriptAssemblies/netstandard.dll"),
                                Path.Combine(UnityEngine.Application.dataPath, "../Packages/com.unity.nuget.newtonsoft-json/Runtime/Newtonsoft.Json.dll")
                            };

                            foreach (string path in possiblePaths)
                            {
                                if (File.Exists(path))
                                {
                                    parameters.ReferencedAssemblies.Add(path);
                                    foundNetStandard = true;
                                    Debug.Log($"Found potential netstandard reference at: {path}");
                                    break;
                                }
                            }
                        }
                    }

                    // If we still couldn't find netstandard, explicitly add a reference to it
                    if (!foundNetStandard)
                    {
                        // Try to add a reference by assembly name rather than path
                        parameters.ReferencedAssemblies.Add("netstandard.dll");
                        Debug.Log("Added reference to netstandard.dll by name");
                    }

                    // Simplify the ability code to avoid dependencies
                    // Modify the source code template to ensure it doesn't need ML-Agents or netstandard
                    sourceCode = @"
            using UnityEngine;
            using System;
            public static class DynamicAbility {
                public static void UseAbility(CustomAgent agent) {
                    try {
                        // Simplified version without external dependencies
                        " + sourceCode.Replace("using Unity.MLAgents;", "").Replace("using Unity.MLAgents.Actuators;", "") + @"
                    }
                    catch (Exception ex) {
                        UnityEngine.Debug.LogError($""Error in dynamic ability: {ex.Message}"");
                    }
                }
            }
            ";

                    // Compile the assembly
                    Debug.Log($"Compiling ability code with {parameters.ReferencedAssemblies.Count} referenced assemblies");
                    CompilerResults results = provider.CompileAssemblyFromSource(parameters, sourceCode);

                    // Check for errors
                    if (results.Errors.HasErrors)
                    {
                        StringBuilder errorMessages = new StringBuilder();
                        errorMessages.AppendLine("Ability compile errors:");

                        foreach (CompilerError error in results.Errors)
                        {
                            errorMessages.AppendLine($"Line {error.Line}: {error.ErrorText}");
                        }

                        Debug.LogError(errorMessages.ToString());
                        return null;
                    }

                    // Get the compiled type and method
                    Assembly assembly = results.CompiledAssembly;
                    Type abilityType = assembly.GetType("DynamicAbility");

                    if (abilityType == null)
                    {
                        Debug.LogError("Could not find DynamicAbility type in the compiled assembly");
                        return null;
                    }

                    MethodInfo method = abilityType.GetMethod("UseAbility", BindingFlags.Public | BindingFlags.Static);

                    if (method == null)
                    {
                        Debug.LogError("Could not find UseAbility method in the DynamicAbility type");
                        return null;
                    }

                    return (Action<CustomAgent>)Delegate.CreateDelegate(typeof(Action<CustomAgent>), method);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"Exception during ability compilation: {ex.Message}\n{ex.StackTrace}");

                    // Fall back to template-based abilities instead
                    Debug.Log("Falling back to template-based ability selection...");
                    return null;
                }
            }

            // Helper method to find netstandard.dll in various locations
            private string GetNetStandardPath()
            {
                // Try to find netstandard in common installation folders
                string[] possiblePaths = new string[]
                {
                    // Unity locations
                    Path.Combine(UnityEngine.Application.dataPath, "../Library/ScriptAssemblies/netstandard.dll"),
                    Path.Combine(UnityEngine.Application.dataPath, "Plugins/netstandard.dll"),

                    // Common .NET Core SDK locations
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet/shared/Microsoft.NETCore.App/2.1.0/netstandard.dll"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet/shared/Microsoft.NETCore.App/3.1.0/netstandard.dll"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet/shared/Microsoft.NETCore.App/5.0.0/netstandard.dll"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet/shared/Microsoft.NETCore.App/6.0.0/netstandard.dll"),

                    // Unity Package Manager locations
                    Path.Combine(UnityEngine.Application.dataPath, "../Library/PackageCache/com.unity.nuget.newtonsoft-json/Runtime/AOT/netstandard2.0/Newtonsoft.Json.dll"),

                    // Mono locations (for older Unity versions)
                    "/usr/local/lib/mono/4.5/netstandard.dll",
                    "C:/Program Files/Unity/Hub/Editor/2020.3.0f1/Editor/Data/MonoBleedingEdge/lib/mono/4.5/netstandard.dll",
                    "C:/Program Files/Unity/Hub/Editor/2021.3.0f1/Editor/Data/MonoBleedingEdge/lib/mono/4.5/netstandard.dll",
                    "C:/Program Files/Unity/Hub/Editor/2022.3.0f1/Editor/Data/MonoBleedingEdge/lib/mono/4.5/netstandard.dll"
                };

                foreach (string path in possiblePaths)
                {
                    if (File.Exists(path))
                    {
                        Debug.Log($"Found netstandard.dll at: {path}");
                        return path;
                    }
                }

                // Try to find in GAC
                try
                {
                    string gacPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Microsoft.NET", "assembly");
                    if (Directory.Exists(gacPath))
                    {
                        string[] netStandardPaths = Directory.GetFiles(gacPath, "netstandard.dll", SearchOption.AllDirectories);
                        if (netStandardPaths.Length > 0)
                        {
                            Debug.Log($"Found netstandard.dll in GAC at: {netStandardPaths[0]}");
                            return netStandardPaths[0];
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"Error searching GAC: {ex.Message}");
                }

                // If all else fails, try unity editor data folder
                try
                {
                    string unityEditorPath = Path.GetDirectoryName(UnityEditor.EditorApplication.applicationPath);
                    string netStandardInEditor = Path.Combine(unityEditorPath, "Data", "NetStandard", "compat", "2.0.0", "shims", "netstandard", "netstandard.dll");
                    if (File.Exists(netStandardInEditor))
                    {
                        Debug.Log($"Found netstandard.dll in Unity Editor folder: {netStandardInEditor}");
                        return netStandardInEditor;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"Error searching Unity Editor path: {ex.Message}");
                }

                Debug.LogWarning("Could not locate netstandard.dll in any common location");
                return null;
            }

            // ----------------------------
            // Use an Ability (by Index)
            // ----------------------------
            public bool TryUseAbility(int index)
            {
                if (index < 0 || index >= abilities.Count)
                {
                    Debug.LogWarning("Invalid ability index selected.");
                    return false;
                }
                if (currentEnergy < abilityCost)
                {
                    Debug.Log("Insufficient Energy to use ability. Current Energy: " + currentEnergy);
                    return false;
                }

                // Track ability usage
                lastUsedAbilityIndex = index;
                timeOfLastAbilityUse = Time.time;
                abilities[index].usageCount++;
                _currentAbilityName = abilities[index].abilityName;

                // Consume energy
                currentEnergy -= abilityCost;

                // Use the ability
                abilities[index].abilityAction.Invoke(customAgent);

                // Log usage
                Debug.Log("Used ability: " + abilities[index].abilityName +
                         ". Remaining Energy: " + currentEnergy +
                         ". Usage count: " + abilities[index].usageCount);

                // Report to LLM Manager
                if (llmManager != null && customAgent != null)
                {
                    llmManager.RecordAgentStrategy(
                        customAgent.agentId,
                        customAgent.teamID,
                        "AbilityUsage",
                        $"Agent used ability: {abilities[index].abilityName}",
                        abilities[index].effectiveness
                    );
                }

                return true;
            }

            // ----------------------------
            // Record Rewards After Ability Usage
            // ----------------------------
            public void RecordAbilityUse(float reward)
            {
                // Store reward for analysis
                recentAbilityRewards[rewardIndex] = reward;
                rewardIndex = (rewardIndex + 1) % recentAbilityRewards.Length;

                // Update the ability's average reward
                if (lastUsedAbilityIndex >= 0 && lastUsedAbilityIndex < abilities.Count)
                {
                    AbilityInfo ability = abilities[lastUsedAbilityIndex];
                    ability.avgReward = ((ability.avgReward * (ability.usageCount - 1)) + reward) / ability.usageCount;

                    // Update the effectiveness (for tracking purposes, not used for rewards now)
                    float lerpFactor = 0.2f;
                    ability.effectiveness = Mathf.Lerp(ability.effectiveness, Mathf.Clamp01((reward + 1f) / 2f), lerpFactor);

                    // Report to LLM Manager
                    if (llmManager != null && customAgent != null)
                    {
                        llmManager.RecordAgentStrategy(
                            customAgent.agentId,
                            customAgent.teamID,
                            "AbilityEffectiveness",
                            $"Ability {ability.abilityName} effectiveness: {ability.effectiveness:F2}",
                            ability.effectiveness
                        );

                        llmManager.RecordAgentReward(
                            customAgent.agentId,
                            customAgent.teamID,
                            reward,
                            $"Ability:{ability.abilityName}",
                            customAgent.transform.position
                        );
                    }
                }
            }

            // ----------------------------
            // Send current ability state to LLM Manager
            // ----------------------------
            private void SendAbilityStateToLLM()
            {
                if (llmManager == null || customAgent == null || abilities.Count == 0)
                    return;

                // Create an observation context for the abilities
                AgentObservation.ObservationContext context = AgentObservation.ObservationContext.None;

                // Generate a summary of all abilities
                string abilityDescription = "Current abilities: ";
                for (int i = 0; i < abilities.Count; i++)
                {
                    AbilityInfo ability = abilities[i];
                    abilityDescription += $"{ability.abilityName} (eff:{ability.effectiveness:F2}, uses:{ability.usageCount}) ";
                }

                // Send to LLM manager for strategic analysis
                float[] abilityStats = new float[abilities.Count * 3]; // effectiveness, usageCount, avgReward for each
                for (int i = 0; i < abilities.Count; i++)
                {
                    abilityStats[i*3] = abilities[i].effectiveness;
                    abilityStats[i*3+1] = abilities[i].usageCount;
                    abilityStats[i*3+2] = abilities[i].avgReward;
                }

                llmManager.RecordAgentObservations(
                    customAgent.agentId,
                    customAgent.teamID,
                    abilityStats,
                    context
                );

                // Also record as strategy information
                llmManager.RecordAgentStrategy(
                    customAgent.agentId,
                    customAgent.teamID,
                    "AbilityInventory",
                    abilityDescription,
                    CalculateAveragePerformance()
                );
            }

            // ----------------------------
            // Fixed Ability Observations
            // ----------------------------
            /// <summary>
            /// Returns an array of length maxAbilities (here 3) with the effectiveness values.
            /// For any ability slot not filled, returns a neutral value (0.5).
            /// </summary>
            public float[] GetAbilityObservations()
            {
                float[] obs = new float[maxAbilities];
                for (int i = 0; i < maxAbilities; i++)
                {
                    if (i < abilities.Count)
                        obs[i] = abilities[i].effectiveness;
                    else
                        obs[i] = 0.5f;
                }

                if (debugObservations)
                {
                    string abilityInfo = "Ability Observations:";
                    for (int i = 0; i < obs.Length; i++)
                    {
                        string abilityName = (i < abilities.Count) ? abilities[i].abilityName : "Empty Slot";
                        abilityInfo += $"\n  Slot {i}: {abilityName} ({obs[i]:F2})";
                    }
                    Debug.Log(abilityInfo);
                }

                return obs;
            }

            // ----------------------------
            // Get number of discrete actions for abilities
            // ----------------------------
            public int GetDiscreteActionSize()
            {
                // Return the number of ability slots + 1 (for "no ability used")
                return _abilityDiscreteActionSize;
            }
        }