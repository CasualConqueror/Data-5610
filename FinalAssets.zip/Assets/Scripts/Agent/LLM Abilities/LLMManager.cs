using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AgentKnowledgeSystem;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using UnityEngine;
using UnityEngine.Networking;
using Random = UnityEngine.Random;

/// <summary>
/// Enhanced manager class for integrating with Language Learning Models (LLMs).
/// This class collects agent observations, rewards, and strategies directly from ML Agents
/// to provide context for LLM-based decision making and strategy refinement.
/// </summary>
public class LLMManager : MonoBehaviour
{

    public enum APIRequestType
        {
            NewAbility,
            AbilityReplacement,
            PerformanceAnalysis
        }

    [Header("LLM Integration Settings")]
    [SerializeField] private bool _enableLLMIntegration = true;
    [SerializeField] private int _observationBatchSize = 50;
    [SerializeField] private bool _logObservationsToFile = true;
    [SerializeField] private string _logFilePath = "AgentObservations.log";
    [SerializeField] private bool _detailedLogging = true;

    [Header("ML Agents Integration")]
    [SerializeField] private bool _syncWithMLAgentsRewards = true;
    [SerializeField] private bool _useMLAgentsObservations = true;

    [Header("Event Sampling")]
    [SerializeField] private int _maxStoredEventsPerType = 100;
    [SerializeField] private int _maxAgentsTracked = 10;

    [Header("Ability Generation Settings")]
    [SerializeField] private string _abilityTemplateFolder = "Assets/AbilityTemplates";
    [SerializeField] private float _abilityGenerationInterval = 30f; // Time in seconds between ability generations
    [SerializeField] private bool _useRandomAbilityVariations = true;  // Whether to add randomness to abilities

    [Header("Default Ability Templates")]
    [SerializeField] private TextAsset _defensiveAbilityTemplate;
    [SerializeField] private TextAsset _offensiveAbilityTemplate;
    [SerializeField] private TextAsset _utilityAbilityTemplate;

    [Header("Auto-Generate Templates")]
    [SerializeField] private bool _autoGenerateTemplates = true;
    [SerializeField] private string _templatesFolder = "Assets/AbilityTemplates";
    
    [Header("Agent-Specific Ability Settings")]
    [SerializeField] private bool _useAgentSpecificAbilities = true;
    [Tooltip("If true, abilities will be tailored differently for Agent_1 vs Agent_2")]
    [SerializeField] private List<int> _agent1TeamIDs = new List<int> { 1 };  // Team IDs for Agent_1 
    [SerializeField] private List<int> _agent2TeamIDs = new List<int> { 2 };  // Team IDs for Agent_2

    [Header("LLM API Settings")]
    [SerializeField] private bool _useActualLLMAPI = false;  // Toggle between API mode and default abilities
    [SerializeField] private string _apiKey = "";  // Your API key
    [SerializeField] private string _apiEndpoint = "https://api.openai.com/v1/chat/completions";  // API endpoint URL
    [SerializeField] private string _modelName = "gpt-4o";  // Model to use
    [SerializeField] private float _temperature = 0.7f;  // Model temperature
    [SerializeField] private int _maxTokens = 1000;  // Maximum tokens to generate
    [Tooltip("Maximum cost to allow per day in USD")]
    [SerializeField] private float _maxDailyCost = 5.0f;  // Maximum cost per day

    [Header("ML Agents Effectiveness Thresholds")]
    [SerializeField] private float _abilityReplacementThreshold = 0.3f;  // Replace abilities with effectiveness below this
    [SerializeField] private float _requestNewAbilityThreshold = 0.6f;  // Request new ability when above this
    [SerializeField] private int _minEpisodesBeforeReplacement = 10;  // Minimum episodes before replacing an ability

    // Cost tracking
    private float _dailyCost = 0f;
    private DateTime _lastCostResetDay = DateTime.Now;



    // API request queue
    private Queue<APIRequest> _pendingAPIRequests = new Queue<APIRequest>();
    private bool _isProcessingQueue = false;

    // Dictionary to store observations per agent, now directly from ML Agents
    private Dictionary<int, List<AgentObservationData>> _agentObservations = new Dictionary<int, List<AgentObservationData>>();

    // Dictionary to store rewards per agent, synced with ML Agents rewards
    private Dictionary<int, List<AgentRewardData>> _agentRewards = new Dictionary<int, List<AgentRewardData>>();

    // Dictionary to store strategies per team
    private Dictionary<int, TeamStrategyData> _teamStrategies = new Dictionary<int, TeamStrategyData>();

    // Dictionary to store ability effectiveness data
    private Dictionary<int, Dictionary<string, AbilityEffectivenessData>> _abilityEffectiveness =
        new Dictionary<int, Dictionary<string, AbilityEffectivenessData>>();

    // Track ML Agent episode performance per agent
    private Dictionary<int, Dictionary<string, float>> _episodePerformance =
        new Dictionary<int, Dictionary<string, float>>();

    // Track ML Agent episode counts per agent
    private Dictionary<int, int> _agentEpisodeCounts = new Dictionary<int, int>();

    // Track last ability generation time per agent
    private Dictionary<int, float> _lastAbilityGenerationTimes = new Dictionary<int, float>();

    // Singleton instance
    private static LLMManager _instance;
    public static LLMManager Instance
    {
        get { return _instance; }
    }

    private void Awake()
    {
        // If no instance exists, make this object the singleton.
        if (_instance == null)
        {
            _instance = this;
            // Remove this object from any parent so it lives in the root.
            transform.SetParent(null);
            // Mark this object so that it is not destroyed on scene loads.
            DontDestroyOnLoad(gameObject);

            // Perform initial setup.
            InitializeLogFile();

            // Ensure the ability template folder exists.
            if (!Directory.Exists(_abilityTemplateFolder))
            {
                Directory.CreateDirectory(_abilityTemplateFolder);
            }

            // Auto-generate templates if enabled.
            if (_autoGenerateTemplates)
            {
                GenerateTemplatesIfNeeded();
            }

            // Load API Key from environment or PlayerPrefs if available
            LoadAPIKey();
        }
        else if (_instance != this)
        {
            // A persistent instance already exists so destroy this duplicate.
            Destroy(gameObject);
            return;
        }
    }

    private void Update()
    {
        // Reset daily cost if it's a new day
        if (DateTime.Now.Day != _lastCostResetDay.Day)
        {
            _dailyCost = 0f;
            _lastCostResetDay = DateTime.Now;
            Debug.Log($"[LLMManager] Daily cost reset to 0.");
        }

        // Process the API request queue
        if (!_isProcessingQueue && _pendingAPIRequests.Count > 0 && _useActualLLMAPI)
        {
            ProcessNextAPIRequest();
        }
    }

    /// <summary>
    /// Record a batch of observations from an agent
    /// </summary>
    public void RecordAgentObservations(int agentId, int teamId, float[] observationData,
                                        AgentObservation.ObservationContext context = AgentObservation.ObservationContext.None)
    {
        if (!_enableLLMIntegration)
            return;

        // Create a new observation record
        AgentObservationData observation = new AgentObservationData
        {
            timestamp = Time.time,
            agentId = agentId,
            teamId = teamId,
            observationContext = context,
            observationData = observationData
        };

        // Add to agent-specific list
        if (!_agentObservations.ContainsKey(agentId))
        {
            _agentObservations[agentId] = new List<AgentObservationData>();
        }

        _agentObservations[agentId].Add(observation);

        // Keep list size manageable
        if (_agentObservations[agentId].Count > _observationBatchSize)
        {
            _agentObservations[agentId].RemoveAt(0);
        }

        // Log to file if enabled
        if (_logObservationsToFile)
        {
            LogObservationToFile(observation);
        }

        // Clean up old data occasionally
        if (Time.frameCount % 1000 == 0)
        {
            CleanupOldData();
        }
    }

    /// <summary>
    /// Record a reward/punishment event for an agent - now syncs with ML Agents reward system
    /// </summary>
    public void RecordAgentReward(int agentId, int teamId, float reward, string reason, Vector3 position)
    {
        if (!_enableLLMIntegration)
            return;

        // Create a new reward record
        AgentRewardData rewardData = new AgentRewardData
        {
            timestamp = Time.time,
            agentId = agentId,
            teamId = teamId,
            reward = reward,
            reason = reason,
            position = position
        };

        // Add to agent-specific list
        if (!_agentRewards.ContainsKey(agentId))
        {
            _agentRewards[agentId] = new List<AgentRewardData>();
        }

        _agentRewards[agentId].Add(rewardData);

        // Keep list size manageable
        if (_agentRewards[agentId].Count > _maxStoredEventsPerType)
        {
            _agentRewards[agentId].RemoveAt(0);
        }

        // Update team strategy data
        UpdateTeamStrategy(teamId, reason, reward);

        // Update ability effectiveness if this is an ability-related reward
        if (reason.Contains("Ability") || reason == "AbilityOutcome")
        {
            UpdateAbilityEffectiveness(agentId, teamId, reason, reward);
        }

        // Log to file if enabled
        if (_logObservationsToFile)
        {
            LogRewardToFile(rewardData);
        }

        // NEW: Report reward to ML Agents stats recorder for tracking
        if (_syncWithMLAgentsRewards)
        {
            // Use StatRecorder to track rewards by category
            Academy.Instance.StatsRecorder.Add($"LLM/{reason}Reward", reward);
        }
    }




    // Note: This method should be placed inside the LLMManager class
    private AbilityType  GetAbilityTypeFromName(string abilityName)
    {
        // Defensive abilities typically have "heal", "shield", "protect" in the name
        if (abilityName.ToLower().Contains("heal") || abilityName.ToLower().Contains("shield") ||
            abilityName.ToLower().Contains("protect") || abilityName.ToLower().Contains("regen"))
        {
            return AbilityType .Defensive;
        }

        // Offensive abilities typically have "blast", "attack", "strike", "damage" in the name
        if (abilityName.ToLower().Contains("blast") || abilityName.ToLower().Contains("attack") ||
            abilityName.ToLower().Contains("strike") || abilityName.ToLower().Contains("damage"))
        {
            return AbilityType .Offensive;
        }

        // Default to utility for everything else
        return AbilityType .Utility;
    }

    // Used to update team strategies in RecordAgentReward method
    private void UpdateTeamStrategy(int teamId, string reason, float reward)
    {
        // Ensure team exists in dictionary
        if (!_teamStrategies.ContainsKey(teamId))
        {
            _teamStrategies[teamId] = new TeamStrategyData
            {
                teamId = teamId,
                strategies = new Dictionary<string, StrategyData>()
            };
        }

        // Map reward reasons to strategy types
        string strategyType;
        if (reason.Contains("Ability"))
        {
            strategyType = "AbilityUsage";
        }
        else if (reason.Contains("Attack"))
        {
            strategyType = "OffensiveStrategy";
        }
        else if (reason.Contains("Defend") || reason.Contains("Block"))
        {
            strategyType = "DefensiveStrategy";
        }
        else if (reason.Contains("Movement") || reason.Contains("Position"))
        {
            strategyType = "PositioningStrategy";
        }
        else if (reason.Contains("Health"))
        {
            strategyType = "HealthPattern";
        }
        else
        {
            strategyType = "GeneralStrategy";
        }

        // Calculate success rate from reward (assuming -1 to 1 range)
        float successRate = Mathf.Clamp01((reward + 1f) / 2f);

        // Update or create strategy entry
        if (!_teamStrategies[teamId].strategies.ContainsKey(strategyType))
        {
            _teamStrategies[teamId].strategies[strategyType] = new StrategyData
            {
                strategyType = strategyType,
                description = reason,
                successRate = successRate,
                lastUpdated = Time.time,
                useCount = 1,
                episodeContext = "Unknown episode"
            };
        }
        else
        {
            var strategy = _teamStrategies[teamId].strategies[strategyType];
            strategy.successRate = Mathf.Lerp(strategy.successRate, successRate, 0.1f); // Rolling average
            strategy.lastUpdated = Time.time;
            strategy.useCount++;
            strategy.description = reason; // Update description
        }
    }

    /// <summary>
    /// Update the effectiveness tracking for abilities - now uses ML Agents performance metrics
    /// </summary>
    private void UpdateAbilityEffectiveness(int agentId, int teamId, string reason, float reward)
    {
        string abilityName = ExtractAbilityNameFromReason(reason);
        if (string.IsNullOrEmpty(abilityName))
            return;

        // Ensure team exists in dictionary
        if (!_abilityEffectiveness.ContainsKey(teamId))
        {
            _abilityEffectiveness[teamId] = new Dictionary<string, AbilityEffectivenessData>();
        }

        // Update or create ability effectiveness entry
        if (!_abilityEffectiveness[teamId].ContainsKey(abilityName))
        {
            _abilityEffectiveness[teamId][abilityName] = new AbilityEffectivenessData
            {
                abilityName = abilityName,
                effectiveness = reward > 0 ? 0.6f : 0.4f,
                useCount = 1,
                totalReward = reward,
                lastUsedTime = Time.time,
                lastReward = reward,
                // Track episodes when this ability was used
                episodeCount = _agentEpisodeCounts.ContainsKey(agentId) ? _agentEpisodeCounts[agentId] : 0
            };
        }
        else
        {
            var abilityData = _abilityEffectiveness[teamId][abilityName];
            abilityData.useCount++;
            abilityData.totalReward += reward;
            abilityData.lastReward = reward;
            abilityData.lastUsedTime = Time.time;

            // Track which episodes used this ability
            abilityData.episodeCount = _agentEpisodeCounts.ContainsKey(agentId) ? _agentEpisodeCounts[agentId] : 0;

            // Calculate rolling average effectiveness using ML Agents context
            // If we have episode performance data, use that to influence effectiveness calculation
            if (_episodePerformance.ContainsKey(agentId) &&
                _episodePerformance[agentId].ContainsKey("AverageReward"))
            {
                // Blend immediate reward with overall episode performance
                float episodeInfluence = 0.4f; // How much overall episode performance affects ability rating
                float immediateInfluence = 0.6f; // How much immediate reward affects ability rating

                float immediateEffectiveness = Mathf.Clamp01((reward + 1f) / 2f); // Convert -1 to 1 range to 0 to 1
                float episodeEffectiveness = Mathf.Clamp01((_episodePerformance[agentId]["AverageReward"] + 1f) / 2f);

                // Weighted blend
                abilityData.effectiveness = Mathf.Lerp(
                    abilityData.effectiveness,
                    (immediateEffectiveness * immediateInfluence) + (episodeEffectiveness * episodeInfluence),
                    0.1f); // Gradual change rate
            }
            else
            {
                // Fallback to original calculation when episode data isn't available
                float avgReward = abilityData.totalReward / abilityData.useCount;
                abilityData.effectiveness = Mathf.Lerp(abilityData.effectiveness,
                                                     Mathf.Clamp01((avgReward + 1f) / 2f), 0.1f);
            }
        }
    }

    /// <summary>
    /// Schedule an ability replacement due to low effectiveness
    /// </summary>
    private void ScheduleAbilityReplacement(int agentId, int teamId, string abilityName, float effectiveness)
    {
        if (!_useActualLLMAPI || string.IsNullOrEmpty(_apiKey))
        {
            // When not using actual API, just log the request
            Debug.Log($"[LLMManager] Would request replacement for ability '{abilityName}' (effectiveness: {effectiveness:F2})");
            return;
        }

        // Check if enough time has passed since last generation
        if (!_lastAbilityGenerationTimes.ContainsKey(agentId))
        {
            _lastAbilityGenerationTimes[agentId] = -_abilityGenerationInterval;
        }

        float timeSinceLastGeneration = Time.time - _lastAbilityGenerationTimes[agentId];
        if (timeSinceLastGeneration < _abilityGenerationInterval)
        {
            Debug.Log($"[LLMManager] Too soon to replace ability '{abilityName}'. " +
                     $"Waiting {_abilityGenerationInterval - timeSinceLastGeneration:F1} more seconds.");
            return;
        }

        // Generate prompt for replacement - now includes ML Agents performance context
        string prompt = GenerateAbilityReplacementPrompt(agentId, teamId, abilityName, effectiveness);

        // Queue API request
        QueueAPIRequest(new APIRequest
        {
            agentId = agentId,
            teamId = teamId,
            prompt = prompt,
            abilityType = GetAbilityTypeFromName(abilityName),
            requestType = APIRequestType.AbilityReplacement,
            abilityToReplace = abilityName
        });

        // Update last generation time
        _lastAbilityGenerationTimes[agentId] = Time.time;
    }
    
    // NEW Method: Get ability suggestions for agent based on observations and rewards
    public AbilitySuggestion GetAbilitySuggestion(int agentId, int teamId, float currentPerformance)
    {
        AbilitySuggestion result = new AbilitySuggestion();

        // Evaluate current agent performance and context
        bool isLowHealth = false;
        bool isUnderAttack = false;
        bool isOffensive = false;

        // Check recent observations for context
        if (_agentObservations.ContainsKey(agentId) && _agentObservations[agentId].Count > 0)
        {
            var recentObs = _agentObservations[agentId][_agentObservations[agentId].Count - 1];

            // Simple heuristic: if observation has damage taken context, agent is under attack
            if (recentObs.observationContext == AgentObservation.ObservationContext.DamageTaken)
            {
                isUnderAttack = true;

                // Check for health level in observations (assuming health is observation 10)
                if (recentObs.observationData.Length > 10 && recentObs.observationData[10] < 0.4f)
                {
                    isLowHealth = true;
                }
            }

            // Check if agent is being offensive
            if (recentObs.observationContext == AgentObservation.ObservationContext.DamageDealt)
            {
                isOffensive = true;
            }
        }

        // Set suggestion based on context
        if (isLowHealth)
        {
            result.recommendedAbilityType = AbilityType.Defensive;
            result.confidence = 0.8f;
            result.reason = "Agent has low health and needs defensive options";
        }
        else if (isUnderAttack)
        {
            result.recommendedAbilityType = AbilityType.Utility;
            result.confidence = 0.7f;
            result.reason = "Agent is under attack and needs mobility or utility";
        }
        else if (isOffensive && currentPerformance > 0.6f)
        {
            result.recommendedAbilityType = AbilityType.Offensive;
            result.confidence = 0.75f;
            result.reason = "Agent is performing well in offensive role";
        }
        else
        {
            // Default balanced suggestion
            result.recommendedAbilityType = AbilityType.Utility;
            result.confidence = 0.5f;
            result.reason = "Balanced ability recommended based on mixed context";
        }

        return result;
    }

    /// <summary>
    /// Generate a prompt for replacing an underperforming ability - now includes ML Agents metrics and discrete actions
    /// </summary>
    private string GenerateAbilityReplacementPrompt(int agentId, int teamId, string abilityName, float effectiveness)
    {
        // Gather recent observations and rewards
        List<string> recentObservations = GetRecentObservationsText(agentId, 3);
        List<string> recentRewards = GetRecentRewardsText(agentId, 3);
        string teamStrategies = GetTeamStrategiesText(teamId);

        // Include ML Agents episode performance data
        string episodePerformance = "No episode data available.";
        if (_episodePerformance.ContainsKey(agentId))
        {
            episodePerformance = $"Average episode reward: {_episodePerformance[agentId]["AverageReward"]:F2}, " +
                                 $"Last episode reward: {_episodePerformance[agentId]["LastReward"]:F2}, " +
                                 $"Episodes completed: {_agentEpisodeCounts[agentId]}";
        }

        string abilityType = GetAbilityTypeFromName(abilityName).ToString().ToLower();
        
        // Determine if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);
        string agentType = isAgent1 ? "Agent_1" : (isAgent2 ? "Agent_2" : "Unknown");

        string agentSpecificGuidance = "";
        if (isAgent1)
        {
            agentSpecificGuidance = "For Agent_1: The agent should be rewarded for dashing towards its target and receive a small reward for dashing away from Agent_2. Punish the agent for improper ability use.";
        }
        else if (isAgent2)
        {
            agentSpecificGuidance = "For Agent_2: The agent should be rewarded for dashing towards Agent_1 and punished for misuse of the ability.";
        }

        return $@"Generate a replacement {abilityType} ability for an agent in a Unity game using ML Agents.

The current ability '{abilityName}' has low effectiveness ({effectiveness:F2}) and needs replacement.

Agent context:
- AgentID: {agentId}
- TeamID: {teamId}
- Agent Type: {agentType}
- Recent observations: {string.Join(", ", recentObservations)}
- Recent rewards: {string.Join(", ", recentRewards)}
- Team strategies: {teamStrategies}
- ML Agents performance: {episodePerformance}

{agentSpecificGuidance}

Design a new {abilityType} ability that:
1. Is implemented for a discrete action system (use or don't use)
2. Uses agent.AddReward() directly instead of effectiveness
3. Does not use NotifyAbilityOutcome()
4. Is self-contained C# code that can run in Unity
5. Uses available agent components (transform, health system, movement system)
6. Includes appropriate visual feedback using Debug.Log statements
7. Works well with the ML Agents reinforcement learning system

Return only the valid C# code with no additional text.";
    }

    /// <summary>
    /// Record an agent strategy or decision - now includes ML Agents performance context
    /// </summary>
    public void RecordAgentStrategy(int agentId, int teamId, string strategyType, string strategyDescription, float successRate)
    {
        if (!_enableLLMIntegration)
            return;

        // Ensure team exists in dictionary
        if (!_teamStrategies.ContainsKey(teamId))
        {
            _teamStrategies[teamId] = new TeamStrategyData
            {
                teamId = teamId,
                strategies = new Dictionary<string, StrategyData>()
            };
        }

        // Update or create strategy entry
        if (!_teamStrategies[teamId].strategies.ContainsKey(strategyType))
        {
            _teamStrategies[teamId].strategies[strategyType] = new StrategyData
            {
                strategyType = strategyType,
                description = strategyDescription,
                successRate = successRate,
                lastUpdated = Time.time,
                useCount = 1,
                // Track episode context
                episodeContext = _agentEpisodeCounts.ContainsKey(agentId) ?
                    $"Episode {_agentEpisodeCounts[agentId]}" : "Unknown episode"
            };
        }
        else
        {
            var strategy = _teamStrategies[teamId].strategies[strategyType];
            strategy.successRate = Mathf.Lerp(strategy.successRate, successRate, 0.1f); // Rolling average
            strategy.lastUpdated = Time.time;
            strategy.useCount++;
            strategy.description = strategyDescription; // Update description

            // Update episode context
            strategy.episodeContext = _agentEpisodeCounts.ContainsKey(agentId) ?
                $"Last updated in episode {_agentEpisodeCounts[agentId]}" : "Unknown episode";
        }

        // Track ability-specific strategies
        if (strategyType == "AbilityUsage" || strategyType == "AbilityEffectiveness")
        {
            string abilityName = ExtractAbilityNameFromReason(strategyDescription);
            if (!string.IsNullOrEmpty(abilityName))
            {
                UpdateAbilityEffectiveness(agentId, teamId, abilityName, successRate * 2 - 1); // Convert 0-1 to -1 to 1
            }
        }

        // Log to file if enabled
        if (_logObservationsToFile && _detailedLogging)
        {
            LogStrategyToFile(agentId, teamId, strategyType, strategyDescription, successRate);
        }

        // Record strategy usage to ML Agents stats for analysis
        if (_syncWithMLAgentsRewards)
        {
            Academy.Instance.StatsRecorder.Add($"Strategy/{strategyType}Count", 1);
            Academy.Instance.StatsRecorder.Add($"Strategy/{strategyType}Success", successRate);
        }
    }

    /// <summary>
    /// Extract ability name from a reason string
    /// </summary>
    private string ExtractAbilityNameFromReason(string reason)
    {
        // Handle ability outcomes directly
        if (reason == "AbilityOutcome")
            return "UnknownAbility"; // Generic fallback

        // Look for patterns like "Ability: Name" or "AbilityName_Outcome"
        if (reason.Contains("Ability:"))
        {
            // Extract name after "Ability:"
            int startIndex = reason.IndexOf("Ability:") + 8;
            int endIndex = reason.IndexOf(" ", startIndex);
            if (endIndex == -1) endIndex = reason.Length;
            return reason.Substring(startIndex, endIndex - startIndex).Trim();
        }
        else if (reason.Contains("Ability_"))
        {
            // Extract between "Ability_" and next underscore or end
            int startIndex = reason.IndexOf("Ability_") + 8;
            int endIndex = reason.IndexOf("_", startIndex);
            if (endIndex == -1) endIndex = reason.Length;
            return reason.Substring(startIndex, endIndex - startIndex).Trim();
        }

        return string.Empty;
    }

    public string GenerateAbility(int agentId, int teamId, float lastScore)
    {
        Debug.Log($"🤖 LLM Suggestion: Agent {agentId} performance score was {lastScore:F2}. Generating ability.");

        // If using actual LLM API, queue a request
        if (_useActualLLMAPI && !string.IsNullOrEmpty(_apiKey))
        {
            // Generate prompt based on ML Agents performance and observations
            string prompt = GenerateAbilityPromptFromMLAgentsContext(agentId, teamId, lastScore);

            // Determine ability type based on agent's current needs and context
            AbilityType  abilityType = DetermineOptimalAbilityType(agentId, teamId);

            // If we have a specific recommendation based on context, use that instead
            AbilitySuggestion contextSuggestion = GetAbilitySuggestion(agentId, teamId, lastScore);
            if (contextSuggestion.confidence > 0.6f)
            {
                abilityType = contextSuggestion.recommendedAbilityType;
                Debug.Log($"[LLMManager] Context analysis suggests {abilityType} ability: {contextSuggestion.reason}");
            }

            // Queue API request
            QueueAPIRequest(new APIRequest
            {
                agentId = agentId,
                teamId = teamId,
                prompt = prompt,
                abilityType = abilityType,
                requestType = APIRequestType.NewAbility
            });

            // Return a placeholder ability until API response is received
            return GetDefaultAbilityByType(abilityType, teamId);
        }

        // Choose an appropriate ability based on agent performance and context
        string abilityCode;

        // Get contextual ability suggestion
        AbilitySuggestion suggestion = GetAbilitySuggestion(agentId, teamId, lastScore);

        // Choose ability based on agent's needs rather than just performance
        if (suggestion.confidence > 0.7f)
        {
            // Use the contextual suggestion
            switch (suggestion.recommendedAbilityType)
            {
                case AbilityType .Defensive:
                    abilityCode = GenerateDefensiveAbility(teamId);
                    break;
                case AbilityType .Offensive:
                    abilityCode = GenerateOffensiveAbility(teamId);
                    break;
                default:
                    abilityCode = GenerateUtilityAbility(teamId);
                    break;
            }

            Debug.Log($"[LLMManager] Generated {suggestion.recommendedAbilityType} ability based on context: {suggestion.reason}");
        }
        else
        {
            // Fall back to performance-based selection if context isn't clear enough
            if (lastScore < 0.3f) {
                abilityCode = GenerateDefensiveAbility(teamId);
                Debug.Log("[LLMManager] Generated defensive ability based on low performance");
            }
            else if (lastScore > 0.7f) {
                abilityCode = GenerateOffensiveAbility(teamId);
                Debug.Log("[LLMManager] Generated offensive ability based on high performance");
            }
            else {
                abilityCode = GenerateUtilityAbility(teamId);
                Debug.Log("[LLMManager] Generated utility ability based on average performance");
            }
        }

        return abilityCode;
    }

    /// <summary>
    /// Generate a prompt for a new ability based on ML Agents context - updated for discrete actions and direct AddReward
    /// </summary>
    private string GenerateAbilityPromptFromMLAgentsContext(int agentId, int teamId, float performance)
    {
        string contextDescription = "The agent has average performance with no specific needs detected.";
        string abilityType = "balanced";

        // Get ability suggestion based on context
        AbilitySuggestion contextSuggestion = GetAbilitySuggestion(agentId, teamId, performance);

        // Determine if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);
        string agentType = isAgent1 ? "Agent_1" : (isAgent2 ? "Agent_2" : "Unknown");

        string agentSpecificGuidance = "";
        if (isAgent1)
        {
            agentSpecificGuidance = "For Agent_1: The agent should be rewarded for dashing towards its target and receive a small reward for dashing away from Agent_2. Punish the agent for improper ability use.";
        }
        else if (isAgent2)
        {
            agentSpecificGuidance = "For Agent_2: The agent should be rewarded for dashing towards Agent_1 and punished for misuse of the ability.";
        }

        // Use suggestion if confidence is high enough
        if (contextSuggestion.confidence > 0.6f)
        {
            contextDescription = contextSuggestion.reason;
            abilityType = contextSuggestion.recommendedAbilityType.ToString().ToLower();
        }
        else
        {
            // Fallback based on performance score
            if (performance < 0.3f)
            {
                abilityType = "defensive";
                contextDescription = "The agent is performing poorly and needs protection or recovery options.";
            }
            else if (performance > 0.7f)
            {
                abilityType = "offensive";
                contextDescription = "The agent is performing well and can take advantage of aggressive options.";
            }
            else
            {
                abilityType = "utility";
                contextDescription = "The agent is performing adequately and could benefit from mobility or strategic options.";
            }
        }

        // Add ML Agents specific context
        string mlAgentsContext = "No ML Agents data available.";
        if (_episodePerformance.ContainsKey(agentId))
        {
            mlAgentsContext = $"The agent has completed {_agentEpisodeCounts[agentId]} training episodes " +
                             $"with an average reward of {_episodePerformance[agentId]["AverageReward"]:F2}.";
        }

        // Add recent events context
        string recentEvents = "";
        if (_agentRewards.ContainsKey(agentId) && _agentRewards[agentId].Count > 0)
        {
            var lastReward = _agentRewards[agentId][_agentRewards[agentId].Count - 1];
            recentEvents = $"The agent recently received a {(lastReward.reward > 0 ? "positive" : "negative")} " +
                           $"reward of {lastReward.reward:F2} for '{lastReward.reason}'.";
        }

        return $@"Generate a {abilityType} ability for an agent in a Unity game using the ML Agents reinforcement learning framework.

Context: {contextDescription}
Agent Type: {agentType}
ML Agents Data: {mlAgentsContext}
Recent Events: {recentEvents}
Performance score: {performance:F2}

{agentSpecificGuidance}

The ability should:
1. Be implemented for a discrete action system (use or don't use)
2. Use agent.AddReward() directly instead of effectiveness measurements
3. Be self-contained C# code that can run in Unity
4. Use available agent components (transform, health system, movement system)
5. Include appropriate visual feedback using Debug.Log statements
6. Work effectively with the ML Agents reinforcement learning system
7. Be designed to improve the agent's performance based on the provided context

For dashing abilities:
- Detect if dashing towards targets/opponents using Vector3.Distance and Vector3.Dot
- Provide appropriate rewards based on the agent type and dash direction
- Apply proper force/movement using transform.position adjustments

Return only the valid C# code with no additional text.";
    }

    /// <summary>
    /// Simulates an LLM call to generate ability code.
    /// This now integrates with the ML Agents system to generate abilities based on agent performance.
    /// </summary>
    public string SimulateLLMCall(float lastScore)
    {
        // This method is kept for backward compatibility
        // Redirect to the new method that takes agent context into account
        return GenerateAbility(-1, -1, lastScore);
    }

    /// <summary>
    /// Get default ability code by type
    /// </summary>
    private string GetDefaultAbilityByType(AbilityType  type, int teamId)
    {
        // Check if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);

        switch (type)
        {
            case AbilityType .Defensive:
                return _defensiveAbilityTemplate != null ? _defensiveAbilityTemplate.text : GenerateDefensiveAbility(teamId);
            case AbilityType .Offensive:
                return _offensiveAbilityTemplate != null ? _offensiveAbilityTemplate.text : GenerateOffensiveAbility(teamId);
            case AbilityType .Utility:
            default:
                return _utilityAbilityTemplate != null ? _utilityAbilityTemplate.text : GenerateUtilityAbility(teamId);
        }
    }

    // New helper to determine which ability type would benefit the agent most
    private AbilityType  DetermineOptimalAbilityType(int agentId, int teamId)
    {
        // This would ideally be based on analyzing agent behavior and needs
        // For now, use a simple heuristic based on health patterns

        // Check if we have health data in strategies
        if (_teamStrategies.ContainsKey(teamId) &&
            _teamStrategies[teamId].strategies.ContainsKey("HealthPattern"))
        {
            var healthPattern = _teamStrategies[teamId].strategies["HealthPattern"];

            // If agent tends to lose health quickly, suggest defensive ability
            if (healthPattern.successRate < 0.4f)
                return AbilityType.Defensive;

            // If agent is good at maintaining health, suggest offensive ability
            if (healthPattern.successRate > 0.7f)
                return AbilityType.Offensive;
        }

        // Default to utility as a balanced option
        return AbilityType.Utility;
    }

    /// <summary>
    /// Generate a new ability prompt
    /// </summary>
    private string GenerateNewAbilityPrompt(float performance, int teamId)
    {
        string abilityType;
        string situationalContext;
        
        // Determine if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);
        string agentType = isAgent1 ? "Agent_1" : (isAgent2 ? "Agent_2" : "Unknown");

        string agentSpecificGuidance = "";
        if (isAgent1)
        {
            agentSpecificGuidance = "For Agent_1: The agent should be rewarded for dashing towards its target and receive a small reward for dashing away from Agent_2. Punish the agent for improper ability use.";
        }
        else if (isAgent2)
        {
            agentSpecificGuidance = "For Agent_2: The agent should be rewarded for dashing towards Agent_1 and punished for misuse of the ability.";
        }

        if (performance < 0.3f)
        {
            abilityType = "defensive";
            situationalContext = "The agent is performing poorly and needs protection or recovery options.";
        }
        else if (performance > 0.7f)
        {
            abilityType = "offensive";
            situationalContext = "The agent is performing well and can take advantage of aggressive options.";
        }
        else
        {
            abilityType = "utility";
            situationalContext = "The agent is performing adequately and could benefit from mobility or strategic options.";
        }

        return $@"Generate a {abilityType} ability for an agent in a Unity game using ML Agents for reinforcement learning.

Context: {situationalContext}
Agent Type: {agentType}
Performance score: {performance:F2}

{agentSpecificGuidance}

The ability should:
1. Be implemented for a discrete action system (use or don't use)
2. Use agent.AddReward() directly instead of effectiveness measurements
3. Be self-contained C# code that can run in Unity
4. Use available agent components (transform, health system, movement system)
5. Include appropriate visual feedback using Debug.Log statements
6. Be consistent and predictable to facilitate ML Agents reinforcement learning

For dashing abilities:
- Detect if dashing towards targets/opponents using Vector3.Distance and Vector3.Dot
- Provide appropriate rewards based on the agent type and dash direction
- Apply proper force/movement using transform.position adjustments

Return only the valid C# code with no additional text.";
    }

    /// <summary>
    /// Queue an API request to be processed
    /// </summary>
    private void QueueAPIRequest(APIRequest request)
    {
        if (!_useActualLLMAPI || string.IsNullOrEmpty(_apiKey))
        {
            Debug.LogWarning("[LLMManager] Cannot queue API request: API usage is disabled or key is missing");
            return;
        }

        // Check daily cost limit
        if (_dailyCost >= _maxDailyCost)
        {
            Debug.LogWarning($"[LLMManager] Daily cost limit reached (${_dailyCost:F2}/${_maxDailyCost:F2}). " +
                            $"API requests are now being throttled until tomorrow.");
            return;
        }

        _pendingAPIRequests.Enqueue(request);
        Debug.Log($"[LLMManager] Queued {request.requestType} request. Queue size: {_pendingAPIRequests.Count}");
    }

    /// <summary>
    /// Process the next API request in the queue
    /// </summary>
    private async void ProcessNextAPIRequest()
    {
        if (_pendingAPIRequests.Count == 0 || _isProcessingQueue)
            return;

        _isProcessingQueue = true;

        APIRequest request = _pendingAPIRequests.Dequeue();
        Debug.Log($"[LLMManager] Processing {request.requestType} request for agent {request.agentId}");

        try
        {
            string response = await MakeAPIRequest(request.prompt);

            // Process the API response based on request type
            switch (request.requestType)
            {
                case APIRequestType.NewAbility:
                    StoreNewAbility(request.abilityType, response);

                    // Record the ability generation in ML Agents stats
                    Academy.Instance.StatsRecorder.Add($"LLM/AbilityGenerated_{request.abilityType}", 1);
                    break;

                case APIRequestType.AbilityReplacement:
                    ReplaceAbility(request.abilityToReplace, request.abilityType, response);

                    // Record the ability replacement in ML Agents stats
                    Academy.Instance.StatsRecorder.Add($"LLM/AbilityReplaced_{request.abilityType}", 1);
                    break;
            }

            // Estimate and track cost
            EstimateAndTrackCost(request.prompt, response);
        }
        catch (Exception ex)
        {
            Debug.LogError($"[LLMManager] API request failed: {ex.Message}");
        }
        finally
        {
            _isProcessingQueue = false;
        }
    }

    /// <summary>
    /// Make an actual API request to the LLM API
    /// </summary>
    private async Task<string> MakeAPIRequest(string prompt)
    {
        using (HttpClient client = new HttpClient())
        {
            // Set up headers
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiKey}");

            // Create the request payload
            var requestData = new
            {
                model = _modelName,
                messages = new[]
                {
                    new { role = "user", content = prompt }
                },
                temperature = _temperature,
                max_tokens = _maxTokens
            };

            string jsonContent = JsonUtility.ToJson(requestData);
            StringContent content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Make the API call
            Debug.Log($"[LLMManager] Sending API request to {_apiEndpoint}");
            HttpResponseMessage response = await client.PostAsync(_apiEndpoint, content);

            if (response.IsSuccessStatusCode)
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                Debug.Log($"[LLMManager] API request successful");

                // Parse the JSON response to extract the completion text
                // Note: This is a simplified example. In a real implementation, you'd need proper JSON parsing
                // This assumes OpenAI API format - adjust for other APIs
                string completionText = ExtractCompletionFromResponse(responseContent);

                return completionText;
            }
            else
            {
                string errorContent = await response.Content.ReadAsStringAsync();
                Debug.LogError($"[LLMManager] API request failed: {response.StatusCode}, {errorContent}");
                throw new Exception($"API request failed: {response.StatusCode}");
            }
        }
    }

    /// <summary>
    /// Generate an insight about agent performance based on ML Agents metrics
    /// </summary>
    public string GenerateAgentInsight(int agentId, int teamId)
    {
        // Generate insights based on agent performance patterns
        string insight = "No significant patterns detected in agent behavior.";

        // Determine if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);
        string agentType = isAgent1 ? "Agent_1" : (isAgent2 ? "Agent_2" : "Unknown");

        // Add agent-specific insights
        if (isAgent1 || isAgent2)
        {
            insight += $" This agent is classified as {agentType}.";
        }

        // Check if we have enough episode data
        if (_episodePerformance.ContainsKey(agentId) && _agentEpisodeCounts.ContainsKey(agentId) && _agentEpisodeCounts[agentId] > 5)
        {
            // Check for performance trends
            if (_episodePerformance[agentId].ContainsKey("AverageReward") &&
                _episodePerformance[agentId].ContainsKey("LastReward"))
            {
                float avgReward = _episodePerformance[agentId]["AverageReward"];
                float lastReward = _episodePerformance[agentId]["LastReward"];

                // Is performance improving?
                if (lastReward > avgReward + 0.2f)
                {
                    insight = $"Agent performance is improving significantly. Recent reward ({lastReward:F2}) " +
                              $"exceeds average ({avgReward:F2}).";
                }
                // Is performance declining?
                else if (lastReward < avgReward - 0.2f)
                {
                    insight = $"Agent performance is declining. Recent reward ({lastReward:F2}) " +
                              $"is below average ({avgReward:F2}).";
                }
            }

            // Check strategy patterns from data
            if (_teamStrategies.ContainsKey(teamId) && _teamStrategies[teamId].strategies.Count > 0)
            {
                // Find most and least successful strategies
                string mostSuccessful = "";
                string leastSuccessful = "";
                float highestSuccess = 0f;
                float lowestSuccess = 1f;

                foreach (var strategy in _teamStrategies[teamId].strategies)
                {
                    if (strategy.Value.useCount >= 5) // Only consider strategies used enough times
                    {
                        if (strategy.Value.successRate > highestSuccess)
                        {
                            highestSuccess = strategy.Value.successRate;
                            mostSuccessful = strategy.Key;
                        }
                        if (strategy.Value.successRate < lowestSuccess)
                        {
                            lowestSuccess = strategy.Value.successRate;
                            leastSuccessful = strategy.Key;
                        }
                    }
                }

                if (!string.IsNullOrEmpty(mostSuccessful) && !string.IsNullOrEmpty(leastSuccessful))
                {
                    insight += $" The '{mostSuccessful}' strategy is most effective ({highestSuccess:P0}), " +
                              $"while '{leastSuccessful}' is least effective ({lowestSuccess:P0}).";
                }
            }

            // Add ability-specific insights
            if (_abilityEffectiveness.ContainsKey(teamId) && _abilityEffectiveness[teamId].Count > 0)
            {
                // Find most effective ability
                string mostEffectiveAbility = "";
                float highestEffectiveness = 0f;

                foreach (var ability in _abilityEffectiveness[teamId])
                {
                    if (ability.Value.useCount >= 5 && ability.Value.effectiveness > highestEffectiveness)
                    {
                        highestEffectiveness = ability.Value.effectiveness;
                        mostEffectiveAbility = ability.Key;
                    }
                }

                if (!string.IsNullOrEmpty(mostEffectiveAbility))
                {
                    insight += $" Ability '{mostEffectiveAbility}' is most effective with {highestEffectiveness:P0} success rate.";
                }
            }
        }
        else
        {
            insight = $"Insufficient data - agent has only completed {(_agentEpisodeCounts.ContainsKey(agentId) ? _agentEpisodeCounts[agentId] : 0)} episodes.";
        }

        return insight;
    }

    /// <summary>
    /// Extract the completion text from the API response
    /// </summary>
    private string ExtractCompletionFromResponse(string responseJson)
    {
        // This is a placeholder implementation
        // In a real implementation, you would use proper JSON parsing

        // Example for OpenAI API format:
        // Parse for "content" field in the response
        int contentStart = responseJson.IndexOf("\"content\":\"") + 12;
        if (contentStart >= 12)
        {
            int contentEnd = responseJson.IndexOf("\"", contentStart);
            if (contentEnd > contentStart)
            {
                string content = responseJson.Substring(contentStart, contentEnd - contentStart);
                // Unescape JSON string
                content = content.Replace("\\n", "\n").Replace("\\\"", "\"").Replace("\\\\", "\\");
                return content;
            }
        }

        Debug.LogError($"[LLMManager] Failed to parse API response: {responseJson}");
        return "// Failed to generate ability code. Using default template.";
    }

    /// <summary>
    /// Store a new ability
    /// </summary>
    private void StoreNewAbility(AbilityType type, string code)
    {
        string templatePath;
        string typeName = type.ToString();

        switch (type)
        {
            case AbilityType.Defensive:
                templatePath = Path.Combine(_templatesFolder, "HealingPulse.txt");
                break;
            case AbilityType.Offensive:
                templatePath = Path.Combine(_templatesFolder, "EnergyBlast.txt");
                break;
            case AbilityType.Utility:
            default:
                templatePath = Path.Combine(_templatesFolder, "Dash.txt");
                break;
        }

        // Save the code to the template file
        try
        {
            File.WriteAllText(templatePath, code);
            Debug.Log($"[LLMManager] Stored new {type} ability to {templatePath}");

            // Update template reference
            switch (type)
            {
                case AbilityType.Defensive:
                    _defensiveAbilityTemplate = new TextAsset(code);
                    break;
                case AbilityType.Offensive:
                    _offensiveAbilityTemplate = new TextAsset(code);
                    break;
                case AbilityType.Utility:
                    _utilityAbilityTemplate = new TextAsset(code);
                    break;
            }

            // Log the ability creation to ML Agents for tracking
            Academy.Instance.StatsRecorder.Add($"LLM/Generated{typeName}Ability", 1);
        }
        catch (Exception ex)
        {
            Debug.LogError($"[LLMManager] Failed to store new ability: {ex.Message}");
        }
    }

    /// <summary>
    /// Replace an existing ability
    /// </summary>
    private void ReplaceAbility(string abilityToReplace, AbilityType type, string code)
    {
        // First store the new ability
        StoreNewAbility(type, code);

        Debug.Log($"[LLMManager] Replaced ability '{abilityToReplace}' with new {type} ability");

        // Record replacement in ML Agents stats
        Academy.Instance.StatsRecorder.Add("LLM/AbilityReplacements", 1);
    }

    /// <summary>
    /// Estimate and track the cost of an API request
    /// </summary>
    private void EstimateAndTrackCost(string prompt, string response)
    {
        // This is a simplified cost estimation based on token count
        // In a real implementation, you would use the actual token count from the API response

        // Rough estimate: 4 characters per token
        int promptTokens = Mathf.CeilToInt(prompt.Length / 4f);
        int responseTokens = Mathf.CeilToInt(response.Length / 4f);

        // Example pricing for GPT-4 (adjust for your specific model)
        // $0.03 per 1K prompt tokens, $0.06 per 1K completion tokens
        float promptCost = promptTokens * 0.03f / 1000f;
        float responseCost = responseTokens * 0.06f / 1000f;
        float totalCost = promptCost + responseCost;

        _dailyCost += totalCost;

        Debug.Log($"[LLMManager] API request cost: ${totalCost:F4} (Prompt: ${promptCost:F4}, Response: ${responseCost:F4})");
        Debug.Log($"[LLMManager] Daily cost so far: ${_dailyCost:F2}/{_maxDailyCost:F2}");

        // Track API usage in ML Agents stats
        Academy.Instance.StatsRecorder.Add("LLM/APIRequestCount", 1);
        Academy.Instance.StatsRecorder.Add("LLM/APICostDaily", _dailyCost);
    }

    /// <summary>
    /// Generates a system prompt for the LLM that includes ML‑Agents context,
    /// the agent’s identifiers, and the updated ability format.
    /// </summary>
    /// <param name="agentId">Unique ID of the agent.</param>
    /// <param name="teamID">Integer ID of the agent’s team.</param>
    public string GenerateSystemPrompt(int agentId, int teamID)
    {
        return $@"You are an AI ability generator for a Unity game using ML Agents for reinforcement learning.
    Your task is to generate C# code for agent abilities based on the provided context and the following identifiers:
    - Agent ID: {agentId}
    - Team ID:  {teamID}

    The code should be self-contained and include clear comments.
    You should only return valid C# code that works within the Unity environment.

    The agent has these components:
    - agent.transform: Transform component for position and rotation
    - agent.GetComponent<AgentHealthSystem>(): Health system with currentHealth and maxHealth properties
    - agent.GetComponent<AgentMovementSystem>(): Movement system with ApplyForce(direction, duration) method
    - agent.teamID: Integer ID of the agent’s team
    - agent.agentId: Unique ID of the agent

    ML‑Agents specifics:
    - The agent is trained using reinforcement learning with discrete actions
    - Use agent.AddReward() directly to provide rewards/penalties
    - Abilities should be consistent and predictable to facilitate learning
    - Do not use NotifyAbilityOutcome()

    There are two agent types:
    - Agent_1: Reward for dashing toward its target and for dashing away from Agent_2
    - Agent_2: Reward for dashing toward Agent_1

    Abilities should:
    1. Be responsive and effective
    2. Visually communicate their effects using Debug.Log
    3. Properly calculate rewards based on behavior and agent type
    4. Work well with the ML‑Agents learning system by providing consistent behavior
    5. Include specific reward calculations based on dash direction and target positions";
    }

    /// <summary>
    /// Generates a defensive ability based on templates or predefined patterns, tailored for specific agent types
    /// </summary>
    private string GenerateDefensiveAbility(int teamId)
    {
        // Check if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);

        // Check if we have a template file
        if (_defensiveAbilityTemplate != null)
        {
            return ProcessTemplateWithVariations(_defensiveAbilityTemplate.text, teamId);
        }

        // Fallback to hardcoded ability with agent-specific reward logic
        string agentSpecificLogic = "";

        if (isAgent1)
        {
            agentSpecificLogic = @"
        // Agent_1 specific reward logic - rewarded for healing more when closer to target
        float distanceToTarget = 0f;
        if (agent.target != null)
        {
            distanceToTarget = Vector3.Distance(agent.transform.position, agent.target.position);
            float proximityBonus = Mathf.Clamp01(1.0f - (distanceToTarget / 10f)) * 0.05f;
            agent.AddReward(proximityBonus);
            Debug.Log($""[Ability] Shield Burst - Agent_1 proximity bonus: {proximityBonus:F3}"");
        }";
        }
        else if (isAgent2)
        {
            agentSpecificLogic = @"
        // Agent_2 specific reward logic - rewarded for healing when near Agent_1
        CustomAgent nearestOpponent = AgentRegistry.Instance.FindClosestOpponent(agent.transform.position, agent.teamID, 10f);
        if (nearestOpponent != null)
        {
            float distanceToOpponent = Vector3.Distance(agent.transform.position, nearestOpponent.transform.position);
            float tacticalBonus = Mathf.Clamp01(1.0f - (distanceToOpponent / 8f)) * 0.05f;
            agent.AddReward(tacticalBonus);
            Debug.Log($""[Ability] Shield Burst - Agent_2 tactical bonus: {tacticalBonus:F3}"");
        }";
        }

        // Generic defensive ability with agent-specific logic
        return @"
    // Ability: Shield Burst
    // Create a temporary shield that blocks incoming damage and boosts health
    AgentHealthSystem health = agent.GetComponent<AgentHealthSystem>();
    if (health != null) {
        // Calculate health before the boost
        float healthBefore = health.currentHealth;

        // Apply health boost
        float healthBoost = 15f;
        health.currentHealth = Mathf.Min(health.maxHealth, health.currentHealth + healthBoost);

        // Calculate actual health gained
        float actualHealthGained = health.currentHealth - healthBefore;

        // Base reward - proportional to how much health was actually gained
        float baseReward = actualHealthGained / healthBoost * 0.1f;
        agent.AddReward(baseReward);

        Debug.Log($""[Ability] Shield Burst activated! +{actualHealthGained:F1} health. Reward: {baseReward:F3}"");
    " + agentSpecificLogic + @"

        // Visual effect (in a real implementation, you would instantiate a particle effect)
        // GameObject shieldEffect = Instantiate(shieldPrefab, agent.transform.position, Quaternion.identity);
        // shieldEffect.transform.parent = agent.transform;
        // Destroy(shieldEffect, 2.0f);

        // Additional reward or penalty based on tactical situation
        if (health.currentHealth < health.maxHealth * 0.5f) {
            // Extra reward for using when health is low (good timing)
            float timingBonus = 0.05f;
            agent.AddReward(timingBonus);
            Debug.Log($""[Ability] Shield Burst good timing bonus: {timingBonus:F3}"");
        }
        else if (health.currentHealth == health.maxHealth) {
            // Small penalty for using at full health (wasteful)
            float wastePenalty = -0.02f;
            agent.AddReward(wastePenalty);
            Debug.Log($""[Ability] Shield Burst wasted at full health: {wastePenalty:F3}"");
        }
    } else {
        Debug.LogWarning(""[Ability] Shield Burst failed - no health system found."");
        agent.AddReward(-0.01f); // Small penalty for failure
    }";
    }

    /// <summary>
    /// Generates an offensive ability based on templates or predefined patterns, tailored for specific agent types
    /// </summary>
    private string GenerateOffensiveAbility(int teamId)
    {
        // Check if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);

        // Check if we have a template file
        if (_offensiveAbilityTemplate != null)
        {
            return ProcessTemplateWithVariations(_offensiveAbilityTemplate.text, teamId);
        }

        // Fallback to hardcoded ability with agent-specific reward logic
        string agentSpecificLogic = "";

        if (isAgent1)
        {
            agentSpecificLogic = @"
            // Agent_1 specific reward logic - extra reward for hitting opponents that are closer to target
            if (affectedOpponents > 0 && agent.target != null) {
                float targetProximityBonus = 0f;

                foreach (var hitAgent in hitAgents) {
                    if (hitAgent != null && hitAgent.teamID != agent.teamID) {
                        float distanceToTarget = Vector3.Distance(hitAgent.transform.position, agent.target.position);
                        targetProximityBonus += Mathf.Clamp01(1.0f - (distanceToTarget / 10f)) * 0.02f;
                    }
                }

                if (targetProximityBonus > 0) {
                    agent.AddReward(targetProximityBonus);
                    Debug.Log($""[Ability] Energy Blast - Agent_1 strategic positioning bonus: {targetProximityBonus:F3}"");
                }
            }";
        }
        else if (isAgent2)
        {
            agentSpecificLogic = @"
            // Agent_2 specific reward logic - rewarded for hitting Agent_1
            float targetHitBonus = 0f;

            foreach (var hitAgent in hitAgents) {
                if (hitAgent != null && _agent1TeamIDs.Contains(hitAgent.teamID)) {
                    targetHitBonus += 0.05f;
                }
            }

            if (targetHitBonus > 0) {
                agent.AddReward(targetHitBonus);
                Debug.Log($""[Ability] Energy Blast - Agent_2 primary target bonus: {targetHitBonus:F3}"");
            }";
        }

        // Generic offensive ability with agent-specific logic
        string abilityCode = $@"
        // Ability: Energy Blast
        // Send out an energy wave that pushes away nearby opponents

        List<CustomAgent> hitAgents = new List<CustomAgent>();
        int affectedAgents = 0;
        int affectedOpponents = 0;

        // Define blast parameters
        float blastRadius = 8f;
        float blastForce = 15f;
        float minDamage = 5f;

        // Base reward calculation
        float baseReward = 0f;

        // Find all agents in blast radius
        Collider[] hitColliders = Physics.OverlapSphere(agent.transform.position, blastRadius);
        foreach (var hitCollider in hitColliders) {{
            CustomAgent targetAgent = hitCollider.GetComponent<CustomAgent>();
            if (targetAgent != null && targetAgent != agent) {{
                // Calculate direction and distance
                Vector3 direction = (targetAgent.transform.position - agent.transform.position).normalized;
                float distance = Vector3.Distance(agent.transform.position, targetAgent.transform.position);

                // Calculate force based on distance (stronger closer to the blast)
                float forceMagnitude = blastForce * (1 - distance / blastRadius);

                // Apply force to the target using their movement system
                AgentMovementSystem targetMovement = targetAgent.GetComponent<AgentMovementSystem>();
                if (targetMovement != null) {{
                    // Apply knockback effect
                    targetMovement.ApplyForce(direction * forceMagnitude, 0.5f);
                }}

                // Keep track of affected agents
                affectedAgents++;
                hitAgents.Add(targetAgent);

                // Apply damage if it's an opponent
                if (targetAgent.teamID != agent.teamID) {{
                    // Calculate damage based on distance (more damage closer to the blast)
                    float damage = minDamage * (1 - distance / blastRadius);

                    // Create damage event
                    AgentEventSystem.AgentEvent attackEvent = new AgentEventSystem.AgentEvent(agent.agentId, targetAgent.transform.position, 0.5f, ""Attack"");
                    attackEvent.data[""damage""] = damage;
                    attackEvent.data[""bypassBlock""] = true;
                    AgentEventSystem.Instance.BroadcastEvent(attackEvent);

                    affectedOpponents++;
                }}
            }}
        }}

        if (affectedOpponents > 0) {{
            // More reward for affecting more opponents
            baseReward = Mathf.Min(affectedOpponents * 0.04f, 0.2f);
            agent.AddReward(baseReward);
            Debug.Log($""[Ability] Energy Blast affected {{affectedOpponents}} opponents! Base reward: {{baseReward:F3}}"");
        }} else if (affectedAgents > 0) {{
            // Small penalty for only affecting allies
            baseReward = -0.02f;
            agent.AddReward(baseReward);
            Debug.Log($""[Ability] Energy Blast only affected allies. Penalty: {{baseReward:F3}}"");
        }} else {{
            // Larger penalty for not affecting anyone
            baseReward = -0.05f;
            agent.AddReward(baseReward);
            Debug.Log($""[Ability] Energy Blast missed everyone! Penalty: {{baseReward:F3}}"");
        }}

        {agentSpecificLogic}
        ";
        return abilityCode;
    }


    private string ProcessTemplateWithVariations(string template, int teamId)
    {
        if (!_useRandomAbilityVariations)
            return template;

        // Check if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);

        // Replace placeholder values with random variations
        string processed = template;

        // Replace numerical placeholders with reasonable variations
        // Use UnityEngine.Random explicitly to resolve ambiguity
        processed = processed.Replace("DASH_DISTANCE", UnityEngine.Random.Range(6f, 10f).ToString("F1"));
        processed = processed.Replace("HEALTH_BOOST", UnityEngine.Random.Range(10f, 25f).ToString("F1"));
        processed = processed.Replace("ATTACK_RANGE", UnityEngine.Random.Range(8f, 12f).ToString("F1"));
        processed = processed.Replace("ATTACK_ANGLE", UnityEngine.Random.Range(30f, 90f).ToString("F1"));
        processed = processed.Replace("ATTACK_DAMAGE", UnityEngine.Random.Range(15f, 25f).ToString("F1"));

        // Replace agent-specific placeholders
        if (isAgent1)
        {
            processed = processed.Replace("AGENT_TYPE", "Agent_1");
            processed = processed.Replace("TARGET_REWARD", UnityEngine.Random.Range(0.08f, 0.12f).ToString("F2"));
            processed = processed.Replace("AVOID_REWARD", UnityEngine.Random.Range(0.03f, 0.07f).ToString("F2"));
            processed = processed.Replace("WRONG_DIRECTION_PENALTY", UnityEngine.Random.Range(-0.05f, -0.02f).ToString("F2"));
        }
        else if (isAgent2)
        {
            processed = processed.Replace("AGENT_TYPE", "Agent_2");
            processed = processed.Replace("PURSUIT_REWARD", UnityEngine.Random.Range(0.12f, 0.18f).ToString("F2"));
            processed = processed.Replace("RETREAT_PENALTY", UnityEngine.Random.Range(-0.08f, -0.04f).ToString("F2"));
            processed = processed.Replace("EXPLORATION_REWARD", UnityEngine.Random.Range(0.01f, 0.03f).ToString("F2"));
        }
        else
        {
            processed = processed.Replace("AGENT_TYPE", "Generic");
            processed = processed.Replace("BASE_REWARD", UnityEngine.Random.Range(0.04f, 0.08f).ToString("F2"));
        }

        return processed;
    }

    /// <summary>
    /// Generates a utility ability based on templates or predefined patterns, tailored for specific agent types
    /// </summary>
    private string GenerateUtilityAbility(int teamId)
    {
        // Check if this is Agent_1 or Agent_2 based on team ID
        bool isAgent1 = _agent1TeamIDs.Contains(teamId);
        bool isAgent2 = _agent2TeamIDs.Contains(teamId);

        // Check if we have a template file
        if (_utilityAbilityTemplate != null)
        {
            return ProcessTemplateWithVariations(_utilityAbilityTemplate.text, teamId);
        }

        // Specific reward logic for each agent type
        string agentSpecificLogic = "";

        if (isAgent1)
        {
            agentSpecificLogic = @"
            // Agent_1 specific rewards
            // Calculate if we're dashing toward the target
            bool dashingTowardTarget = false;
            float targetReward = 0f;

            if (agent.target != null)
            {
                Vector3 dirToTarget = (agent.target.position - originalPosition).normalized;
                float dotToTarget = Vector3.Dot(forward, dirToTarget);
                float distanceToTarget = Vector3.Distance(originalPosition, agent.target.position);
                float newDistanceToTarget = Vector3.Distance(agent.transform.position, agent.target.position);

                // Check if we're moving toward target (positive dot product and distance decreased)
                if (dotToTarget > 0.5f && newDistanceToTarget < distanceToTarget)
                {
                    dashingTowardTarget = true;
                    float distanceReduction = distanceToTarget - newDistanceToTarget;
                    targetReward = 0.1f * (distanceReduction / dashDistance);
                    agent.AddReward(targetReward);
                    Debug.Log($""[Ability] Dash moved toward target by {distanceReduction:F2} units. Reward: {targetReward:F3}"");
                }
            }

            // Check if we're dashing away from an opponent (Agent_2)
            CustomAgent nearestOpponent = AgentRegistry.Instance.FindClosestOpponent(agent.transform.position, agent.teamID, 15f);
            if (nearestOpponent != null)
            {
                Vector3 dirToOpponent = (nearestOpponent.transform.position - originalPosition).normalized;
                float dotToOpponent = Vector3.Dot(forward, dirToOpponent);
                float originalDistToOpponent = Vector3.Distance(originalPosition, nearestOpponent.transform.position);
                float newDistToOpponent = Vector3.Distance(agent.transform.position, nearestOpponent.transform.position);

                // If we're dashing away from opponent (negative dot product or increased distance)
                if (dotToOpponent < -0.3f || newDistToOpponent > originalDistToOpponent)
                {
                    float distanceGain = newDistToOpponent - originalDistToOpponent;
                    float escapeReward = 0.05f * Mathf.Clamp01(distanceGain / dashDistance);
                    agent.AddReward(escapeReward);
                    Debug.Log($""[Ability] Dash avoided opponent by {distanceGain:F2} units. Reward: {escapeReward:F3}"");
                }
                // If we're not moving toward target and instead moving toward opponent, small penalty
                else if (!dashingTowardTarget && dotToOpponent > 0.5f)
                {
                    float penalty = -0.03f;
                    agent.AddReward(penalty);
                    Debug.Log($""[Ability] Dash moved toward opponent instead of target. Penalty: {penalty:F3}"");
                }
            }";
        }
        else if (isAgent2)
        {
            agentSpecificLogic = @"
            // Agent_2 specific rewards
            // Check if we're dashing toward Agent_1
            CustomAgent opponent = null;
            foreach (var foundAgent in AgentRegistry.Instance.GetNearbyAgents(agent.transform.position, 20f))
            {
                if (_agent1TeamIDs.Contains(foundAgent.teamID))
                {
                    opponent = foundAgent;
                    break;
                }
            }

            if (opponent != null)
            {
                Vector3 dirToOpponent = (opponent.transform.position - originalPosition).normalized;
                float dotToOpponent = Vector3.Dot(forward, dirToOpponent);
                float originalDistToOpponent = Vector3.Distance(originalPosition, opponent.transform.position);
                float newDistToOpponent = Vector3.Distance(agent.transform.position, opponent.transform.position);

                // If we're dashing toward Agent_1 (positive dot product and decreased distance)
                if (dotToOpponent > 0.5f && newDistToOpponent < originalDistToOpponent)
                {
                    float distanceReduction = originalDistToOpponent - newDistToOpponent;
                    float pursuitReward = 0.15f * (distanceReduction / dashDistance);
                    agent.AddReward(pursuitReward);
                    Debug.Log($""[Ability] Dash closed distance to Agent_1 by {distanceReduction:F2} units. Reward: {pursuitReward:F3}"");
                }
                // If we're dashing away from Agent_1, add penalty
                else if (dotToOpponent < -0.3f || newDistToOpponent > originalDistToOpponent)
                {
                    float distanceGain = newDistToOpponent - originalDistToOpponent;
                    float retreatPenalty = -0.05f * Mathf.Clamp01(distanceGain / dashDistance);
                    agent.AddReward(retreatPenalty);
                    Debug.Log($""[Ability] Dash retreated from Agent_1 by {distanceGain:F2} units. Penalty: {retreatPenalty:F3}"");
                }
            }
            else
            {
                // No Agent_1 found, explore mode - reward for longer, unobstructed dashes
                float explorationReward = 0.02f * (distanceTraveled / dashDistance);
                agent.AddReward(explorationReward);
                Debug.Log($""[Ability] Dash exploration mode. Reward: {explorationReward:F3}"");
            }";
        }

        // Generic dash ability with agent-specific reward logic
        return @"
        // Ability: Tactical Dash
        // Quickly dash forward to reposition
        Vector3 forward = agent.transform.forward;

        // Calculate dash parameters
        float dashDistance = 7.5f;
        float dashSpeed = 30f; // Higher value = faster dash

        // Store original position for success calculation
        Vector3 originalPosition = agent.transform.position;

        // Calculate the target position
        Vector3 targetPosition = originalPosition + forward * dashDistance;

        // Check for collisions in the dash path
        RaycastHit hit;
        bool hitObstacle = Physics.Raycast(originalPosition, forward, out hit, dashDistance);
        if (hitObstacle) {
            // Adjust target position to stop just before the obstacle
            targetPosition = hit.point - (forward * 0.5f);
            Debug.Log($""[Ability] Dash adjusted to avoid collision with {hit.collider.gameObject.name}"");
        }

        // Apply the dash - instantly change position
        agent.transform.position = targetPosition;

        // Calculate actual distance traveled
        float distanceTraveled = Vector3.Distance(originalPosition, agent.transform.position);

        // Base reward calculation - more reward for longer dashes that don't hit obstacles
        float baseReward = 0.05f * (distanceTraveled / dashDistance);
        if (hitObstacle) {
            // Reduced reward for hitting obstacle
            baseReward *= 0.5f;
        }
        agent.AddReward(baseReward);

        // Report the outcome
        Debug.Log($""[Ability] Dash completed! Traveled {distanceTraveled:F1} units. Base reward: {baseReward:F3}"");

        " + agentSpecificLogic;
    }


    public void CleanupOldData()
    {
        // Remove data for agents that haven't been updated recently
        float currentTime = Time.time;
        float cutoffTime = currentTime - 300f; // 5 minutes

        List<int> agentsToRemove = new List<int>();

        foreach (var entry in _agentObservations)
        {
            if (entry.Value.Count > 0 && entry.Value[entry.Value.Count - 1].timestamp < cutoffTime)
            {
                agentsToRemove.Add(entry.Key);
            }
        }

        foreach (int agentId in agentsToRemove)
        {
            _agentObservations.Remove(agentId);
            _agentRewards.Remove(agentId);
        }

        // Limit number of agents tracked
        if (_agentObservations.Count > _maxAgentsTracked)
        {
            // Find the oldest updated agent
            int oldestAgentId = -1;
            float oldestTime = float.MaxValue;

            foreach (var entry in _agentObservations)
            {
                if (entry.Value.Count > 0)
                {
                    float lastTime = entry.Value[entry.Value.Count - 1].timestamp;
                    if (lastTime < oldestTime)
                    {
                        oldestTime = lastTime;
                        oldestAgentId = entry.Key;
                    }
                }
            }

            if (oldestAgentId != -1)
            {
                _agentObservations.Remove(oldestAgentId);
                _agentRewards.Remove(oldestAgentId);
            }
        }
    }

    public void LoadAPIKey()
    {
        // Try to load from PlayerPrefs first
        if (PlayerPrefs.HasKey("LLM_API_KEY"))
        {
            _apiKey = PlayerPrefs.GetString("LLM_API_KEY");
            Debug.Log("[LLMManager] Loaded API key from PlayerPrefs");
        }
        // Then try environment variables
        else
        {
            string envKey = Environment.GetEnvironmentVariable("LLM_API_KEY");
            if (!string.IsNullOrEmpty(envKey))
            {
                _apiKey = envKey;
                Debug.Log("[LLMManager] Loaded API key from environment variable");
            }
        }

        // If API key is found but useActualLLMAPI is false, log a warning
        if (!string.IsNullOrEmpty(_apiKey) && !_useActualLLMAPI)
        {
            Debug.LogWarning("[LLMManager] API key is set but useActualLLMAPI is false. " +
                             "Set useActualLLMAPI to true to use the API.");
        }

        // If useActualLLMAPI is true but API key is empty, log an error
        if (_useActualLLMAPI && string.IsNullOrEmpty(_apiKey))
        {
            Debug.LogError("[LLMManager] useActualLLMAPI is true but no API key found. " +
                          "Please set the API key in the inspector or in PlayerPrefs.");
        }
    }

    /// <summary>
    /// Save the API key to PlayerPrefs
    /// </summary>
    public void SaveAPIKey(string apiKey)
    {
        _apiKey = apiKey;
        PlayerPrefs.SetString("LLM_API_KEY", apiKey);
        PlayerPrefs.Save();
        Debug.Log("[LLMManager] Saved API key to PlayerPrefs");
    }

    /// <summary>
    /// Set whether to use the actual LLM API or fallback to default abilities
    /// </summary>
    public void SetUseActualLLMAPI(bool useAPI)
    {
        _useActualLLMAPI = useAPI;
        Debug.Log($"[LLMManager] Using actual LLM API: {useAPI}");
    }

    public void GenerateTemplatesIfNeeded()
    {
        // Check if templates exist, create them if they don't
        if (_defensiveAbilityTemplate == null)
        {
            CreateDefensiveTemplate();
        }

        if (_offensiveAbilityTemplate == null)
        {
            CreateOffensiveTemplate();
        }

        if (_utilityAbilityTemplate == null)
        {
            CreateUtilityTemplate();
        }
    }


    private void CreateUtilityTemplate()
    {
        string templatePath = Path.Combine(_templatesFolder, "Dash.txt");

        // Only create if it doesn't exist
        if (!File.Exists(templatePath))
        {
            string content = @"// Ability: Tactical Dash
    // Quickly dash forward to reposition
    Vector3 forward = agent.transform.forward;

    // Calculate dash parameters
    float dashDistance = 7.5f;
    float dashSpeed = 30f; // Higher value = faster dash

    // Store original position for success calculation
    Vector3 originalPosition = agent.transform.position;

    // Calculate the target position
    Vector3 targetPosition = originalPosition + forward * dashDistance;

    // Check for collisions in the dash path
    RaycastHit hit;
    bool hitObstacle = Physics.Raycast(originalPosition, forward, out hit, dashDistance);
    if (hitObstacle) {
        // Adjust target position to stop just before the obstacle
        targetPosition = hit.point - (forward * 0.5f);
        Debug.Log($""[Ability] Dash adjusted to avoid collision with {hit.collider.gameObject.name}"");
    }

    // Apply the dash - instantly change position
    agent.transform.position = targetPosition;

    // Calculate actual distance traveled
    float distanceTraveled = Vector3.Distance(originalPosition, agent.transform.position);

    // Base reward calculation - more reward for longer dashes that don't hit obstacles
    float baseReward = 0.05f * (distanceTraveled / dashDistance);
    if (hitObstacle) {
        // Reduced reward for hitting obstacle
        baseReward *= 0.5f;
    }
    agent.AddReward(baseReward);

    // Report the outcome
    Debug.Log($""[Ability] Dash completed! Traveled {distanceTraveled:F1} units. Base reward: {baseReward:F3}"");

    // Agent-specific reward logic
    if (agent.teamID == 1) {  // Agent_1
        // Calculate if we're dashing toward the target
        bool dashingTowardTarget = false;
        float targetReward = 0f;

        if (agent.target != null)
        {
            Vector3 dirToTarget = (agent.target.position - originalPosition).normalized;
            float dotToTarget = Vector3.Dot(forward, dirToTarget);
            float distanceToTarget = Vector3.Distance(originalPosition, agent.target.position);
            float newDistanceToTarget = Vector3.Distance(agent.transform.position, agent.target.position);

            // Check if we're moving toward target (positive dot product and distance decreased)
            if (dotToTarget > 0.5f && newDistanceToTarget < distanceToTarget)
            {
                dashingTowardTarget = true;
                float distanceReduction = distanceToTarget - newDistanceToTarget;
                targetReward = TARGET_REWARD * (distanceReduction / dashDistance);
                agent.AddReward(targetReward);
                Debug.Log($""[Ability] Dash moved toward target by {distanceReduction:F2} units. Reward: {targetReward:F3}"");
            }
        }

        // Check if we're dashing away from an opponent (Agent_2)
        CustomAgent nearestOpponent = AgentRegistry.Instance.FindClosestOpponent(agent.transform.position, agent.teamID, 15f);
        if (nearestOpponent != null)
        {
            Vector3 dirToOpponent = (nearestOpponent.transform.position - originalPosition).normalized;
            float dotToOpponent = Vector3.Dot(forward, dirToOpponent);
            float originalDistToOpponent = Vector3.Distance(originalPosition, nearestOpponent.transform.position);
            float newDistToOpponent = Vector3.Distance(agent.transform.position, nearestOpponent.transform.position);

            // If we're dashing away from opponent (negative dot product or increased distance)
            if (dotToOpponent < -0.3f || newDistToOpponent > originalDistToOpponent)
            {
                float distanceGain = newDistToOpponent - originalDistToOpponent;
                float escapeReward = AVOID_REWARD * Mathf.Clamp01(distanceGain / dashDistance);
                agent.AddReward(escapeReward);
                Debug.Log($""[Ability] Dash avoided opponent by {distanceGain:F2} units. Reward: {escapeReward:F3}"");
            }
            // If we're not moving toward target and instead moving toward opponent, small penalty
            else if (!dashingTowardTarget && dotToOpponent > 0.5f)
            {
                float penalty = WRONG_DIRECTION_PENALTY;
                agent.AddReward(penalty);
                Debug.Log($""[Ability] Dash moved toward opponent instead of target. Penalty: {penalty:F3}"");
            }
        }
    }
    else if (agent.teamID == 2) {  // Agent_2
        // Check if we're dashing toward Agent_1
        CustomAgent opponent = null;
        foreach (var foundAgent in AgentRegistry.Instance.GetNearbyAgents(agent.transform.position, 20f))
        {
            if (foundAgent.teamID == 1)  // Team 1 is Agent_1
            {
                opponent = foundAgent;
                break;
            }
        }

        if (opponent != null)
        {
            Vector3 dirToOpponent = (opponent.transform.position - originalPosition).normalized;
            float dotToOpponent = Vector3.Dot(forward, dirToOpponent);
            float originalDistToOpponent = Vector3.Distance(originalPosition, opponent.transform.position);
            float newDistToOpponent = Vector3.Distance(agent.transform.position, opponent.transform.position);

            // If we're dashing toward Agent_1 (positive dot product and decreased distance)
            if (dotToOpponent > 0.5f && newDistToOpponent < originalDistToOpponent)
            {
                float distanceReduction = originalDistToOpponent - newDistToOpponent;
                float pursuitReward = PURSUIT_REWARD * (distanceReduction / dashDistance);
                agent.AddReward(pursuitReward);
                Debug.Log($""[Ability] Dash closed distance to Agent_1 by {distanceReduction:F2} units. Reward: {pursuitReward:F3}"");
            }
            // If we're dashing away from Agent_1, add penalty
            else if (dotToOpponent < -0.3f || newDistToOpponent > originalDistToOpponent)
            {
                float distanceGain = newDistToOpponent - originalDistToOpponent;
                float retreatPenalty = RETREAT_PENALTY * Mathf.Clamp01(distanceGain / dashDistance);
                agent.AddReward(retreatPenalty);
                Debug.Log($""[Ability] Dash retreated from Agent_1 by {distanceGain:F2} units. Penalty: {retreatPenalty:F3}"");
            }
        }
        else
        {
            // No Agent_1 found, explore mode - reward for longer, unobstructed dashes
            float explorationReward = EXPLORATION_REWARD * (distanceTraveled / dashDistance);
            agent.AddReward(explorationReward);
            Debug.Log($""[Ability] Dash exploration mode. Reward: {explorationReward:F3}"");
        }
    }
    else {  // Generic agent that isn't Agent_1 or Agent_2
        // Basic distance-based reward
        float genericReward = BASE_REWARD * (distanceTraveled / dashDistance);
        agent.AddReward(genericReward);
        Debug.Log($""[Ability] Dash generic distance reward: {genericReward:F3}"");
    }";

            File.WriteAllText(templatePath, content);
            Debug.Log($"Created utility ability template at {templatePath}");

            // Load the newly created template
            _utilityAbilityTemplate = new TextAsset(content);
        }
    }

    public void CreateDefensiveTemplate()
    {
        string templatePath = Path.Combine(_templatesFolder, "HealingPulse.txt");

        // Only create if it doesn't exist
        if (!File.Exists(templatePath))
        {
            string content = @"// Ability: Healing Pulse
        // Restores health to the agent and nearby allies
        AgentHealthSystem health = agent.GetComponent<AgentHealthSystem>();
        if (health != null) {
            // Define healing parameters
            float healAmount = 20f;
            float healRadius = 5f;

            // Track state before healing
            float selfHealthBefore = health.currentHealth;

            // Heal self first
            health.currentHealth = Mathf.Min(health.maxHealth, health.currentHealth + healAmount);
            float selfHealingApplied = health.currentHealth - selfHealthBefore;

            // Calculate base reward based on healing amount
            float baseReward = 0.05f * (selfHealingApplied / healAmount);
            agent.AddReward(baseReward);

            // Heal nearby allies
            int alliesHealed = 0;
            float totalHealingApplied = selfHealingApplied;

            Collider[] hitColliders = Physics.OverlapSphere(agent.transform.position, healRadius);
            foreach (var hitCollider in hitColliders) {
                CustomAgent targetAgent = hitCollider.GetComponent<CustomAgent>();
                if (targetAgent != null && targetAgent != agent && targetAgent.teamID == agent.teamID) {
                    // Apply healing to ally
                    AgentHealthSystem allyHealth = targetAgent.GetComponent<AgentHealthSystem>();
                    if (allyHealth != null) {
                        float allyHealthBefore = allyHealth.currentHealth;
                        allyHealth.currentHealth = Mathf.Min(allyHealth.maxHealth, allyHealth.currentHealth + healAmount * 0.5f);
                        float allyHealingApplied = allyHealth.currentHealth - allyHealthBefore;

                        totalHealingApplied += allyHealingApplied;
                        alliesHealed++;

                        // Create a healing event
                        AgentEventSystem.AgentEvent healEvent = new AgentEventSystem.AgentEvent(
                            agent.agentId, targetAgent.transform.position, 0.5f, ""Heal"");
                        healEvent.data[""amount""] = allyHealingApplied;
                        AgentEventSystem.Instance.BroadcastEvent(healEvent);
                    }
                }
            }

            // Additional reward for healing allies
            float allyBonus = 0.02f * alliesHealed;
            agent.AddReward(allyBonus);

            Debug.Log($""[Ability] Healing Pulse healed self for {selfHealingApplied:F1} and {alliesHealed} allies for a total of {totalHealingApplied:F1} health. Rewards: {baseReward:F3} + {allyBonus:F3}"");

            // AGENT_TYPE specific logic
            if (health.currentHealth < health.maxHealth * 0.5f) {
                // Extra reward for using when health is low (good timing)
                float timingBonus = 0.05f;
                agent.AddReward(timingBonus);
                Debug.Log($""[Ability] Healing Pulse good timing bonus: {timingBonus:F3}"");
            }
            else if (health.currentHealth == health.maxHealth && selfHealthBefore > health.maxHealth * 0.9f) {
                // Small penalty for using at near-full health (wasteful)
                float wastePenalty = -0.02f;
                agent.AddReward(wastePenalty);
                Debug.Log($""[Ability] Healing Pulse used wastefully at high health: {wastePenalty:F3}"");
            }
        } else {
            Debug.LogWarning(""[Ability] Healing Pulse failed - no health system found"");
            agent.AddReward(-0.01f); // Small penalty for failure
        }";

                    File.WriteAllText(templatePath, content);
                    Debug.Log($"Created defensive ability template at {templatePath}");

                    // Load the newly created template
                    _defensiveAbilityTemplate = new TextAsset(content);
                }
            }

            public void CreateOffensiveTemplate()
            {
                string templatePath = Path.Combine(_templatesFolder, "EnergyBlast.txt");

                // Only create if it doesn't exist
                if (!File.Exists(templatePath))
                {
                    string content = @"// Ability: Energy Blast
        // Create a shockwave that pushes away nearby opponents
        List<CustomAgent> hitAgents = new List<CustomAgent>();
        int affectedAgents = 0;
        int affectedOpponents = 0;

        // Define blast parameters
        float blastRadius = 8f;
        float blastForce = 15f;
        float minDamage = 5f;

        // Apply blast force to nearby agents
        Collider[] hitColliders = Physics.OverlapSphere(agent.transform.position, blastRadius);

        foreach (var hitCollider in hitColliders) {
            CustomAgent targetAgent = hitCollider.GetComponent<CustomAgent>();
            if (targetAgent != null && targetAgent != agent) {
                // Calculate direction and distance
                Vector3 direction = (targetAgent.transform.position - agent.transform.position).normalized;
                float distance = Vector3.Distance(agent.transform.position, targetAgent.transform.position);

                // Calculate force based on distance (stronger closer to the blast)
                float forceMagnitude = blastForce * (1 - distance/blastRadius);

                // Apply force to the target using their movement system
                AgentMovementSystem targetMovement = targetAgent.GetComponent<AgentMovementSystem>();
                if (targetMovement != null) {
                    // Apply knockback effect
                    targetMovement.ApplyForce(direction * forceMagnitude, 0.5f);
                }

                // Track all affected agents
                affectedAgents++;
                hitAgents.Add(targetAgent);

                // Apply damage if it's an opponent
                if (targetAgent.teamID != agent.teamID) {
                    // Calculate damage based on distance (more damage closer to the blast)
                    float damage = minDamage * (1 - distance/blastRadius);

                    // Create damage event
                    AgentEventSystem.AgentEvent attackEvent = new AgentEventSystem.AgentEvent(
                        agent.agentId, targetAgent.transform.position, 0.5f, ""Attack"");
                    attackEvent.data[""damage""] = damage;
                    attackEvent.data[""bypassBlock""] = true;
                    AgentEventSystem.Instance.BroadcastEvent(attackEvent);

                    affectedOpponents++;
                }
            }
        }

        // Base reward calculation
        float baseReward = 0f;
        if (affectedOpponents > 0) {
            // More reward for affecting more opponents
            baseReward = Mathf.Min(affectedOpponents * 0.04f, 0.2f);
            agent.AddReward(baseReward);
            Debug.Log($""[Ability] Energy Blast affected {affectedOpponents} opponents! Base reward: {baseReward:F3}"");
        } else if (affectedAgents > 0) {
            // Small penalty for only affecting allies
            baseReward = -0.02f;
            agent.AddReward(baseReward);
            Debug.Log($""[Ability] Energy Blast only affected allies. Penalty: {baseReward:F3}"");
        } else {
            // Larger penalty for not affecting anyone
            baseReward = -0.05f;
            agent.AddReward(baseReward);
            Debug.Log($""[Ability] Energy Blast missed everyone! Penalty: {baseReward:F3}"");
        }

        // Agent_1 specific reward calculation
        if (agent.teamID == 1 && affectedOpponents > 0 && agent.target != null) {
            float targetProximityBonus = 0f;

            foreach (var hitAgent in hitAgents) {
                if (hitAgent != null && hitAgent.teamID != agent.teamID) {
                    float distanceToTarget = Vector3.Distance(hitAgent.transform.position, agent.target.position);
                    targetProximityBonus += Mathf.Clamp01(1.0f - (distanceToTarget / 10f)) * 0.02f;
                }
            }

            if (targetProximityBonus > 0) {
                agent.AddReward(targetProximityBonus);
                Debug.Log($""[Ability] Energy Blast - Agent_1 strategic positioning bonus: {targetProximityBonus:F3}"");
            }
        }
        // Agent_2 specific reward calculation
        else if (agent.teamID == 2 && affectedOpponents > 0) {
            float targetHitBonus = 0f;

            foreach (var hitAgent in hitAgents) {
                if (hitAgent != null && hitAgent.teamID == 1) {  // Team 1 is Agent_1
                    targetHitBonus += 0.05f;
                }
            }

            if (targetHitBonus > 0) {
                agent.AddReward(targetHitBonus);
                Debug.Log($""[Ability] Energy Blast - Agent_2 primary target bonus: {targetHitBonus:F3}"");
            }
        }

        // Visual effect (in a real implementation, you would instantiate a particle system)
        Debug.Log($""[Ability] Energy Blast affected a total of {affectedAgents} agents!"");";

                    File.WriteAllText(templatePath, content);
                    Debug.Log($"Created offensive ability template at {templatePath}");

                    // Load the newly created template
                    _offensiveAbilityTemplate = new TextAsset(content);
                }
            }


            // Fix for InitializeLogFile method
            private void InitializeLogFile()
            {
                if (_logObservationsToFile)
                {
                    string directory = Path.GetDirectoryName(_logFilePath);
                    if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }

                    // Create or clear the log file
                    using (StreamWriter writer = new StreamWriter(_logFilePath, false))
                    {
                        writer.WriteLine("# Agent Observations Log");
                        writer.WriteLine("# Format: Timestamp | AgentID | TeamID | ObservationType | Data");
                        writer.WriteLine("# --------------------------------------------------------");
                    }
                }
            }

            // Fix for LogObservationToFile method
            private void LogObservationToFile(AgentObservationData observation)
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(_logFilePath, true))
                    {
                        string dataSummary = _detailedLogging ?
                            SummarizeObservationData(observation.observationData) :
                            $"[{observation.observationData.Length} values]";

                        writer.WriteLine($"{observation.timestamp:F2} | " +
                                        $"Agent-{observation.agentId} | " +
                                        $"Team-{observation.teamId} | " +
                                        $"Observation-{observation.observationContext} | " +
                                        $"{dataSummary}");
                    }
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to write observation to log: {e.Message}");
                }
            }

            // Fix for LogRewardToFile method
            private void LogRewardToFile(AgentRewardData reward)
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(_logFilePath, true))
                    {
                        writer.WriteLine($"{reward.timestamp:F2} | " +
                                        $"Agent-{reward.agentId} | " +
                                        $"Team-{reward.teamId} | " +
                                        $"Reward | " +
                                        $"Value: {reward.reward:F2}, Reason: {reward.reason}, " +
                                        $"Position: ({reward.position.x:F1},{reward.position.y:F1},{reward.position.z:F1})");
                    }
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to write reward to log: {e.Message}");
                }
            }

            // Fix for LogStrategyToFile method
            private void LogStrategyToFile(int agentId, int teamId, string strategyType, string strategyDescription, float successRate)
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(_logFilePath, true))
                    {
                        writer.WriteLine($"{Time.time:F2} | " +
                                        $"Agent-{agentId} | " +
                                        $"Team-{teamId} | " +
                                        $"Strategy | " +
                                        $"Type: {strategyType}, Success: {successRate:P0}, Description: {strategyDescription}");
                    }
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to write strategy to log: {e.Message}");
                }
            }

            // Fix for SummarizeObservationData method
            private string SummarizeObservationData(float[] data)
            {
                if (data == null || data.Length == 0)
                    return "[Empty]";

                if (data.Length <= 5)
                {
                    return "[" + string.Join(", ", data) + "]";
                }
                else
                {
                    // Calculate some basic statistics
                    float sum = 0, min = float.MaxValue, max = float.MinValue;
                    for (int i = 0; i < data.Length; i++)
                    {
                        sum += data[i];
                        min = Mathf.Min(min, data[i]);
                        max = Mathf.Max(max, data[i]);
                    }
                    float average = sum / data.Length;

                    return $"[{data.Length} values, Avg: {average:F2}, Min: {min:F2}, Max: {max:F2}]";
                }
            }

            // Fix for helper methods related to observations and strategies
            private List<AgentObservationData> GetRecentObservations(int agentId, int count = 10)
            {
                if (!_agentObservations.ContainsKey(agentId))
                    return new List<AgentObservationData>();

                // Return the most recent observations up to the requested count
                int startIndex = Mathf.Max(0, _agentObservations[agentId].Count - count);
                return _agentObservations[agentId].GetRange(startIndex, Mathf.Min(count, _agentObservations[agentId].Count - startIndex));
            }

            private List<StrategyData> GetSuccessfulStrategies(int teamId, int count = 3)
            {
                if (!_teamStrategies.ContainsKey(teamId))
                    return new List<StrategyData>();

                // Create a sorted list of strategies based on success rate
                List<StrategyData> sortedStrategies = new List<StrategyData>(_teamStrategies[teamId].strategies.Values);
                sortedStrategies.Sort((a, b) => b.successRate.CompareTo(a.successRate));

                // Return the top strategies
                return sortedStrategies.GetRange(0, Mathf.Min(count, sortedStrategies.Count));
            }

            private List<AbilityEffectivenessData> GetMostEffectiveAbilities(int teamId, int count = 3)
            {
                if (!_abilityEffectiveness.ContainsKey(teamId))
                    return new List<AbilityEffectivenessData>();

                // Create a sorted list of abilities based on effectiveness
                List<AbilityEffectivenessData> sortedAbilities =
                    new List<AbilityEffectivenessData>(_abilityEffectiveness[teamId].Values);

                sortedAbilities.Sort((a, b) => b.effectiveness.CompareTo(a.effectiveness));

                // Return the top abilities
                return sortedAbilities.GetRange(0, Mathf.Min(count, sortedAbilities.Count));
            }

            private List<string> GetRecentObservationsText(int agentId, int count)
            {
                List<string> results = new List<string>();

                if (_agentObservations.ContainsKey(agentId))
                {
                    var recentObs = GetRecentObservations(agentId, count);
                    foreach (var obs in recentObs)
                    {
                        string summary = $"Time: {obs.timestamp:F2}, Context: {obs.observationContext}";
                        results.Add(summary);
                    }
                }

                if (results.Count == 0)
                    results.Add("No recent observations");

                return results;
            }

            private List<string> GetRecentRewardsText(int agentId, int count)
            {
                List<string> results = new List<string>();

                if (_agentRewards.ContainsKey(agentId))
                {
                    int recentCount = Mathf.Min(count, _agentRewards[agentId].Count);
                    for (int i = _agentRewards[agentId].Count - recentCount; i < _agentRewards[agentId].Count; i++)
                    {
                        var reward = _agentRewards[agentId][i];
                        string summary = $"Value: {reward.reward:F2}, Reason: {reward.reason}";
                        results.Add(summary);
                    }
                }

                if (results.Count == 0)
                    results.Add("No recent rewards");

                return results;
            }

            private string GetTeamStrategiesText(int teamId)
            {
                if (!_teamStrategies.ContainsKey(teamId))
                    return "No team strategies";

                var strategies = GetSuccessfulStrategies(teamId, 2);
                if (strategies.Count == 0)
                    return "No successful strategies";

                List<string> results = new List<string>();
                foreach (var strategy in strategies)
                {
                    string summary = $"{strategy.strategyType} ({strategy.successRate:P0} success)";
                    results.Add(summary);
                }

                return string.Join(", ", results);
            }
            public bool EnableLLMIntegration    => _enableLLMIntegration;
            public bool DetailedLogging         => _detailedLogging;
            public bool LogObservationsToFile   => _logObservationsToFile;
            public bool SyncWithMLAgentsRewards => _syncWithMLAgentsRewards;
            public string ObservationLogPath    => _logFilePath;

            

            /// <summary>
            /// Struct to hold agent observation data
            /// </summary>
            [System.Serializable]
            public struct AgentObservationData
            {
                public float timestamp;
                public int agentId;
                public int teamId;
                public AgentObservation.ObservationContext observationContext;
                public float[] observationData;
            }

            /// <summary>
            /// Struct to hold agent reward data
            /// </summary>
            [System.Serializable]
            public struct AgentRewardData
            {
                public float timestamp;
                public int agentId;
                public int teamId;
                public float reward;
                public string reason;
                public Vector3 position;
            }

            /// <summary>
            /// Struct to hold team strategy data
            /// </summary>
            [System.Serializable]
            public class TeamStrategyData
            {
                public int teamId;
                public Dictionary<string, StrategyData> strategies;
            }

            /// <summary>
            /// Struct to hold strategy data
            /// </summary>
            [System.Serializable]
            public class StrategyData
            {
                public string strategyType;
                public string description;
                public float successRate;
                public float lastUpdated;
                public int useCount;
                public string episodeContext; // Episode context information
            }

            /// <summary>
            /// Struct to hold ability effectiveness data
            /// </summary>
            [System.Serializable]
            public class AbilityEffectivenessData
            {
                public string abilityName;
                public float effectiveness;
                public int useCount;
                public float totalReward;
                public float lastUsedTime;
                public float lastReward;
                public int episodeCount; // Track which episode this ability was used in
            }

            /// <summary>
            /// Struct to hold API request data
            /// </summary>
            public class APIRequest
            {
                public int agentId;
                public int teamId;
                public string prompt;
                public AbilityType  abilityType;
                public APIRequestType requestType;
                public string abilityToReplace;
            }

            /// <summary>
            /// Struct for contextual ability suggestions
            /// </summary>
            public class AbilitySuggestion
            {
                public AbilityType  recommendedAbilityType;
                public float confidence;  // 0-1 how confident we are in this suggestion
                public string reason;     // Why this ability type is recommended
            }


            private class EpisodeRecord
                {
                    public int AgentId;
                    public int TeamId;
                    public bool Success;
                    public float CumulativeReward;
                    public DateTime Timestamp;
                }

                private readonly List<EpisodeRecord> _episodeRecords = new List<EpisodeRecord>();

                /// <summary>
                /// Track the end of an agent's episode, recording its cumulative reward.
                /// </summary>
                /// <param name="agentId">Unique ID of the agent.</param>
                /// <param name="teamID">Team identifier.</param>
                /// <param name="success">Whether this episode met its success criteria.</param>
                /// <param name="cumulativeReward">Total reward earned this episode.</param>
                public void TrackAgentEpisode(int agentId, int teamID, bool success, float cumulativeReward)
                {
                    var rec = new EpisodeRecord {
                        AgentId = agentId,
                        TeamId = teamID,
                        Success = success,
                        CumulativeReward = cumulativeReward,
                        Timestamp = DateTime.UtcNow
                    };
                    _episodeRecords.Add(rec);

                    if (_logObservationsToFile)
                    {
                        try
                        {
                            var line = $"{rec.Timestamp:O}, Agent:{rec.AgentId}, Team:{rec.TeamId}, Success:{rec.Success}, Reward:{rec.CumulativeReward}{Environment.NewLine}";
                            File.AppendAllText(_logFilePath, line);
                        }
                        catch (Exception ex)
                        {
                            Debug.LogError($"LLMManager: Failed to write episode log → {ex.Message}");
                        }
                    }

                    Debug.Log($"[LLMManager] Tracked Episode — Agent {agentId} (Team {teamID}): Success={success}, Reward={cumulativeReward}");
                }


    }

