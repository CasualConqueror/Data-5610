using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using System.Collections.Generic;
using AgentKnowledgeSystem;
using System.IO;


public class CustomAgent : Agent
{
    // ---- REWARD STATISTICS TRACKING ----
    [Header("Reward Statistics")]
    [SerializeField] private bool _trackRewardStats = true;
    [SerializeField] private int _episodesToTrack = 100;
    [SerializeField] private float _statsOutputInterval = 10f;

    // Static collections for tracking rewards across all agents
    private static Dictionary<int, List<float>> _rewardsByTeam = new Dictionary<int, List<float>>();
    private static List<float> _allRewards = new List<float>();
    private static float _lastStatsOutputTime = 0f;

    // Local tracking for this agent
    private int _episodesCompleted = 0;
    private float _lastEpisodeReward = 0f;

    [Header("References")]
    public Transform target;
    public LLMManager llm;
    public AgentAbilityManager abilityManager;  // Assign this in inspector

    [Header("Training Settings")]
    // How often (in simulation time) to update cached opponent information in headless mode.
    private const float OPPONENT_UPDATE_INTERVAL = 0.5f;
    // Chance to trigger an LLM simulation for strategy changes in visual mode.
    private const int LLM_MUTATION_CHANCE = 1500;
    public float targetReachReward = 1.0f;
    public float attackPenalty = -0.03f;
    // Debug flag for printing observation info.
    public bool debugObservations = true;

    [Header("Mode and Identification")]
    [HideInInspector]
    public int agentId;
    public int teamID;
    // If true, the agent will rely on registry and synthetic data rather than raycasts.
    public bool headlessMode = false;

    [Header("Knowledge Sharing")]
    [SerializeField] private bool _shareKnowledge = true;
    [SerializeField] private bool _useSharedKnowledge = true;
    [SerializeField] private int _sharedObservationCount = 5;
    [SerializeField] private float _sharedKnowledgeInfluence = 0.3f;
    [Tooltip("Controls how much shared knowledge affects decisions (0-1)")]
    [SerializeField] private float _currentInfluenceFactor = 1.0f; // Dynamic influence factor adjusted by staged learning

    // Cached opponents for headless mode updates.
    private List<CustomAgent> cachedNearbyOpponents = new List<CustomAgent>();
    private float nearbyOpponentUpdateTimer = 0f;

    // Storage for recent events (if needed for processing later).
    private Dictionary<string, List<AgentEventSystem.AgentEvent>> recentEvents = new Dictionary<string, List<AgentEventSystem.AgentEvent>>();

    // Component references.
    private AgentMovementSystem movementSystem;
    private AgentHealthSystem healthSystem;
    private AgentBlockSystem blockSystem;
    private AgentPerceptionSystem perceptionSystem;

    // Counter for observation debugging.
    private int currentObservationCount = 0;

    // Environment ID and episode tracking for knowledge sharing
    private int _environmentId = 0;
    private int _currentEpisodeId = 0;

    // Cache for our observation data (used for sharing)
    private float[] _lastObservationData;

    // Performance tracking to determine if observations should be shared (for selective sharing)
    private float _recentPerformanceScore = 0f;
    private Queue<float> _recentRewards = new Queue<float>();
    private const int MAX_RECENT_REWARDS = 10;

    // LLM Integration settings
    [Header("LLM Integration")]
    [SerializeField] private bool _enableLLMIntegration = true;

    // Agent type identification (for tailoring ability rewards)
    [Header("Agent Type Settings")]
    [SerializeField] private List<int> _agent1TeamIDs = new List<int> { 1 };  // Team IDs for Agent_1
    [SerializeField] private List<int> _agent2TeamIDs = new List<int> { 2 };  // Team IDs for Agent_2
    private bool _isAgent1 = false;
    private bool _isAgent2 = false;


    private void OnBlockEvent(AgentEventSystem.AgentEvent evt)
    {
        if (evt == null || !llm.EnableLLMIntegration)
            return;

        int blockingAgentId = evt.sourceAgentId;
        Vector3 eventPosition = evt.position;

        // pull out custom data
        float blockEffectiveness = evt.data.TryGetValue("effectiveness", out var e)
                                   ? (float)e
                                   : 0f;
        bool perfectBlock = evt.data.TryGetValue("perfectBlock", out var p)
                            && (bool)p;

        // find the agent that did the block
        CustomAgent blockingAgent = null;
        foreach (var agent in AgentRegistry.Instance.GetNearbyAgents(eventPosition, 20f))
            if (agent.agentId == blockingAgentId)
            {
                blockingAgent = agent;
                break;
            }

        if (blockingAgent == null) return;

        // 1) record strategy
        llm.RecordAgentStrategy(
            blockingAgentId,
            blockingAgent.teamID,
            "DefensiveBlock",
            $"Block effectiveness: {blockEffectiveness:F2}, Perfect: {perfectBlock}",
            blockEffectiveness
        );

        // 2) record reward
        float reward = perfectBlock
                       ? 0.1f
                       : blockEffectiveness * 0.05f;
        llm.RecordAgentReward(
            blockingAgentId,
            blockingAgent.teamID,
            reward,
            $"Block_Success_{(perfectBlock ? "Perfect" : "Partial")}",
            eventPosition
        );

        // 3) detailed logging
        if (llm.DetailedLogging && llm.LogObservationsToFile)
        {
            using (var writer = new StreamWriter(llm.ObservationLogPath, append: true))
            {
                writer.WriteLine(
                    $"{Time.time:F2} | " +
                    $"Agent-{blockingAgentId} | " +
                    $"Team-{blockingAgent.teamID} | " +
                    $"BlockEvent | " +
                    $"Effectiveness: {blockEffectiveness:F2}, Perfect: {perfectBlock}"
                );
            }
        }

        // 4) sync with ML‑Agents stats
        if (llm.SyncWithMLAgentsRewards)
        {
            var stats = Academy.Instance.StatsRecorder;
            stats.Add(perfectBlock ? "Block/PerfectBlock" : "Block/PartialBlock", 1);
            stats.Add("Block/Effectiveness", blockEffectiveness);
        }
    }


    private void RetrieveSharedKnowledge()
        {
            if (AgentKnowledgePoolManager.Instance == null)
                return;

            // Get recent observations from similar agents (same team)
            List<AgentObservation> recentObservations =
                AgentKnowledgePoolManager.Instance.GetRecentObservations(teamID, _sharedObservationCount);

            // Get average reward for this agent type/team
            float avgReward =
                AgentKnowledgePoolManager.Instance.GetAverageReward(teamID, 100);

            // Get action-specific reward statistics
            RewardStatistics attackStats =
                AgentKnowledgePoolManager.Instance.GetRewardStatisticsForAction(teamID, "Attack");
            RewardStatistics blockStats =
                AgentKnowledgePoolManager.Instance.GetRewardStatisticsForAction(teamID, "Block");

            // Log the shared knowledge retrieval and influence factor
            if (debugObservations)
            {
                Debug.Log($"Agent {agentId} (Team {teamID}) retrieved {recentObservations.Count} observations and " +
                          $"average reward {avgReward:F2} from knowledge pool. " +
                          $"Attack stats: {attackStats.AverageReward:F2}, Block stats: {blockStats.AverageReward:F2} " +
                          $"- Influence factor: {_currentInfluenceFactor:F3}");
            }
        }

    private string GetCurrentContext()
        {
            // Create a simple context string with key agent state information
            string context = $"{{\"health\":{healthSystem.currentHealth/healthSystem.maxHealth:F2}," +
                              $"\"isBlocking\":{blockSystem.isBlocking.ToString().ToLower()}," +
                              $"\"attackReady\":{(healthSystem.attackTimer <= 0).ToString().ToLower()}," +
                              $"\"performanceScore\":{_recentPerformanceScore:F3}}}";

            return context;
        }

    public void OnEventReceived(AgentEventSystem.AgentEvent evt)
        {
            if (!recentEvents.ContainsKey(evt.eventType))
            {
                recentEvents[evt.eventType] = new List<AgentEventSystem.AgentEvent>();
            }
            recentEvents[evt.eventType].Add(evt);
            if (recentEvents[evt.eventType].Count > 10)
            {
                recentEvents[evt.eventType].RemoveAt(0);
            }
        }

    private void OnAttackEvent(AgentEventSystem.AgentEvent evt)
        {
            if (evt.sourceAgentId != agentId)
            {
                float distance = Vector3.Distance(transform.position, evt.position);
                if (distance <= evt.radius)
                {
                    float damage = 0f;
                    if (evt.data.ContainsKey("damage"))
                    {
                        damage = (float)evt.data["damage"];
                    }
                    if (!blockSystem.isBlocking || (evt.data.ContainsKey("bypassBlock") && (bool)evt.data["bypassBlock"]))
                    {
                        // Retrieve the attacker using the AgentRegistry and pass it to TakeDamage.
                        CustomAgent attacker = AgentRegistry.Instance.GetAgentById(evt.sourceAgentId);
                        healthSystem.TakeDamage(damage, attacker);
                    }
                    else
                    {
                        blockSystem.OnAttackBlocked();

                        // Share successful block information
                        if (_shareKnowledge)
                        {
                            ContributeRewardToPool(blockSystem.blockReward, "Block");
                        }
                    }
                }
            }
        }

    public new void AddReward(float reward)
        {
            // Call base implementation
            base.AddReward(reward);

            // Contribute reward to knowledge pool
            if (_shareKnowledge && AgentKnowledgePoolManager.Instance != null)
            {
                ContributeRewardToPool(reward, "Default");
            }

            // Send reward information to LLM manager with generic reason
            if (llm != null && _enableLLMIntegration)
            {
                llm.RecordAgentReward(agentId, teamID, reward, "Generic", transform.position);
            }
        }

    public void AddReward(float reward, string reason)
        {
            // Call base implementation from Agent class
            base.AddReward(reward);

            // Share with knowledge pool if enabled
            if (_shareKnowledge && AgentKnowledgePoolManager.Instance != null)
            {
                ContributeRewardToPool(reward, reason);
            }

            // Send reward information to LLM manager
            if (llm != null)
            {
                llm.RecordAgentReward(agentId, teamID, reward, reason, transform.position);

                if (debugObservations && Mathf.Abs(reward) > 0.01f)
                {
                    Debug.Log($"Agent {agentId} reported reward {reward:F3} for '{reason}' to LLM Manager");
                }
            }
        }

    private AgentObservation.ObservationContext GetCurrentObservationContext()
        {
            AgentObservation.ObservationContext context = AgentObservation.ObservationContext.None;

            // Determine context based on agent state
            if (healthSystem != null)
            {
                // If health is low, mark as in critical state
                if (healthSystem.currentHealth < healthSystem.maxHealth * 0.3f)
                {
                    context = AgentObservation.ObservationContext.DamageTaken;
                }
                // If attack timer is active, we've likely just attacked
                else if (healthSystem.attackTimer > 0)
                {
                    context = AgentObservation.ObservationContext.DamageDealt;
                }
            }

            return context;
        }

    public void NotifyAbilityOutcome(float effectiveness, string abilityName)
        {
            // Convert effectiveness to reward (-1 to 1 scale)
            float abilityReward = (effectiveness - 0.5f) * 2.0f;

            // Add reward based on effectiveness
            AddReward(abilityReward, "AbilityOutcome");

            // Notify the LLM system
            if (llm != null && _enableLLMIntegration)
            {
                NotifyAbilityUsage(abilityName, effectiveness);
            }
        }

    public string RequestAbility(float performanceScore)
        {
            if (llm == null)
                return string.Empty;

            // Use the new ML Agents aware ability generation method
            return llm.GenerateAbility(agentId, teamID, performanceScore);
        }

    private void ContributeRewardToPool(float reward, string reason)
        {
            // Update performance tracking for selective sharing
            UpdatePerformanceScore(reward);

            // Create reward record
            RewardRecord record = new RewardRecord(
                Time.time,
                _environmentId,
                _currentEpisodeId,
                agentId,
                reward,
                reason
            );

            // Add to pool via manager
            AgentKnowledgePoolManager.Instance?.AddRewardRecord(teamID, record);

            if (debugObservations)
            {
                Debug.Log($"Agent {agentId} (Team {teamID}) contributed reward {reward} for reason '{reason}' to pool");
            }
        }

    public string GetLLMInsights()
        {
            if (llm == null)
                return "LLM Manager not available.";

            return llm.GenerateAgentInsight(agentId, teamID);
        }

        public void NotifyAbilityUsage(string abilityName, float effectiveness)
        {
            if (llm != null && _enableLLMIntegration)
            {
                llm.RecordAgentReward(agentId, teamID, effectiveness,
                    $"Ability:{abilityName}", transform.position);
                llm.RecordAgentStrategy(agentId, teamID, "AbilityUsage",
                    $"Used ability {abilityName}", effectiveness);
            }
        }
    // Synthetic perception methods for headless mode
    private void ProvideSyntheticRaycastData(VectorSensor sensor)
    {
        // For each synthetic ray direction...
        for (int i = 0; i < perceptionSystem.rayCount; i++)
        {
            float angle = (i / (float)perceptionSystem.rayCount) * 360f;
            Vector3 rayDir = Quaternion.Euler(0, angle, 0) * transform.forward;

            bool hit = false;
            float closestDist = perceptionSystem.rayLength;
            CustomAgent closestAgent = null;

            // Check against cached nearby opponents.
            foreach (var agent in cachedNearbyOpponents)
            {
                Vector3 dirToAgent = (agent.transform.position - transform.position).normalized;
                float angleToAgent = Vector3.Angle(rayDir, dirToAgent);
                float distToAgent = Vector3.Distance(transform.position, agent.transform.position);
                if (angleToAgent < 20f && distToAgent < closestDist)
                {
                    hit = true;
                    closestDist = distToAgent;
                    closestAgent = agent;
                }
            }

            // Add synthetic observations mimicking real raycast data.
            if (hit && closestAgent != null)
            {
                AddObservationWithDebug(sensor, 1f, $"Ray {i} Hit");
                AddObservationWithDebug(sensor, closestDist / perceptionSystem.rayLength, $"Ray {i} Distance");
                if (closestAgent == target.GetComponent<CustomAgent>())
                {
                    AddObservationWithDebug(sensor, 1f, $"Ray {i} Hit Target");
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} Not Hit Opponent");
                }
                else if (closestAgent.teamID != this.teamID)
                {
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} Not Hit Target");
                    AddObservationWithDebug(sensor, 1f, $"Ray {i} Hit Opponent");

                    AgentHealthSystem opponentHealth = closestAgent.GetComponent<AgentHealthSystem>();
                    AgentBlockSystem opponentBlock = closestAgent.GetComponent<AgentBlockSystem>();
                    AddObservationWithDebug(sensor, opponentHealth.currentHealth / opponentHealth.maxHealth, $"Ray {i} Opponent Health");
                    AddObservationWithDebug(sensor, opponentBlock.isBlocking ? 1f : 0f, $"Ray {i} Opponent Blocking");
                }
                else
                {
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} Not Hit Target");
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} Not Hit Opponent");
                    AddObservationWithDebug(sensor, 1f, $"Ray {i} Hit Other");
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} Other Default Value");
                }
            }
            else
            {
                AddObservationWithDebug(sensor, 0f, $"Ray {i} No Hit");
                AddObservationWithDebug(sensor, 1f, $"Ray {i} Max Distance");
                AddObservationWithDebug(sensor, 0f, $"Ray {i} Default Target");
                AddObservationWithDebug(sensor, 0f, $"Ray {i} Default Opponent");
                AddObservationWithDebug(sensor, 1f, $"Ray {i} Default Health");
                AddObservationWithDebug(sensor, 0f, $"Ray {i} Default Block");
            }
        }
    }

    private void ContributeObservationToPool(float[] observationData)
        {
            // Create observation object
            AgentObservation observation = new AgentObservation(
                Time.time,
                _environmentId,
                _currentEpisodeId,
                agentId,
                observationData,
                GetCurrentContext()
            );

            // Add to pool via manager
            AgentKnowledgePoolManager.Instance?.AddObservation(teamID, observation);

            if (debugObservations)
            {
                Debug.Log($"Agent {agentId} (Team {teamID}) contributed observation to pool");
            }
        }

    private void ProvideSyntheticForwardPerception(VectorSensor sensor)
        {
            // Determine if an agent is directly in front.
            bool hitTarget = false;
            bool hitOpponent = false;
            float closestDistance = 10f;
            CustomAgent closestAgent = null;

            foreach (var agent in cachedNearbyOpponents)
            {
                Vector3 dirToAgent = (agent.transform.position - transform.position).normalized;
                float angleToAgent = Vector3.Angle(transform.forward, dirToAgent);
                float distToAgent = Vector3.Distance(transform.position, agent.transform.position);
                if (angleToAgent < 30f && distToAgent < closestDistance)
                {
                    closestDistance = distToAgent;
                    closestAgent = agent;
                    if (closestAgent.GetInstanceID() == target.GetInstanceID())
                    {
                        hitTarget = true;
                        hitOpponent = false;
                    }
                    else if (closestAgent.teamID != this.teamID)
                    {
                        hitTarget = false;
                        hitOpponent = true;
                    }
                }
            }

            if (hitTarget)
            {
                AddObservationWithDebug(sensor, 1f, "Forward Ray Hit Target");
                AddObservationWithDebug(sensor, closestDistance / 10f, "Forward Ray Target Distance");
            }
            else
            {
                AddObservationWithDebug(sensor, 0f, "Forward Ray No Target");
                AddObservationWithDebug(sensor, 1f, "Forward Ray Max Distance");
            }

            if (hitOpponent && closestAgent != null)
            {
                AgentHealthSystem opponentHealth = closestAgent.GetComponent<AgentHealthSystem>();
                AgentBlockSystem opponentBlock = closestAgent.GetComponent<AgentBlockSystem>();
                AddObservationWithDebug(sensor, 1f, "Forward Ray Hit Opponent");
                AddObservationWithDebug(sensor, closestDistance / 10f, "Forward Ray Opponent Distance");
                AddObservationWithDebug(sensor, opponentHealth.currentHealth / opponentHealth.maxHealth, "Forward Ray Opponent Health");
                AddObservationWithDebug(sensor, opponentBlock.isBlocking ? 1f : 0f, "Forward Ray Opponent Blocking");
            }
            else
            {
                AddObservationWithDebug(sensor, 0f, "Forward Ray No Opponent");
                AddObservationWithDebug(sensor, 1f, "Forward Ray Default Distance");
                AddObservationWithDebug(sensor, 1f, "Forward Ray Default Health");
                AddObservationWithDebug(sensor, 0f, "Forward Ray Default Block");
            }
        }

    public override void OnActionReceived(ActionBuffers actions)
        {
            // Update the attack cooldown.
            healthSystem.UpdateCooldowns();

            // Process block action.
            int blockAction = actions.DiscreteActions[1];
            blockSystem.SetBlockState(blockAction == 1);

            // Process movement actions (only when not blocking).
            float moveX = 0f;
            float moveZ = 0f;
            float rotateY = actions.ContinuousActions[2];
            if (!blockSystem.isBlocking)
            {
                moveX = actions.ContinuousActions[0];
                moveZ = actions.ContinuousActions[1];
            }
            movementSystem.Move(moveX, moveZ, rotateY);

            // Process attack action.
            int attackAction = actions.DiscreteActions[0];

            // Process ability action - NEW
            int abilityAction = actions.DiscreteActions[2]; // Assuming this is in the third discrete branch
            if (abilityManager != null && abilityAction > 0)
            {
                abilityManager.ProcessAbilityAction(abilityAction);
            }

            // Record strategy information for LLM learning
            if (llm != null)
            {
                // Create a strategy description based on the agent's actions
                string strategyType = "";
                string strategyDescription = "";
                float successRate = 0.5f;  // Default neutral value

                // Find closest opponent for strategy evaluation
                CustomAgent opponent = null;
                if (headlessMode) {
                    opponent = AgentRegistry.Instance.FindClosestOpponent(transform.position, teamID, healthSystem.attackRange * 1.5f);
                } else if (perceptionSystem != null) {
                    opponent = perceptionSystem.FindClosestOpponent();
                } else {
                    // Handle the case where perceptionSystem is null
                    Debug.LogWarning($"Agent {agentId}: perceptionSystem is null, cannot find closest opponent");
                }

                float distanceToOpponent = 0f;
                float angleToOpponent = 0f;

                if (opponent != null)
                {
                    Vector3 dirToOpponent = (opponent.transform.position - transform.position).normalized;
                    angleToOpponent = Vector3.Angle(transform.forward, dirToOpponent);
                    distanceToOpponent = Vector3.Distance(transform.position, opponent.transform.position);
                }

                // Determine strategy type based on actions
                if (attackAction == 1 && blockAction == 0)
                {
                    strategyType = "Aggressive";

                    if (opponent != null)
                    {
                        strategyDescription = $"Agent attacks when facing opponent at distance {distanceToOpponent:F1}";

                        // Estimate success based on whether the attack was successful
                        if (angleToOpponent <= 45f && distanceToOpponent <= healthSystem.attackRange)
                        {
                            successRate = 0.7f;  // Successful attack positioning
                        }
                        else
                        {
                            successRate = 0.3f;  // Failed attack positioning
                        }
                    }
                    else
                    {
                        strategyDescription = "Agent attacks with no visible opponent";
                        successRate = 0.2f;  // Not effective to attack nothing
                    }
                }
                else if (blockAction == 1)
                {
                    strategyType = "Defensive";
                    strategyDescription = "Agent blocks when opponent is nearby";

                    // Success depends on whether there's actually an opponent nearby to block against
                    if (opponent != null && distanceToOpponent < healthSystem.attackRange * 1.5f)
                    {
                        successRate = 0.8f;  // Appropriate defensive posture
                    }
                    else
                    {
                        successRate = 0.2f;  // Blocking with no nearby threats
                    }
                }
                else if (Mathf.Abs(moveX) > 0.5f || Mathf.Abs(moveZ) > 0.5f)
                {
                    strategyType = "Movement";

                    // Calculate dot product between movement and direction to target
                    Vector3 moveDir = new Vector3(moveX, 0, moveZ).normalized;
                    float dotToTarget = Vector3.Dot(moveDir, (target.position - transform.position).normalized);

                    if (dotToTarget > 0.7f)
                    {
                        strategyDescription = "Agent moves directly toward target";
                        successRate = 0.75f;
                    }
                    else if (dotToTarget < -0.5f)
                    {
                        strategyDescription = "Agent retreats from target";
                        successRate = 0.4f;
                    }
                    else
                    {
                        strategyDescription = "Agent moves perpendicular to target direction";
                        successRate = 0.5f;
                    }
                }
                else if (Mathf.Abs(rotateY) > 0.5f)
                {
                    strategyType = "Exploration";
                    strategyDescription = "Agent is looking around";
                    successRate = 0.6f;
                }
                else
                {
                    strategyType = "Waiting";
                    strategyDescription = "Agent is stationary";
                    successRate = 0.3f;
                }

                // Add ability usage to strategy description if applicable
                if (abilityAction > 0 && abilityManager != null && abilityAction <= abilityManager.abilities.Count)
                {
                    string abilityName = abilityManager.abilities[abilityAction - 1].abilityName;
                    strategyType += "WithAbility";
                    strategyDescription += $" and uses {abilityName} ability";
                }

                // Only record non-empty strategies
                if (!string.IsNullOrEmpty(strategyType))
                {
                    llm.RecordAgentStrategy(agentId, teamID, strategyType, strategyDescription, successRate);

                    if (debugObservations && Time.frameCount % 100 == 0)
                    {
                        Debug.Log($"Agent {agentId} reported strategy '{strategyType}' to LLM Manager");
                    }
                }
            }

            // Continue with the rest of the method (attack processing)
            if (attackAction == 1 && healthSystem.attackTimer <= 0 && !blockSystem.isBlocking)
            {
                // Select opponent based on mode.
                CustomAgent opponent = null;
                if (headlessMode) {
                    opponent = AgentRegistry.Instance.FindClosestOpponent(transform.position, teamID, healthSystem.attackRange * 1.5f);
                } else if (perceptionSystem != null) {
                    opponent = perceptionSystem.FindClosestOpponent();
                } else {
                    // Handle the case where perceptionSystem is null
                    Debug.LogWarning($"Agent {agentId}: perceptionSystem is null, cannot find closest opponent");
                }

                if (opponent != null)
                {
                    Vector3 dirToOpponent = (opponent.transform.position - transform.position).normalized;
                    float angleToOpponent = Vector3.Angle(transform.forward, dirToOpponent);
                    float distanceToOpponent = Vector3.Distance(transform.position, opponent.transform.position);

                    // Optionally apply a facing reward.
                    if (perceptionSystem.GetType().GetMethod("CalculateFacingReward") != null)
                    {
                        float facingReward = perceptionSystem.CalculateFacingReward(opponent);
                        AddReward(facingReward * 0.01f, "Facing");
                    }

                    if (angleToOpponent <= 45f && distanceToOpponent <= healthSystem.attackRange)
                    {
                        Vector3 attackPoint = opponent.transform.position;
                        if (headlessMode)
                        {
                            AgentEventSystem.AgentEvent attackEvent = new AgentEventSystem.AgentEvent(
                                agentId, attackPoint, healthSystem.attackRange, "Attack");
                            attackEvent.data["damage"] = healthSystem.attackDamage;
                            attackEvent.data["bypassBlock"] = false;
                            AgentEventSystem.Instance.BroadcastEvent(attackEvent);
                            // Reset attack timer in headless mode.
                            healthSystem.ResetAttackTimer();

                            // Track successful attack in knowledge pool
                            if (_shareKnowledge)
                            {
                                ContributeRewardToPool(healthSystem.damageReward, "Attack");
                            }
                        }
                        else
                        {
                            healthSystem.TryAttack(opponent, attackPoint);

                            // Track successful attack in knowledge pool
                            if (_shareKnowledge)
                            {
                                ContributeRewardToPool(healthSystem.damageReward, "Attack");
                            }
                        }
                    }
                    else
                    {
                        AddReward(attackPenalty, "FailedAttack");
                    }
                }
                else
                {
                    AddReward(attackPenalty, "FailedAttack");
                }
            }

            if (debugObservations)
            {
                Debug.Log($"🚀 Agent {teamID} Action: X={moveX:F2}, Z={moveZ:F2}, Rotate={rotateY:F2}, Attack={attackAction}, Block={blockAction}, Ability={abilityAction}");
            }

            // Check if the agent has reached the target.
            float distanceToTarget = Vector3.Distance(transform.localPosition, target.localPosition);
            if (distanceToTarget < 1.5f)
            {
                SetReward(targetReachReward);

                // Record success in knowledge pool
                if (_shareKnowledge && AgentKnowledgePoolManager.Instance != null)
                {
                    ContributeRewardToPool(targetReachReward, "TargetReached");
                }

                if (TrainingStatsManager.Instance != null)
                {
                    int envId = (int)Academy.Instance.EnvironmentParameters.GetWithDefault("env_id", 0);
                    TrainingStatsManager.Instance.RecordEpisodeResult(envId, targetReachReward, true);
                }
                ReportTargetReached(); // Report via the Academy's StatsRecorder.
                NotifyEpisodeEnding();
                EndEpisode();
            }

            // Occasionally trigger an LLM simulation (only in visual mode).
            if (!headlessMode && Random.Range(0, LLM_MUTATION_CHANCE) == 0 && llm != null)
            {
                // First, generate a prompt based on the agent's recent history
                string llmPrompt = llm.GenerateSystemPrompt(agentId, teamID);

                // Log the prompt for debugging
                if (debugObservations)
                {
                    Debug.Log($"[LLM Prompt for Agent {agentId}]\n{llmPrompt}");
                }

                // Calculate a performance score based on recent rewards
                float performanceScore = 0.5f; // Default neutral value

                // If we have enough rewards stored, calculate an average
                if (_recentRewards.Count > 0)
                {
                    float sum = 0f;
                    foreach (float r in _recentRewards)
                    {
                        sum += r;
                    }
                    performanceScore = Mathf.Clamp01((sum / _recentRewards.Count) + 0.5f); // Normalize to 0-1 range
                }

                // Additional contextual factors that might affect the score
                float distancePercent = Mathf.Clamp01(distanceToTarget / 10f);  // Distance to target (normalized)
                float healthPercent = healthSystem != null ?
                                     healthSystem.currentHealth / healthSystem.maxHealth : 1.0f;  // Health status

                // Adjust performance score based on these factors
                performanceScore = performanceScore * 0.6f + (1.0f - distancePercent) * 0.3f + healthPercent * 0.1f;

                // Fetch insights from the LLM based on the calculated performance
                llm.SimulateLLMCall(performanceScore);

                if (debugObservations)
                {
                    Debug.Log($"Agent {agentId} requested LLM insights with performance score: {performanceScore:F2}");
                }
            }
        }

    public void ReportTargetReached()
        {
            Academy.Instance.StatsRecorder.Add("Target/ReachedCount", 1);
            Academy.Instance.StatsRecorder.Add("Agent/Distance", Vector3.Distance(transform.position, target.position));
        }

    public void NotifyEpisodeEnding()
        {
            // Get final performance stats before ending the episode
            float finalReward = GetCumulativeReward();

            // Record reward for statistics
            RecordEpisodeReward(finalReward);

            // Notify LLMManager if enabled
            if (llm != null && _enableLLMIntegration)
            {
                // Track episode completion
                llm.TrackAgentEpisode(agentId, teamID, true, finalReward);

                if (debugObservations)
                {
                    Debug.Log($"Agent {agentId} completed episode with reward {finalReward:F2}");
                }
            }
        }

    public override void Heuristic(in ActionBuffers actionsOut)
        {
            var continuousActions = actionsOut.ContinuousActions;
            var discreteActions = actionsOut.DiscreteActions;

            // Movement and rotation
            continuousActions[0] = Input.GetAxis("Horizontal");
            continuousActions[1] = Input.GetAxis("Vertical");

            if (Input.GetKey(KeyCode.Q))
                continuousActions[2] = -1.0f;
            else if (Input.GetKey(KeyCode.E))
                continuousActions[2] = 1.0f;
            else
                continuousActions[2] = 0f;

            // Attack and block
            discreteActions[0] = Input.GetKey(KeyCode.Space) ? 1 : 0;
            discreteActions[1] = Input.GetKey(KeyCode.B) ? 1 : 0;

            // Ability usage - from 1-3 keys (0 means no ability)
            if (Input.GetKey(KeyCode.Alpha1))
                discreteActions[2] = 1;
            else if (Input.GetKey(KeyCode.Alpha2))
                discreteActions[2] = 2;
            else if (Input.GetKey(KeyCode.Alpha3))
                discreteActions[2] = 3;
            else
                discreteActions[2] = 0;
        }

    public override void Initialize()
    {
        try
        {
            base.Initialize();

            // Determine agent type based on team ID
            _isAgent1 = _agent1TeamIDs.Contains(teamID);
            _isAgent2 = _agent2TeamIDs.Contains(teamID);

            if (debugObservations)
            {
                Debug.Log($"Initializing agent {agentId} (Team {teamID}) identified as: " +
                         $"{(_isAgent1 ? "Agent_1" : (_isAgent2 ? "Agent_2" : "Generic Agent"))}");
            }

            // Cache required components with null checks
            movementSystem = GetComponent<AgentMovementSystem>();
            healthSystem = GetComponent<AgentHealthSystem>();
            blockSystem = GetComponent<AgentBlockSystem>();
            perceptionSystem = GetComponent<AgentPerceptionSystem>();

            // Check if we have an ability manager and assign it if not
            if (abilityManager == null)
            {
                abilityManager = GetComponent<AgentAbilityManager>();
                if (abilityManager == null)
                {
                    Debug.LogWarning($"Agent {agentId} has no AgentAbilityManager assigned. Abilities will not be available.");
                }
            }

            // Explicitly assign this agent to perception system
            if (perceptionSystem != null)
            {
                perceptionSystem.assignedAgent = this;
            }

            // Initialize sub-systems with null checks
            if (healthSystem != null) healthSystem.Initialize();
            if (blockSystem != null) blockSystem.Initialize();
            if (perceptionSystem != null) perceptionSystem.Initialize();

            // Check for singletons before using them
            if (AgentRegistry.Instance != null)
            {
                agentId = GetInstanceID();
                AgentRegistry.Instance.RegisterAgent(this, agentId);
            }
            else
            {
                Debug.LogWarning("AgentRegistry.Instance not found during agent initialization. Registration skipped.");
            }

            if (AgentEventSystem.Instance != null)
            {
                AgentEventSystem.Instance.RegisterListener("Attack", OnAttackEvent);
                AgentEventSystem.Instance.RegisterListener("Block", OnBlockEvent);
            }
            else
            {
                Debug.LogWarning("AgentEventSystem.Instance not found during agent initialization. Event registration skipped.");
            }

            // Set environment ID from the Academy if available
            _environmentId = (int)Academy.Instance.EnvironmentParameters.GetWithDefault("env_id", 0);

            // Initialize performance tracking
            _recentPerformanceScore = 0f;
            _recentRewards.Clear();

            if (_shareKnowledge && debugObservations)
            {
                Debug.Log($"Agent {agentId} (Team {teamID}) initialized with knowledge sharing in environment {_environmentId}");
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"Error in CustomAgent.Initialize(): {e.Message}\n{e.StackTrace}");
        }
    }

    public override void OnEpisodeBegin()
    {
        // Reset systems.
        healthSystem.Initialize();
        blockSystem.Initialize();
        movementSystem.ResetMovement();

        // Increment episode ID for knowledge sharing.
        _currentEpisodeId++;

        // Update influence factor for staged learning.
        UpdateInfluenceFactor();

        // Reset performance tracking for selective sharing.
        _recentPerformanceScore = 0f;
        _recentRewards.Clear();

        // Capture the current Y position to preserve it.
        float currentY = transform.localPosition.y;

        // Define a smaller spawn range to keep agents closer to the center.
        float spawnRange = 3.5f; // This will yield positions between -2 and 2 for both X and Z.

        // Randomize spawn position relative to the center, using the current Y value.
        transform.localPosition = new Vector3(Random.Range(-spawnRange, spawnRange), 1, Random.Range(-spawnRange, spawnRange));

        // Optionally randomize the target's position, preserving its Y position.
        if (target != null)
        {
            float targetY = target.localPosition.y;
            target.localPosition = new Vector3(Random.Range(-spawnRange, spawnRange), 1, Random.Range(-spawnRange, spawnRange));
        }

        // If using shared knowledge, retrieve from the pool at episode start.
        if (_useSharedKnowledge)
        {
            RetrieveSharedKnowledge();
        }

        // If we have an ability manager, notify it
        if (abilityManager != null)
        {
            abilityManager.OnEpisodeBegin();
        }

        // Notify LLMManager about episode completion if it exists
        if (llm != null && _enableLLMIntegration)
        {
            // Track the episode in LLMManager with current cumulative reward
            llm.TrackAgentEpisode(agentId, teamID, true, GetCumulativeReward());
        }
    }

    /// <summary>
    /// Updates the influence factor based on current episode (for staged learning)
    /// </summary>
    private void UpdateInfluenceFactor()
    {
        if (AgentKnowledgePoolManager.Instance != null)
        {
            // Get the pool for our team
            AgentKnowledgePool pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(teamID);

            // Check if the pool implements staged learning
            if (pool._useStagedLearning)
            {
                // Calculate how far into training we are (after minimum episodes)
                int episodesAfterMin = System.Math.Max(0, _currentEpisodeId - pool._minEpisodesBeforeSharing);

                // Gradually increase sharing factor (capped at max influence)
                _currentInfluenceFactor = System.Math.Min(_sharedKnowledgeInfluence,
                                            episodesAfterMin * pool._sharingScalingFactor);

                if (debugObservations && _currentEpisodeId % 10 == 0)
                {
                    Debug.Log($"Agent {agentId} (Team {teamID}) - Episode {_currentEpisodeId}: " +
                             $"Knowledge influence updated to {_currentInfluenceFactor:F3}");
                }
            }
            else
            {
                // If staged learning is disabled, use the full influence directly
                _currentInfluenceFactor = _sharedKnowledgeInfluence;
            }
        }
    }

    private void OnDestroy()
    {
        // Unregister from the registry and event system.
        if (AgentRegistry.Instance != null)
        {
            AgentRegistry.Instance.UnregisterAgent(this, agentId);
        }

        if (AgentEventSystem.Instance != null)
        {
            AgentEventSystem.Instance.UnregisterListener("Attack", OnAttackEvent);
            AgentEventSystem.Instance.UnregisterListener("Block", OnBlockEvent);
        }
    }


    /// <summary>
    /// Output reward statistics to the console
    /// </summary>
    private void OutputRewardStats()
    {
        Debug.Log("========= AGENT REWARD STATISTICS =========");

        // Output global stats
        if (_allRewards.Count > 0)
        {
            float mean = CalculateMean(_allRewards);
            float stdDev = CalculateStdDev(_allRewards, mean);
            Debug.Log($"Overall: Mean Reward = {mean:F3}, StdDev = {stdDev:F3}, Episodes = {_allRewards.Count}");
        }
        else
        {
            Debug.Log("No episodes completed yet.");
        }

        // Output team-specific stats
        foreach (var team in _rewardsByTeam)
        {
            if (team.Value.Count > 0)
            {
                float mean = CalculateMean(team.Value);
                float stdDev = CalculateStdDev(team.Value, mean);
                Debug.Log($"Team {team.Key}: Mean Reward = {mean:F3}, StdDev = {stdDev:F3}, Episodes = {team.Value.Count}");
            }
        }

        Debug.Log("============================================");
    }

    /// <summary>
    /// Calculate the mean of a list of values
    /// </summary>
    private float CalculateMean(List<float> values)
    {
        float sum = 0;
        foreach (float value in values)
        {
            sum += value;
        }
        return sum / values.Count;
    }

    /// <summary>
    /// Calculate the standard deviation of a list of values
    /// </summary>
    private float CalculateStdDev(List<float> values, float mean)
    {
        if (values.Count <= 1)
            return 0;

        float sumSquaredDifferences = 0;
        foreach (float value in values)
        {
            float difference = value - mean;
            sumSquaredDifferences += difference * difference;
        }

        return Mathf.Sqrt(sumSquaredDifferences / (values.Count - 1));
    }

    /// <summary>
    /// Record a completed episode's reward for statistics
    /// </summary>
    private void RecordEpisodeReward(float reward)
    {
        if (!_trackRewardStats)
            return;

        _lastEpisodeReward = reward;
        _episodesCompleted++;

        // Track globally
        _allRewards.Add(reward);
        if (_allRewards.Count > _episodesToTrack)
        {
            _allRewards.RemoveAt(0);
        }

        // Track by team
        if (!_rewardsByTeam.ContainsKey(teamID))
        {
            _rewardsByTeam[teamID] = new List<float>();
        }

        _rewardsByTeam[teamID].Add(reward);

        // Keep list size limited
        if (_rewardsByTeam[teamID].Count > _episodesToTrack)
        {
            _rewardsByTeam[teamID].RemoveAt(0);
        }

        // Also record in ML-Agents StatsRecorder
        Academy.Instance.StatsRecorder.Add("Agent/EpisodeReward", reward);
        Academy.Instance.StatsRecorder.Add($"Agent/Team{teamID}Reward", reward);
    }

    private void Update()
    {
        // Update spatial registry with the current position.
        if (AgentRegistry.Instance != null)
        {
            AgentRegistry.Instance.UpdateAgentSpatialPosition(this);
        }

        // Update cached nearby opponents for headless mode.
        if (headlessMode)
        {
            nearbyOpponentUpdateTimer -= Time.deltaTime;
            if (nearbyOpponentUpdateTimer <= 0f)
            {
                UpdateNearbyOpponents();
                nearbyOpponentUpdateTimer = OPPONENT_UPDATE_INTERVAL;
            }
        }
        if (_trackRewardStats && Time.time - _lastStatsOutputTime > _statsOutputInterval)
            {
                OutputRewardStats();
                _lastStatsOutputTime = Time.time;
            }
    }

    private void UpdateNearbyOpponents()
    {
        // Get nearby agents (opponents) based on position, excluding agents on the same team.
        if (AgentRegistry.Instance != null)
        {
            cachedNearbyOpponents = AgentRegistry.Instance.GetNearbyAgents(transform.position, 15f, teamID);
        }
    }

    // Helper method to add observations with optional debug output.
    private void AddObservationWithDebug(VectorSensor sensor, float value, string observationName = "")
    {
        if (currentObservationCount < 91)
        {
            sensor.AddObservation(value);
            currentObservationCount++;
        }
        else if (debugObservations)
        {
            Debug.Log($"[Observation Debug] Would add observation #{currentObservationCount + 1}: {observationName} = {value}");
        }
    }

    /// <summary>
    /// Updates the agent's performance score for selective sharing
    /// </summary>
    private void UpdatePerformanceScore(float reward)
    {
        // Add reward to recent rewards queue
        _recentRewards.Enqueue(reward);

        // Keep queue at max size
        if (_recentRewards.Count > MAX_RECENT_REWARDS)
        {
            _recentRewards.Dequeue();
        }

        // Calculate average of recent rewards
        float sum = 0f;
        foreach (float r in _recentRewards)
        {
            sum += r;
        }
        _recentPerformanceScore = _recentRewards.Count > 0 ? sum / _recentRewards.Count : 0f;

        if (debugObservations && reward != 0 && _recentRewards.Count > 3)
        {
            Debug.Log($"Agent {agentId} performance score updated: {_recentPerformanceScore:F3} " +
                     $"(based on {_recentRewards.Count} rewards)");
        }
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // Store original observation count for tracking
        int startingObservationCount = currentObservationCount;
        currentObservationCount = 0;

        // In headless mode, use synthetic perception data; otherwise, perform real raycasts.
        if (!headlessMode)
        {
            perceptionSystem.PerformRaycasts();
        }
        else
        {
            perceptionSystem.PerformHeadlessPerception(cachedNearbyOpponents);
        }

        // Base observations.
        AddObservationWithDebug(sensor, transform.localPosition.x, "Agent Position X");
        AddObservationWithDebug(sensor, transform.localPosition.y, "Agent Position Y");
        AddObservationWithDebug(sensor, transform.localPosition.z, "Agent Position Z");

        Vector3 forward = transform.forward;
        AddObservationWithDebug(sensor, forward.x, "Agent Forward X");
        AddObservationWithDebug(sensor, forward.z, "Agent Forward Z");

        AddObservationWithDebug(sensor, target.localPosition.x, "Target Position X");
        AddObservationWithDebug(sensor, target.localPosition.y, "Target Position Y");
        AddObservationWithDebug(sensor, target.localPosition.z, "Target Position Z");

        Vector3 dirToTarget = (target.localPosition - transform.localPosition).normalized;
        AddObservationWithDebug(sensor, dirToTarget.x, "Direction to Target X");
        AddObservationWithDebug(sensor, dirToTarget.z, "Direction to Target Z");

        AddObservationWithDebug(sensor, healthSystem.currentHealth / healthSystem.maxHealth, "Normalized Health");
        AddObservationWithDebug(sensor, healthSystem.attackTimer / healthSystem.attackCooldown, "Attack Cooldown");
        AddObservationWithDebug(sensor, blockSystem.isBlocking ? 1f : 0f, "Blocking State");

        // Use synthetic or real raycast observations.
        if (headlessMode)
        {
            ProvideSyntheticRaycastData(sensor);
            ProvideSyntheticForwardPerception(sensor);
        }
        else
        {
            for (int i = 0; i < perceptionSystem.rayCount; i++)
            {
                if (perceptionSystem.rayHitResults[i])
                {
                    AddObservationWithDebug(sensor, 1f, $"Ray {i} Hit");
                    AddObservationWithDebug(sensor, perceptionSystem.raycastHits[i].distance / perceptionSystem.rayLength, $"Ray {i} Distance");
                    int hitLayer = perceptionSystem.raycastHits[i].collider.gameObject.layer;
                    if (hitLayer == (int)Mathf.Log(perceptionSystem.targetLayer.value, 2))
                    {
                        AddObservationWithDebug(sensor, 1f, $"Ray {i} Hit Target");
                        AddObservationWithDebug(sensor, 0f, $"Ray {i} Not Hit Opponent");
                    }
                    else if (hitLayer == (int)Mathf.Log(perceptionSystem.opponentLayer.value, 2))
                    {
                        AddObservationWithDebug(sensor, 0f, $"Ray {i} Not Hit Target");
                        AddObservationWithDebug(sensor, 1f, $"Ray {i} Hit Opponent");
                        CustomAgent opponent = perceptionSystem.raycastHits[i].collider.GetComponent<CustomAgent>();
                        if (opponent != null && opponent.teamID != this.teamID)
                        {
                            AgentHealthSystem opponentHealth = opponent.GetComponent<AgentHealthSystem>();
                            AgentBlockSystem opponentBlock = opponent.GetComponent<AgentBlockSystem>();
                            AddObservationWithDebug(sensor, opponentHealth.currentHealth / opponentHealth.maxHealth, $"Ray {i} Opponent Health");
                            AddObservationWithDebug(sensor, opponentBlock.isBlocking ? 1f : 0f, $"Ray {i} Opponent Blocking");
                        }
                        else
                        {
                            AddObservationWithDebug(sensor, 1f, $"Ray {i} Opponent Default Health");
                            AddObservationWithDebug(sensor, 0f, $"Ray {i} Opponent Default Block");
                        }
                    }
                    else
                    {
                        AddObservationWithDebug(sensor, 0f, $"Ray {i} Not Hit Target");
                        AddObservationWithDebug(sensor, 0f, $"Ray {i} Not Hit Opponent");
                        AddObservationWithDebug(sensor, 1f, $"Ray {i} Hit Other");
                        AddObservationWithDebug(sensor, 0f, $"Ray {i} Other Default Value");
                    }
                }
                else
                {
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} No Hit");
                    AddObservationWithDebug(sensor, 1f, $"Ray {i} Max Distance");
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} Default Target");
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} Default Opponent");
                    AddObservationWithDebug(sensor, 1f, $"Ray {i} Default Health");
                    AddObservationWithDebug(sensor, 0f, $"Ray {i} Default Block");
                }
            }
        }

        // If sharing knowledge, create a copy of observations we've just collected
        if (_shareKnowledge && AgentKnowledgePoolManager.Instance != null)
        {
            // Calculate and store observation data
            int observationCount = currentObservationCount;

            // Safety check to prevent negative array size or overflow
            if (observationCount > 0 && observationCount <= 91)
            {
                _lastObservationData = new float[observationCount];

                // In a real implementation, you would need to access the actual sensor data
                // This is a simplified stand-in that will be replaced with actual values
                for (int i = 0; i < observationCount; i++)
                {
                    // Placeholder for actual sensor data
                    _lastObservationData[i] = 0.5f;
                }

                // Check if this agent's performance is good enough for selective sharing
                // Only share observations from top-performing agents
                AgentKnowledgePool pool = AgentKnowledgePoolManager.Instance.GetKnowledgePool(teamID);
                bool shouldShare = true;

                if (pool._useSelectiveSharing)
                {
                    // Calculate average reward threshold for this team
                    float avgTeamReward = AgentKnowledgePoolManager.Instance.GetAverageReward(teamID);
                    float threshold = avgTeamReward * (1.0f - pool._topPercentileThreshold);

                    // Only share if this agent's performance is above threshold
                    shouldShare = _recentPerformanceScore >= threshold;

                    if (debugObservations && _recentRewards.Count > 3)
                    {
                        Debug.Log($"Selective sharing check: Agent {agentId} score {_recentPerformanceScore:F3} " +
                                 $"vs threshold {threshold:F3} - Will share: {shouldShare}");
                    }
                }

                // Contribute to the knowledge pool if allowed
                if (_lastObservationData.Length > 0 && shouldShare)
                {
                    ContributeObservationToPool(_lastObservationData);
                }
            }
            else if (debugObservations)
            {
                Debug.LogWarning($"Invalid observation count for sharing: {observationCount}");
            }
        }

        // If using shared knowledge, add observations from the pool
        if (_useSharedKnowledge && AgentKnowledgePoolManager.Instance != null && _currentInfluenceFactor > 0f)
        {
            // Get shared knowledge stats
            RewardStatistics attackStats =
                AgentKnowledgePoolManager.Instance.GetRewardStatisticsForAction(teamID, "Attack");
            RewardStatistics blockStats =
                AgentKnowledgePoolManager.Instance.GetRewardStatisticsForAction(teamID, "Block");

            // Add shared knowledge observations (effective attack and block strategies)
            // Scale these by the current influence factor (for staged learning)
            AddObservationWithDebug(sensor, attackStats.AverageReward * _currentInfluenceFactor,
                                   "Shared Attack Effectiveness");
            AddObservationWithDebug(sensor, blockStats.AverageReward * _currentInfluenceFactor,
                                   "Shared Block Effectiveness");

            // Add the current influence factor as an observation so the agent knows how much
            // to rely on shared knowledge
            AddObservationWithDebug(sensor, _currentInfluenceFactor, "Knowledge Influence Factor");
        }
        else
        {
            // Add zero values when shared knowledge is not used
            AddObservationWithDebug(sensor, 0f, "Shared Attack Effectiveness (Unused)");
            AddObservationWithDebug(sensor, 0f, "Shared Block Effectiveness (Unused)");
            AddObservationWithDebug(sensor, 0f, "Knowledge Influence Factor (Unused)");
        }

        // Get ability observations if available
        if (abilityManager != null)
        {
            float[] abilityObs = abilityManager.GetAbilityObservations();
            for (int i = 0; i < abilityObs.Length; i++)
            {
                AddObservationWithDebug(sensor, abilityObs[i], $"Ability Observation {i}");
            }
        }
        else
        {
            // Add placeholder observations if ability manager isn't available
            for (int i = 0; i < 3; i++) // Assuming 3 ability slots
            {
                AddObservationWithDebug(sensor, 0.5f, $"Default Ability Value {i}");
            }
        }

        // Fill in remaining observation slots to reach the expected size
        int remainingSlots = 91 - currentObservationCount;
        for (int i = 0; i < remainingSlots; i++)
        {
            AddObservationWithDebug(sensor, 0.5f, $"Padding Observation {i}");
        }

        if (debugObservations)
        {
            Debug.Log($"[Observation Debug] Total observations added: {currentObservationCount}/91");
        }

        // If LLM integration is enabled, send observations to LLM manager
        if (llm != null && _enableLLMIntegration && _lastObservationData != null && _lastObservationData.Length > 0)
        {
            // Determine the observation context
            AgentObservation.ObservationContext context = GetCurrentObservationContext();

            // Send observation data to LLM manager
            llm.RecordAgentObservations(agentId, teamID, _lastObservationData, context);

            if (debugObservations)
            {
                Debug.Log($"Agent {agentId} sent {_lastObservationData.Length} observations to LLM Manager");
            }
        }
    }
}