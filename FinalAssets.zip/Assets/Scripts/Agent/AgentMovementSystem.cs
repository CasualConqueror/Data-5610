using UnityEngine;

public class AgentMovementSystem : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 5f;
    public float rotationSpeed = 120f;

    // External force variables
    private Vector3 externalForce = Vector3.zero;
    private float forceRemainingTime = 0f;

    private Rigidbody rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    /// <summary>
    /// Apply an external force to the agent for a specific duration
    /// </summary>
    public void ApplyForce(Vector3 force, float duration)
    {
        externalForce = force;
        forceRemainingTime = duration;
    }

    public void Move(float moveX, float moveZ, float rotateY)
    {
        transform.Rotate(0, rotateY * rotationSpeed * Time.deltaTime, 0);

        Vector3 moveDir = new Vector3(moveX, 0, moveZ);
        Vector3 movement = moveDir * moveSpeed * Time.deltaTime;

        // Apply external force if active
        if (forceRemainingTime > 0)
        {
            movement += externalForce * Time.deltaTime;
            forceRemainingTime -= Time.deltaTime;

            if (forceRemainingTime <= 0)
            {
                externalForce = Vector3.zero;
            }
        }

        if (rb != null)
        {
            Vector3 newPos = transform.position + movement;
            rb.MovePosition(newPos);
        }
        else
        {
            transform.position += movement;
        }
    }

    public void ResetMovement()
    {
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        // Also reset any external forces
        externalForce = Vector3.zero;
        forceRemainingTime = 0f;
    }
}