using UnityEngine;

public class AgentComponentsConnector : MonoBehaviour
{
    private CustomAgent agent;
    private AgentHealthSystem healthSystem;
    private AgentBlockSystem blockSystem;
    private AgentPerceptionSystem perceptionSystem;
    private AgentMovementSystem movementSystem;

    private void Awake()
    {
        agent = GetComponent<CustomAgent>();
        healthSystem = GetComponent<AgentHealthSystem>();
        blockSystem = GetComponent<AgentBlockSystem>();
        perceptionSystem = GetComponent<AgentPerceptionSystem>();
        movementSystem = GetComponent<AgentMovementSystem>();
    }

    public void ExtendedTryAttack(CustomAgent opponent, Vector3 hitPoint) =>
        healthSystem.TryAttack(opponent, hitPoint);

    public void ExtendedBlockAttack(Vector3 hitPoint) =>
        blockSystem.BlockAttack(hitPoint);

    public void ExtendedTakeDamage(float damage, CustomAgent attacker) =>
        healthSystem.TakeDamage(damage, attacker);
}
