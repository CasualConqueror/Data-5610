using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Event-based communication system for agents that doesn't rely on visual contact.
/// Also provides integration with the LLM system for monitoring and analysis.
/// </summary>
public class AgentEventSystem : MonoBehaviour
{
    // Singleton pattern
    public static AgentEventSystem Instance { get; private set; }

    // Event tracking for LLM analysis
    private Dictionary<string, List<AgentEvent>> recentEvents = new Dictionary<string, List<AgentEvent>>();
    private int maxEventsPerType = 100;
    private bool enableEventTracking = true;

    // Reference to LLM Manager (optional)
    private LLMManager llmManager;

    // Event definitions
    public class AgentEvent
    {
        public int sourceAgentId;
        public Vector3 position;
        public float radius;
        public string eventType; // e.g., "Attack", "Block", "HealthChange", "AbilityUsed"
        public Dictionary<string, object> data; // Additional event data
        public float timestamp;

        public AgentEvent(int sourceId, Vector3 pos, float radius, string type)
        {
            sourceAgentId = sourceId;
            position = pos;
            this.radius = radius;
            eventType = type;
            data = new Dictionary<string, object>();
            timestamp = Time.time;
        }
    }

    // Dictionary for storing event listeners by event type
    private Dictionary<string, List<Action<AgentEvent>>> eventListeners =
        new Dictionary<string, List<Action<AgentEvent>>>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        // Find LLMManager if available
        llmManager = FindObjectOfType<LLMManager>();
    }

    /// <summary>
    /// Register a listener for a specific event type.
    /// </summary>
    public void RegisterListener(string eventType, Action<AgentEvent> listener)
    {
        if (!eventListeners.ContainsKey(eventType))
            eventListeners[eventType] = new List<Action<AgentEvent>>();

        eventListeners[eventType].Add(listener);
    }

    /// <summary>
    /// Unregister a listener.
    /// </summary>
    public void UnregisterListener(string eventType, Action<AgentEvent> listener)
    {
        if (eventListeners.ContainsKey(eventType))
            eventListeners[eventType].Remove(listener);
    }

    /// <summary>
    /// Broadcast an event to nearby agents without relying on physics queries.
    /// </summary>
    public void BroadcastEvent(AgentEvent evt)
    {
        // Store event in recent events for LLM analysis
        if (enableEventTracking)
        {
            TrackEvent(evt);
        }

        if (!eventListeners.ContainsKey(evt.eventType))
            return;

        // Get agents within the event's radius using the AgentRegistry
        List<CustomAgent> nearbyAgents = AgentRegistry.Instance?.GetNearbyAgents(evt.position, evt.radius)
                                        ?? new List<CustomAgent>();

        // Notify each agent (excluding the source) about the event
        foreach (var agent in nearbyAgents)
        {
            if (agent.GetInstanceID() != evt.sourceAgentId)
            {
                agent.OnEventReceived(evt);
            }
        }

        // Additionally notify all global listeners for this event type
        foreach (var listener in eventListeners[evt.eventType])
        {
            listener.Invoke(evt);
        }

        // Report significant events to LLM Manager
        ReportEventToLLM(evt);
    }

    /// <summary>
    /// Track event for LLM analysis
    /// </summary>
    private void TrackEvent(AgentEvent evt)
    {
        if (!recentEvents.ContainsKey(evt.eventType))
        {
            recentEvents[evt.eventType] = new List<AgentEvent>();
        }

        recentEvents[evt.eventType].Add(evt);

        // Trim list if too long
        if (recentEvents[evt.eventType].Count > maxEventsPerType)
        {
            recentEvents[evt.eventType].RemoveAt(0);
        }
    }

    /// <summary>
    /// Report significant events to LLM Manager for analysis
    /// </summary>
    private void ReportEventToLLM(AgentEvent evt)
    {
        if (llmManager == null)
            return;

        // Report combat events
        if (evt.eventType == "Attack" || evt.eventType == "Block" || evt.eventType == "HealthChange")
        {
            // Extract the agent who triggered the event
            CustomAgent sourceAgent = AgentRegistry.Instance?.GetAgentById(evt.sourceAgentId);
            if (sourceAgent != null)
            {
                // Report strategy
                float successRate = 0.5f; // Default neutral value
                string description = $"Agent performed {evt.eventType} at position {evt.position}";

                // Calculate success rate based on event type
                if (evt.eventType == "Attack" && evt.data.ContainsKey("damage"))
                {
                    float damage = (float)evt.data["damage"];
                    successRate = Mathf.Clamp01(damage / 30f); // Normalize damage to 0-1 range (assuming 30 is max damage)
                    description = $"Agent attacked for {damage:F1} damage";
                }
                else if (evt.eventType == "Block" && evt.data.ContainsKey("successful"))
                {
                    bool successful = (bool)evt.data["successful"];
                    successRate = successful ? 0.8f : 0.2f;
                    description = $"Agent {(successful ? "successfully" : "unsuccessfully")} blocked an attack";
                }

                llmManager.RecordAgentStrategy(
                    sourceAgent.agentId,
                    sourceAgent.teamID,
                    evt.eventType,
                    description,
                    successRate
                );
            }
        }

        // Report ability usage
        if (evt.eventType == "AbilityUsed" && evt.data.ContainsKey("abilityName"))
        {
            CustomAgent sourceAgent = AgentRegistry.Instance?.GetAgentById(evt.sourceAgentId);
            if (sourceAgent != null)
            {
                string abilityName = (string)evt.data["abilityName"];
                float effectiveness = evt.data.ContainsKey("effectiveness") ? (float)evt.data["effectiveness"] : 0.5f;

                llmManager.RecordAgentStrategy(
                    sourceAgent.agentId,
                    sourceAgent.teamID,
                    "AbilityUsage",
                    $"Agent used ability: {abilityName}",
                    effectiveness
                );
            }
        }
    }

    /// <summary>
    /// Broadcast an event to all agents on a specific team.
    /// </summary>
    public void BroadcastTeamEvent(AgentEvent evt, int teamId)
    {
        // Store event in recent events for LLM analysis
        if (enableEventTracking)
        {
            TrackEvent(evt);
        }

        if (!eventListeners.ContainsKey(evt.eventType))
            return;

        List<CustomAgent> teamAgents = AgentRegistry.Instance?.GetTeamAgents(teamId)
                                     ?? new List<CustomAgent>();
        foreach (var agent in teamAgents)
        {
            if (agent.GetInstanceID() != evt.sourceAgentId)
            {
                agent.OnEventReceived(evt);
            }
        }

        // Notify global listeners
        foreach (var listener in eventListeners[evt.eventType])
        {
            listener.Invoke(evt);
        }

        // Report team events to LLM
        ReportEventToLLM(evt);
    }

    /// <summary>
    /// Get recent events of a specific type
    /// </summary>
    public List<AgentEvent> GetRecentEvents(string eventType, int count = 10)
    {
        if (!recentEvents.ContainsKey(eventType))
            return new List<AgentEvent>();

        var events = recentEvents[eventType];
        int startIndex = Mathf.Max(0, events.Count - count);
        return events.GetRange(startIndex, Mathf.Min(count, events.Count - startIndex));
    }

    /// <summary>
    /// Get the most common event type in recent history
    /// </summary>
    public string GetMostCommonEventType()
    {
        string mostCommonType = "";
        int highestCount = 0;

        foreach (var kvp in recentEvents)
        {
            if (kvp.Value.Count > highestCount)
            {
                highestCount = kvp.Value.Count;
                mostCommonType = kvp.Key;
            }
        }

        return mostCommonType;
    }

    /// <summary>
    /// Clear recent events tracking
    /// </summary>
    public void ClearRecentEvents()
    {
        recentEvents.Clear();
    }

    /// <summary>
    /// Clears all event listeners. Useful for resetting state between training sessions.
    /// </summary>
    public void ResetEventListeners()
    {
        eventListeners.Clear();
    }
}