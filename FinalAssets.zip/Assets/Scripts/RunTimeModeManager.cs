using UnityEngine;
using System.Collections.Generic;

public class RuntimeModeManager : MonoBehaviour
{
    // Singleton pattern: ensures a single instance persists
    public static RuntimeModeManager Instance { get; private set; }

    // Runtime mode settings
    [Header("Runtime Mode Settings")]
    public bool isHeadlessMode = false;

    // References to all the cameras, lights, and renderers that should be disabled in headless mode
    [Header("Visual Components")]
    public List<Camera> sceneCameras = new List<Camera>();
    public List<Light> sceneLights = new List<Light>();
    public List<Renderer> visualRenderers = new List<Renderer>();

    // Optional: Environment ID for tracking performance across environments
    [Header("Environment Info")]
    public int environmentId = 0;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            ApplyRuntimeModeSettings();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// Applies headless mode settings by enabling or disabling visual components.
    /// </summary>
    public void ApplyRuntimeModeSettings()
    {
        if (isHeadlessMode)
        {
            // Disable cameras
            foreach (var cam in sceneCameras)
            {
                if (cam != null)
                    cam.enabled = false;
            }

            // Disable lights
            foreach (var light in sceneLights)
            {
                if (light != null)
                    light.enabled = false;
            }

            // Disable visual renderers
            foreach (var rend in visualRenderers)
            {
                if (rend != null)
                    rend.enabled = false;
            }
        }
        else
        {
            // Enable cameras
            foreach (var cam in sceneCameras)
            {
                if (cam != null)
                    cam.enabled = true;
            }

            // Enable lights
            foreach (var light in sceneLights)
            {
                if (light != null)
                    light.enabled = true;
            }

            // Enable visual renderers
            foreach (var rend in visualRenderers)
            {
                if (rend != null)
                    rend.enabled = true;
            }
        }
    }

    /// <summary>
    /// Toggles headless mode at runtime and updates visual components accordingly.
    /// </summary>
    /// <param name="headless">If true, activates headless mode.</param>
    public void ToggleHeadlessMode(bool headless)
    {
        isHeadlessMode = headless;
        ApplyRuntimeModeSettings();
    }
}
