using UnityEngine;

public class GameBootstrapper : MonoBehaviour
{
    public GameObject agentRegistryPrefab;
    public GameObject agentEventSystemPrefab;

    // Set this script's execution order to be very early (-999)
    void Awake()
    {
        // Make sure singletons exist
        if (AgentRegistry.Instance == null)
        {
            if (agentRegistryPrefab != null)
                Instantiate(agentRegistryPrefab);
            else
                new GameObject("AgentRegistry").AddComponent<AgentRegistry>();
        }

        if (AgentEventSystem.Instance == null)
        {
            if (agentEventSystemPrefab != null)
                Instantiate(agentEventSystemPrefab);
            else
                new GameObject("AgentEventSystem").AddComponent<AgentEventSystem>();
        }
    }
}